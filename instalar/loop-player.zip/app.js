import { extractYouTubeVideoId, youtubeUrl, formatLoopTime, parseLoopTime, normalizeConfiguration, normalizeView, adjustView, focusIndex, focusOnScreen, FOCUS_POINTS, MAX_LOOP_FRAGMENTS, NO_FRAGMENT, MIN_SPEED, MAX_SPEED, QUIET_SPEED, MAX_ZOOM } from './lib/core.js';
import { nudgeView } from './lib/framing.js';
import { icon, hydrateIcons } from './ui/icons.js';
import { attachJoystick } from './ui/joystick.js';
import { setupSharing } from './ui/share-panel.js';
import { setupBackup } from './ui/backup-panel.js';
import { createToolsClient } from './ui/tools-client.js';
import { engineNotice } from './lib/tools.js';
import { t, applyLocaleChoice, localizeDom, getLocale, hasMessage, videoTitle } from './lib/i18n.js';
import { loadUiPrefs, saveUiPrefs, watchUiPrefs, applyAppearance, writeCache } from './ui/appearance.js';

const isExtension = Boolean(globalThis.chrome?.runtime?.id);
const params = new URLSearchParams(location.search);
const isWorkspace = params.get('layout') === 'workspace' || (isExtension && params.has('view'));
document.body.classList.add(isWorkspace ? 'workspace' : 'popup');
document.querySelector('#demo-banner').hidden = isExtension;
const demo = isExtension ? null : (await import('./lib/demo-api.js')).demoApi;
const api = isExtension ? { send: (message) => chrome.runtime.sendMessage(message) } : demo;
const $ = (selector) => document.querySelector(selector);
// The preview's version is data (it goes into exported .loop files); only its display is translated.
const appVersion = isExtension ? chrome.runtime.getManifest().version : 'prévia';
// Catalog names for the focus grid, by FOCUS_POINTS coordinates.
const FOCUS_NAMES = { '0,0': 'topLeft', '0.5,0': 'top', '1,0': 'topRight', '0,0.5': 'left', '0.5,0.5': 'center', '1,0.5': 'right', '0,1': 'bottomLeft', '0.5,1': 'bottom', '1,1': 'bottomRight' };
// Theme and language come first so the very first render is already in the user's choice.
let uiPrefs = await loadUiPrefs();
applyAppearance(document.documentElement, uiPrefs);
applyLocaleChoice(uiPrefs.locale);
writeCache(uiPrefs, getLocale());
$('#focus-grid').innerHTML = FOCUS_POINTS.map((point, index) => {
  const name = FOCUS_NAMES[`${point.x},${point.y}`];
  const label = escape(t('app.observe.focusOn', { place: name ? t(`app.focus.${name}`) : point.label }));
  return `<button data-focus="${index}" aria-pressed="false" aria-label="${label}" title="${label}"></button>`;
}).join('') + '<span id="focus-dot" class="focus-dot" hidden></span>';
localizeDom(document);
hydrateIcons(document);
$('#version').textContent = t('app.settings.version', { version: isExtension ? appVersion : t('app.settings.previewVersion') });

const VIEWS = ['discover', 'library', 'practice', 'tools', 'settings'];
let context = { candidates: [], library: [], session: null, commands: [], tab: null, pageShortcuts: false, overlay: { visible: false, autoShow: true } };
let view = 'discover';
let previousView = 'discover';
let refreshing = false;
let candidateKey = '';
let libraryKey = '';
let partKey = '';
let toastTimer;
let connectingId = null;
let connectedVideoId = null;
let configurationBusy = false;
let mutationRevision = 0;
let sessionStamp = performance.now();
let clockFrame = null;
let scrubbing = false;
let draft = {};
let draftTimer;
let micPermission = 'prompt';
let micClient = null;
let devicesKey = '';
// While the Ferramentas tab is open, the input meter listens through the shared audio engine.
const micMeter = {
  views: () => ['input'],
  receive(message) {
    if (message.type === 'reading') $('#mic-level').style.width = `${Math.max(0, Math.min(100, ((message.level + 60) / 60) * 100)).toFixed(1)}%`;
    if (message.type === 'state') renderMicEngine(message.engine);
  },
};

function escape(value) {
  return String(value ?? '').replace(/[&<>"']/g, (character) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[character]);
}
function sourceHost(url) {
  try { return new URL(url).hostname.replace(/^www\./, ''); } catch { return t('app.video.sourcePage'); }
}
function thumbUrl(videoId) {
  return `https://i.ytimg.com/vi/${videoId}/mqdefault.jpg`;
}
function shortTime(seconds, precise = false) {
  const whole = Math.floor(seconds);
  const label = `${Math.floor(whole / 60)}:${String(whole % 60).padStart(2, '0')}`;
  return precise ? `${label}.${Math.floor((seconds - whole) * 10)}` : label;
}
// Chips stay compact; sub-second fragments keep a decimal so A and B differ.
function partLabel(part) {
  const precise = Math.floor(part.start) === Math.floor(part.end);
  return `${shortTime(part.start, precise)}–${shortTime(part.end, precise)}`;
}
function formatGap(seconds) {
  return `${Number.isInteger(seconds) ? seconds : seconds.toFixed(1)} s`;
}
const clamp = (value, minimum, maximum) => Math.min(Math.max(value, minimum), maximum);

// `action` adds a button such as "Desfazer"; the toast then stays longer.
function toast(message, error = false, action = null) {
  clearTimeout(toastTimer);
  const element = $('#toast');
  // The worker answers unknown actions in whatever language it was in; recognize all three.
  element.textContent = /Mensagem desconhecida|Unknown message|Mensaje desconocido/.test(message) ? t('app.errors.unknownAction') : message;
  if (action) {
    const button = Object.assign(document.createElement('button'), { type: 'button', className: 'toast-action', textContent: action.label });
    button.addEventListener('click', () => { clearTimeout(toastTimer); element.hidden = true; action.run(); }, { once: true });
    element.append(button);
  }
  element.dataset.tone = error ? 'danger' : '';
  element.hidden = false;
  toastTimer = setTimeout(() => { element.hidden = true; }, action ? 8000 : error ? 6500 : 3000);
}
async function request(message, quiet = false) {
  if (message.type !== 'GET_CONTEXT') mutationRevision++;
  try {
    const response = await api.send(message);
    if (!response?.ok) throw new Error(response?.error || t('app.errors.actionFailed'));
    return response;
  } catch (error) {
    if (!quiet) toast(error.message, true);
    return null;
  }
}

function setView(next) {
  if (next === 'back') next = previousView;
  if (isWorkspace && next === 'discover') next = 'library';
  if (!VIEWS.includes(next)) next = 'discover';
  if (next === 'settings' && view === 'settings') next = previousView;
  if (view !== 'settings') previousView = view;
  view = next;
  for (const button of document.querySelectorAll('.tabs [data-view], #settings-button')) {
    if (button.dataset.view === view) button.setAttribute('aria-current', 'page');
    else button.removeAttribute('aria-current');
  }
  for (const section of document.querySelectorAll('.view')) section.hidden = section.id !== `${view}-view`;
  if (view === 'library') renderLibrary(true);
  if (view === 'practice') renderSession();
  if (view === 'settings') backupPanel.showTrash();
  if (view === 'tools') renderTools();
  listenToInput();
}

function entryFor(videoId) {
  return context.library.find((item) => item.videoId === videoId);
}
function titleFor(item) {
  return videoTitle(entryFor(item.videoId)?.title || item.title, item.videoId);
}
function sourceUrlFor(candidate) {
  return candidate.pageUrl || context.tab?.url;
}
function saveControl(candidate, featured = false) {
  const entry = entryFor(candidate.videoId);
  const saved = Boolean(entry?.sources.some((item) => item.url === sourceUrlFor(candidate)));
  const label = escape(t(saved ? 'app.save.saved' : entry ? 'app.save.addSource' : 'app.save.save'));
  const glyph = icon(saved ? 'bookmarkCheck' : entry ? 'bookmarkPlus' : 'bookmark', { size: featured ? 16 : 18 });
  if (featured) return `<button class="btn btn-secondary" data-save="${candidate.videoId}" ${saved ? 'disabled' : ''} title="${label}">${glyph}${escape(t(saved ? 'app.save.savedShort' : 'app.actions.save'))}</button>`;
  if (saved) return `<span class="icon-btn" data-saved="true" role="img" aria-label="${label}" title="${label}">${glyph}</span>`;
  return `<button class="icon-btn" data-save="${candidate.videoId}" aria-label="${label}" title="${label}">${glyph}</button>`;
}
function savedMeta(videoId) {
  const entry = entryFor(videoId);
  if (!entry) return '';
  return `<span class="saved">${escape(t('app.video.inLibrary'))}</span> · ${escape(t('app.video.sections', { count: entry.configuration.fragments.length }))}`;
}

function featureCard(candidate) {
  const title = escape(titleFor(candidate));
  return `<article class="feature" data-id="${candidate.videoId}">
    <div class="feature-top"><img class="thumb" src="${thumbUrl(candidate.videoId)}" alt="" loading="lazy" referrerpolicy="no-referrer">
      <div class="feature-copy"><h2 class="feature-title">${title}</h2><span class="row-meta">${savedMeta(candidate.videoId) || escape(t('app.discover.playerFound'))}</span></div></div>
    <div class="feature-actions"><button class="btn btn-primary" data-connect="${candidate.videoId}">${icon('play', { size: 15 })}${escape(t('app.discover.practiceHere'))}</button>${saveControl(candidate, true)}</div>
  </article>`;
}
function linkRow(candidate) {
  const name = titleFor(candidate);
  return `<article class="row" data-id="${candidate.videoId}">
    <img class="thumb" src="${thumbUrl(candidate.videoId)}" alt="" loading="lazy" referrerpolicy="no-referrer">
    <div class="row-copy"><h2 class="row-title">${escape(name)}</h2><div class="row-meta">${savedMeta(candidate.videoId) || escape(t('app.discover.youtubeLink'))}</div></div>
    <div class="row-actions">${saveControl(candidate)}<button class="icon-btn row-play" data-connect="${candidate.videoId}" aria-label="${escape(t('app.video.openAndPracticeNamed', { title: name }))}" title="${escape(t('app.video.openAndPractice'))}">${icon('play', { size: 14 })}</button></div>
  </article>`;
}
function libraryRow(entry) {
  const onPage = context.candidates.some((item) => item.videoId === entry.videoId && item.kind === 'player');
  // The play action already opens YouTube; only distinct lesson pages are worth linking.
  const pages = entry.sources.filter((item) => onPage || extractYouTubeVideoId(item.url) !== entry.videoId);
  const page = pages[0] ? `· <a href="${escape(pages[0].url)}" target="_blank" rel="noopener noreferrer" title="${escape(pages[0].title)}">${escape(sourceHost(pages[0].url))}${pages.length > 1 ? ` +${pages.length - 1}` : ''}</a>` : '';
  const name = videoTitle(entry.title, entry.videoId);
  const action = t(onPage ? 'app.video.practiceOnPage' : 'app.video.openAndPractice');
  return `<article class="row library-row" data-id="${entry.videoId}">
    <img class="thumb" src="${thumbUrl(entry.videoId)}" alt="" loading="lazy" referrerpolicy="no-referrer">
    <div class="row-copy"><h2 class="row-title">${escape(name)}</h2><div class="row-meta">${escape(t('app.video.sections', { count: entry.configuration.fragments.length }))} · ${Math.round(entry.configuration.speed * 100)}% ${page}</div></div>
    <div class="row-actions"><button class="icon-btn" data-copy-code="${entry.videoId}" aria-label="${escape(t('app.video.copyCodeNamed', { title: name }))}" title="${escape(t('app.video.copyCode'))}">${icon('copy', { size: 16 })}</button><button class="icon-btn icon-btn-danger" data-delete="${entry.videoId}" aria-label="${escape(t('app.video.deleteNamed', { title: name }))}" title="${escape(t('app.video.delete'))}">${icon('trash', { size: 16 })}</button><button class="icon-btn row-play" data-connect="${entry.videoId}" aria-label="${escape(t('app.video.actionNamed', { action, title: name }))}" title="${escape(action)}">${icon('play', { size: 14 })}</button></div>
  </article>`;
}

function renderCandidates(force = false) {
  const key = JSON.stringify([context.candidates, context.library.map(({ videoId, title, sources, configuration }) => [videoId, title, sources.length, configuration.fragments.length]), context.tab, context.error]);
  if (key === candidateKey && !force) return;
  candidateKey = key;
  const count = context.candidates.length;
  $('#detected-count').textContent = count;
  $('#detected-count').hidden = !count;
  $('.page-context').dataset.found = String(count > 0);
  $('#scan-label').textContent = count ? t('app.discover.found', { count }) : t('app.discover.none');
  $('#page-label').textContent = context.tab?.title || context.tab?.url || t('app.discover.openPageHint');
  if (!count) {
    $('#candidates').innerHTML = `<div class="empty-list"><strong>${escape(t('app.discover.emptyTitle'))}</strong>${escape(context.error || t('app.discover.emptyText'))}</div>`;
    return;
  }
  const players = context.candidates.filter((item) => item.kind === 'player');
  const links = context.candidates.filter((item) => item.kind !== 'player');
  $('#candidates').innerHTML = [
    players.length ? `<div class="group-label">${escape(t('app.discover.onPlayer'))}</div><div class="list">${players.map(featureCard).join('')}</div>` : '',
    links.length ? `<div class="group-label">${escape(t('app.discover.links'))} <span class="count">${links.length}</span></div><div class="list">${links.map(linkRow).join('')}</div>` : '',
  ].join('');
}

function renderLibrary(force = false) {
  $('#saved-count').textContent = context.library.length;
  $('#saved-count').hidden = !context.library.length;
  const query = $('#library-search').value.trim().toLocaleLowerCase('pt-BR');
  const key = JSON.stringify([context.library, query, context.candidates.map(({ videoId, kind }) => videoId + kind)]);
  if (key === libraryKey && !force) return;
  libraryKey = key;
  const entries = context.library.filter((entry) => `${videoTitle(entry.title, entry.videoId)} ${entry.notes} ${entry.sources.map((source) => `${source.title} ${source.url}`).join(' ')}`.toLocaleLowerCase('pt-BR').includes(query));
  $('#library').innerHTML = entries.length ? entries.map(libraryRow).join('') : `<div class="empty-list"><strong>${escape(t(query ? 'app.library.noResults' : 'app.library.emptyTitle'))}</strong>${escape(t(query ? 'app.library.noResultsHint' : 'app.library.emptyText'))}</div>`;
}

function writeValue(selector, value) {
  const input = $(selector);
  if (document.activeElement !== input && !configurationBusy) input.value = value;
}
function playerReady() {
  return Boolean(context.session && !context.session.error && !context.session.adPlaying && context.session.duration > 0);
}
function isPlaying(session) {
  return Boolean(session && !session.paused && !(session.gapRemaining > 0) && !session.adPlaying && !session.error && session.duration > 0);
}
function activeFragment(session) {
  const configuration = session?.configuration;
  return configuration?.fragments?.[configuration.activeFragmentIndex] || null;
}
// Interpolates between worker updates so the clock moves smoothly.
function liveTime() {
  const session = context.session;
  if (!session) return 0;
  let time = session.currentTime || 0;
  if (isPlaying(session)) {
    time += ((performance.now() - sessionStamp) / 1000) * (session.configuration?.speed || 1);
    const fragment = activeFragment(session);
    if (session.configuration?.loopEnabled && fragment && session.currentTime < fragment.end) time = Math.min(time, fragment.end);
  }
  return clamp(time, 0, session.duration || time);
}
function percent(time) {
  const duration = context.session?.duration;
  return duration > 0 ? clamp((time / duration) * 100, 0, 100) : 0;
}
function paintClock() {
  if (!context.session) return;
  const time = scrubbing ? Number($('#timeline').value) : liveTime();
  $('#current-time').textContent = formatLoopTime(time);
  if (!scrubbing) $('#timeline').value = time;
  $('#timeline-wrap').style.setProperty('--p', percent(time).toFixed(3));
}
function tickClock() {
  clockFrame = null;
  if (view !== 'practice' || document.hidden) return;
  paintClock();
  if (isPlaying(context.session) && !scrubbing) clockFrame = requestAnimationFrame(tickClock);
}
function startClock() {
  paintClock();
  if (!clockFrame) clockFrame = requestAnimationFrame(tickClock);
}

function connectionStatus(session, ready, waitingForPlay) {
  if (waitingForPlay) return ['warn', t('app.status.waitingForPlay')];
  if (session.adPlaying) return ['warn', t('app.status.ad')];
  if (!ready) return ['danger', t('app.status.disconnected')];
  if (session.gapRemaining > 0) return ['warn', t('app.status.gap')];
  if (session.paused) return ['', t('app.status.paused')];
  return ['live', t('app.status.playing')];
}

function renderTempo() {
  const configuration = context.session?.configuration;
  if (!configuration) return;
  const speed = draft.speed ?? configuration.speed;
  const gap = draft.gap ?? configuration.gapSeconds;
  $('#speed-value').textContent = `${Math.round(speed * 100)}%`;
  $('#gap-value').textContent = formatGap(gap);
  document.querySelector('[data-step="speed"][data-delta^="-"]').disabled = speed <= MIN_SPEED;
  document.querySelector('[data-step="speed"]:not([data-delta^="-"])').disabled = speed >= MAX_SPEED;
  $('#speed-hint').hidden = speed >= QUIET_SPEED;
  document.querySelector('[data-step="gap"][data-delta^="-"]').disabled = gap <= 0;
  document.querySelector('[data-step="gap"]:not([data-delta^="-"])').disabled = gap >= 30;
}

// Zoom and focus belong to the selected fragment; a pending edit wins until it is saved.
function activeView() {
  const configuration = context.session.configuration;
  const index = configuration.activeFragmentIndex;
  return draft.view?.index === index ? draft.view.value : normalizeView(configuration.fragments[index]?.view);
}
function renderObserve() {
  const session = context.session;
  if (!session?.configuration) return;
  const view = activeView();
  const zoom = view?.zoom ?? 1;
  // Zoom and focus are saved with a passage; mirroring works without one.
  const chosen = session.configuration.activeFragmentIndex !== NO_FRAGMENT;
  const mirror = draft.mirror ?? session.configuration.mirror === true;
  const focused = focusIndex(view, mirror);
  $('#zoom-value').textContent = `${zoom}×`;
  $('#zoom-out').disabled = zoom <= 1;
  $('#zoom-in').disabled = !chosen || zoom >= MAX_ZOOM;
  for (const cell of document.querySelectorAll('#focus-grid [data-focus]')) { cell.setAttribute('aria-pressed', String(Number(cell.dataset.focus) === focused)); cell.disabled = !chosen; }
  const point = focusOnScreen(view, mirror);
  $('#focus-dot').hidden = !point;
  if (point) { $('#focus-dot').style.setProperty('--fx', point.x); $('#focus-dot').style.setProperty('--fy', point.y); }
  $('#mirror').setAttribute('aria-pressed', String(mirror));
  $('#mirror').title = t(mirror ? 'app.observe.mirrored' : 'app.observe.mirror');
  const canPan = zoom > 1;
  $('#stick').setAttribute('aria-disabled', String(!canPan));
  $('#stick').tabIndex = canPan ? 0 : -1;
  for (const arrow of document.querySelectorAll('#stick [data-pan]')) arrow.disabled = !canPan;
  $('#center-view').disabled = !canPan || (view.x === 0.5 && view.y === 0.5);
  $('#stick-hint').textContent = t(canPan ? 'app.observe.stickHint' : 'app.observe.stickDisabled');
  $('#view-scope').textContent = chosen ? t('app.observe.scope', { number: session.configuration.activeFragmentIndex + 1 }) : t('app.observe.scopeNone');
  const fps = session.frameRate ? ` · ${Math.round(session.frameRate)} fps` : '';
  $('#frame-back').title = `${t('app.observe.previousFrameTitle')}${fps}`;
  $('#frame-forward').title = `${t('app.observe.nextFrameTitle')}${fps}`;
}

function renderSession() {
  const session = context.session;
  const ready = playerReady();
  $('#session-dot').hidden = !ready;
  $('#practice-controls').hidden = !ready;
  $('#practice-controls').disabled = !ready;
  $('#practice-empty').hidden = Boolean(session);
  $('#practice-content').hidden = !session;
  if (!session) return;
  const configuration = normalizeConfiguration(session.configuration, session.duration || Infinity);
  // With no passage chosen the video plays freely: no A/B on the timeline, no loop.
  const fragment = configuration.fragments[configuration.activeFragmentIndex] || null;
  const looping = configuration.loopEnabled && Boolean(fragment);
  const entry = entryFor(session.videoId);
  const candidate = context.candidates.find((item) => item.videoId === session.videoId);
  const waitingForPlay = session.errorCode === 'PLAYER_NOT_READY' || /vídeo ainda não carregou/i.test(session.error || '') || (!session.error && !session.duration);
  const [tone, label] = connectionStatus(session, ready, waitingForPlay);

  const title = videoTitle(entry?.title || candidate?.title, session.videoId);
  $('#practice-name').textContent = title;
  $('#practice-name').title = title;
  const thumb = thumbUrl(session.videoId);
  if ($('#practice-thumb').getAttribute('src') !== thumb) $('#practice-thumb').src = thumb;
  $('#connection-label').textContent = label;
  $('#connection-label').dataset.tone = tone;
  $('#duration').textContent = formatLoopTime(session.duration);

  const warning = waitingForPlay ? t('app.practice.waitingForPlay') : session.error || (session.adPlaying ? t('app.practice.adPlaying') : '');
  $('#player-warning').hidden = !warning;
  $('#player-warning').innerHTML = warning ? `${icon('alert')}<span>${escape(warning)}</span>` : '';
  $('#player-warning').dataset.tone = session.error && !waitingForPlay ? 'danger' : 'warn';
  $('#connection-actions').hidden = ready || session.adPlaying || waitingForPlay;
  $('#focus-video').title = t(waitingForPlay ? 'app.practice.goPlay' : 'app.practice.goToVideo');
  if (view === 'practice' && warning) {
    if ($('#connection-feedback').textContent === session.error) $('#connection-feedback').hidden = true;
    if ($('#toast').textContent === session.error) $('#toast').hidden = true;
  }

  const playing = !(session.paused && !session.gapRemaining);
  $('#play-pause').innerHTML = icon(playing ? 'pause' : 'play', { size: 22 });
  $('#play-pause').setAttribute('aria-label', t(playing ? 'app.transport.pause' : 'app.transport.play'));
  $('#toggle-loop').setAttribute('aria-pressed', String(looping));
  $('#toggle-loop').title = t(looping ? 'app.transport.loopOn' : 'app.transport.loopOff');
  $('#timeline').max = session.duration || 10;
  const wrap = $('#timeline-wrap');
  wrap.style.setProperty('--a', percent(fragment?.start ?? 0).toFixed(3));
  wrap.style.setProperty('--b', percent(fragment?.end ?? 0).toFixed(3));
  wrap.dataset.loop = String(looping);
  wrap.dataset.part = fragment ? 'chosen' : 'none';
  $('#repetitions').textContent = session.repetitions || 0;
  $('#reps-label').textContent = t('app.practice.repsUnit', { count: session.repetitions || 0 });
  $('#gap-countdown').hidden = !(session.gapRemaining > 0);
  $('#gap-countdown').textContent = session.gapRemaining > 0 ? t('app.practice.restartsIn', { seconds: session.gapRemaining.toFixed(1) }) : '';

  // No passage: A and B wait for "Marcar", which chooses the passage again.
  writeValue('#point-a', fragment ? formatLoopTime(fragment.start) : '');
  writeValue('#point-b', fragment ? formatLoopTime(fragment.end) : '');
  for (const input of [$('#point-a'), $('#point-b')]) input.disabled = !fragment;
  for (const button of document.querySelectorAll('[data-adjust]')) button.disabled = !fragment;
  $('#range-help').hidden = !fragment;
  if (fragment) $('#range-duration').textContent = `${(fragment.end - fragment.start).toFixed(2)} s`;
  $('#part-counter').textContent = fragment ? `${configuration.activeFragmentIndex + 1} / ${configuration.fragments.length}` : t('app.parts.noneChosen', { count: configuration.fragments.length });
  $('#remove-part').disabled = !fragment || configuration.fragments.length <= 1;
  document.querySelector('[data-share-scope="active"]').disabled = !fragment;
  const nextPartKey = JSON.stringify([session.videoId, configuration.fragments, configuration.activeFragmentIndex]);
  if (nextPartKey !== partKey) {
    partKey = nextPartKey;
    const full = configuration.fragments.length >= MAX_LOOP_FRAGMENTS;
    const chipTitle = (part, index) => escape(t(part.view ? 'app.parts.chipTitleZoom' : 'app.parts.chipTitle', { number: index + 1, start: formatLoopTime(part.start), end: formatLoopTime(part.end), zoom: part.view?.zoom }));
    const addLabel = escape(t('app.parts.add'));
    $('#parts').innerHTML = configuration.fragments.map((part, index) => `<button class="chip part" data-part="${index}" aria-pressed="${index === configuration.activeFragmentIndex}" title="${chipTitle(part, index)}${index === configuration.activeFragmentIndex ? escape(` · ${t('app.parts.clickToClear')}`) : ''}">${index + 1}<small>${partLabel(part)}${part.view ? ` · ${part.view.zoom}×` : ''}</small></button>`).join('')
      + `<button class="chip chip-add" id="add-part" data-action="add-part" ${full ? 'disabled' : ''} aria-label="${addLabel}" title="${full ? escape(t('app.parts.limit', { max: MAX_LOOP_FRAGMENTS })) : addLabel}">${icon('plus', { size: 14 })}</button>`;
  }
  renderTempo();
  renderObserve();

  const overlayVisible = Boolean(context.overlay?.visible);
  $('#toggle-overlay').setAttribute('aria-pressed', String(overlayVisible));
  $('#overlay-label').textContent = t(overlayVisible ? 'app.overlay.hide' : 'app.overlay.show');

  if (connectedVideoId !== session.videoId) {
    connectedVideoId = session.videoId;
    $('#saved-title').value = title;
    $('#notes').value = entry?.notes || '';
  }
  $('#notes-help').textContent = t(entry ? 'app.notes.autoSaved' : 'app.notes.saveAdds');
  startClock();
}

// Ferramentas: permission, input choice and level meter. The tools themselves open on the page.
function micText(permission) {
  const state = ['granted', 'denied'].includes(permission) ? permission : 'prompt';
  return [t(`app.mic.${state}Title`), t(`app.mic.${state}Detail`)];
}

async function renderTools() {
  if (!isExtension) {
    micPermission = 'granted';
  } else {
    try { micPermission = (await navigator.permissions.query({ name: 'microphone' })).state; } catch { micPermission = 'prompt'; }
  }
  const [state, detail] = micText(micPermission);
  $('.mic-card').dataset.state = micPermission;
  $('#mic-state').textContent = state;
  $('#mic-detail').textContent = detail;
  $('#mic-allow').hidden = micPermission === 'granted';
  $('#mic-allow').textContent = t(micPermission === 'denied' ? 'app.mic.howToAllow' : 'app.mic.allow');
  $('#mic-input').hidden = micPermission !== 'granted';
  if (micPermission === 'granted') await renderDevices();
  listenToInput();
}

async function renderDevices() {
  const prefs = isExtension ? (await request({ type: 'GET_TOOLS' }, true))?.prefs?.input : { deviceId: '', channel: 1 };
  let devices = [];
  try { devices = (await navigator.mediaDevices.enumerateDevices()).filter((device) => device.kind === 'audioinput' && device.deviceId && !['default', 'communications'].includes(device.deviceId)); } catch { devices = []; }
  if (!isExtension) devices = [{ deviceId: 'demo', label: 'Interface USB (demonstração)' }];
  const key = JSON.stringify([devices.map((device) => [device.deviceId, device.label]), prefs]);
  if (key === devicesKey) return;
  devicesKey = key;
  const select = $('#mic-device');
  select.replaceChildren(new Option(t('app.mic.systemDefault'), ''), ...devices.map((device, index) => new Option(device.label || t('app.mic.numbered', { number: index + 1 }), device.deviceId)));
  if (prefs?.deviceId && !devices.some((device) => device.deviceId === prefs.deviceId)) {
    // The saved label stays without the "(disconnected)" suffix shown in the list.
    const label = prefs.label || t('app.mic.chosen');
    const option = new Option(t('app.mic.disconnected', { label }), prefs.deviceId);
    option.dataset.label = label;
    select.append(option);
  }
  select.value = prefs?.deviceId || '';
  $('#mic-channel').value = String(prefs?.channel === 2 ? 2 : 1);
}

function renderMicEngine(engine) {
  if (micPermission !== 'granted' || !engine) return;
  const notice = engineNotice(engine);
  $('#mic-detail').textContent = notice ? notice.text : engine.status === 'capturing' ? t('app.mic.capturing', { label: engine.input.label || t('app.mic.defaultInput'), channel: engine.input.channel }) : micText('granted')[1];
}

function listenToInput() {
  const listen = isExtension && view === 'tools' && micPermission === 'granted' && !document.hidden;
  if (listen && !micClient) {
    micClient = createToolsClient({ connect: () => chrome.runtime.connect({ name: 'lp-tools' }), send: (message) => chrome.runtime.sendMessage(message) });
    micClient.attach(micMeter);
  } else if (!listen && micClient) {
    micClient.detach(micMeter);
    micClient = null;
    $('#mic-level').style.width = '0%';
  }
}

async function openTool(tool) {
  if (!isExtension) { toast(t('app.demo.openTool')); return; }
  const response = await request({ type: 'OPEN_TOOL', tool, tabId: context.tab?.id });
  if (!response) return;
  // The tool window replaces this popup; in the library tab, say where it opened.
  if (!isWorkspace) window.close();
  else toast(t(response.where === 'page' ? 'app.tools.openedOnPage' : 'app.tools.openedInWindow'));
}

async function showPracticeTool(tool) {
  const response = await request({ type: 'SHOW_PRACTICE_TOOLS', tool });
  if (!response) return;
  context.overlay = response.overlay;
  renderSession();
  if (!isWorkspace && await focusSessionTab()) window.close();
}

function shortcutKeys(shortcut) {
  const keys = shortcut.includes('+') ? shortcut.split('+') : Array.from(shortcut);
  return keys.map((key) => `<kbd class="kbd">${escape(key)}</kbd>`).join('');
}
// Chrome describes commands in its own language; the panel follows the chosen one.
function commandLabel(command) {
  const key = `app.command.${command.name}`;
  return hasMessage(key) ? t(key) : command.description || command.name;
}
function renderSettings() {
  const commands = context.commands.filter((command) => command.name !== '_execute_action');
  const key = JSON.stringify([commands, context.pageShortcuts, context.overlay?.autoShow, context.overlay?.stage]);
  if (renderSettings.key === key) return;
  renderSettings.key = key;
  $('#chrome-shortcuts').innerHTML = commands.map((command) => `<div><span>${command.shortcut ? shortcutKeys(command.shortcut) : `<span class="unset">${escape(t('app.shortcuts.none'))}</span>`}</span>${escape(commandLabel(command))}</div>`).join('');
  $('#page-shortcuts').checked = context.pageShortcuts === true;
  $('#overlay-auto').checked = context.overlay?.autoShow !== false;
  $('#overlay-stage').checked = context.overlay?.stage === true;
}

function renderAppearance() {
  for (const button of document.querySelectorAll('[data-theme-choice]')) button.setAttribute('aria-checked', String(button.dataset.themeChoice === uiPrefs.theme));
  for (const button of document.querySelectorAll('[data-accent-choice]')) button.setAttribute('aria-checked', String(button.dataset.accentChoice === uiPrefs.accent));
  for (const button of document.querySelectorAll('[data-tool-visual-choice]')) button.setAttribute('aria-checked', String(button.dataset.toolVisualChoice === uiPrefs.toolVisual));
  $('#locale-select').value = uiPrefs.locale;
}

async function updateUiPrefs(patch) {
  const previousLocale = getLocale();
  uiPrefs = await saveUiPrefs(patch);
  applyAppearance(document.documentElement, uiPrefs);
  renderAppearance();
  if (applyLocaleChoice(uiPrefs.locale) !== previousLocale) {
    writeCache(uiPrefs, getLocale());
    // Re-rendering every screen is simplest from a fresh load; come back to Settings.
    try { sessionStorage.setItem('lp-view', view); } catch { /* Not essential. */ }
    location.reload();
    return;
  }
  writeCache(uiPrefs, getLocale());
}

function applySession(session) {
  if (context.session && (!session || session.videoId !== context.session.videoId)) {
    $('#connection-feedback').hidden = true;
    $('#toast').hidden = true;
    connectedVideoId = null;
    draft = {};
  }
  context.session = session;
  sessionStamp = performance.now();
}

async function refresh(force = false) {
  if (refreshing || $('#confirm-dialog').open) return;
  refreshing = true;
  try {
    const revision = mutationRevision;
    const response = await request({ type: 'GET_CONTEXT' }, !force);
    if (!response) return;
    // A poll begun before a mutation must not restore its older library/session.
    if (revision !== mutationRevision || configurationBusy) return;
    applySession(response.session);
    context = { ...context, ...response, session: context.session };
    renderCandidates(force);
    renderLibrary(force);
    renderSession();
    renderSettings();
    backupPanel.render();
    if (connectingId && response.session?.videoId === connectingId) {
      connectingId = null;
      setView('practice');
    }
  } finally { refreshing = false; }
}

function subscribe() {
  const receive = (message) => {
    if (message?.type === 'SESSION' && !configurationBusy) {
      applySession(message.session);
      if (message.overlay) context.overlay = message.overlay;
      renderSession();
    }
  };
  if (!isExtension) { demo.subscribe(receive); return; }
  try {
    const port = chrome.runtime.connect({ name: 'lp-ui' });
    port.onMessage.addListener(receive);
    // The service worker may restart; the next poll keeps the UI current meanwhile.
    port.onDisconnect.addListener(() => { if (chrome.runtime?.id) setTimeout(subscribe, 1000); });
  } catch { /* Polling still updates the interface. */ }
}

async function saveVideo(candidate) {
  const response = await request({ type: 'SAVE_VIDEO', candidate });
  if (!response) return false;
  context.library = response.library;
  renderCandidates(true);
  renderLibrary(true);
  toast(t('app.save.done'));
  return true;
}
async function connectVideo(videoId, tabId) {
  connectingId = videoId;
  const candidate = context.candidates.find((item) => item.videoId === videoId);
  const entry = entryFor(videoId);
  if (candidate && !entry?.sources.some((source) => source.url === sourceUrlFor(candidate))) {
    if (!await saveVideo(candidate)) { connectingId = null; return; }
  }
  const targetTabId = tabId ?? context.tab?.id;
  const allowOpen = !tabId && (!candidate || candidate.kind === 'link');
  $('#connection-feedback').hidden = true;
  mutationRevision++;
  const response = await api.send({ type: 'CONNECT_VIDEO', videoId, tabId: targetTabId, allowOpen }).catch((error) => ({ ok: false, error: error.message }));
  mutationRevision++;
  if (!response?.ok) {
    connectingId = null;
    $('#connection-feedback').innerHTML = `${icon('alert')}<span>${escape(response?.error || t('app.errors.noConnection'))}</span>`;
    $('#connection-feedback').hidden = false;
    await refresh();
    return;
  }
  if (response.overlay) context.overlay = response.overlay;
  if (response.session) {
    applySession(response.session);
    connectingId = null;
    renderSession();
    setView('practice');
  } else {
    toast(t('app.practice.openingYouTube'));
  }
  await refresh();
}
async function command(name, value) {
  if (!playerReady()) return;
  const response = await request({ type: 'PLAYER_COMMAND', command: name, value });
  if (response?.session) { applySession(response.session); renderSession(); }
}
async function setConfiguration(configuration) {
  if (!playerReady() || configurationBusy) return false;
  configurationBusy = true;
  try {
    const response = await request({ type: 'SET_CONFIG', videoId: context.session.videoId, configuration });
    if (!response) return false;
    if (response.session) applySession(response.session);
    else context.session.configuration = configuration;
    if (response.entry) context.library = context.library.map((entry) => entry.videoId === response.entry.videoId ? response.entry : entry);
    return true;
  } finally { configurationBusy = false; renderSession(); renderLibrary(true); }
}
async function editPoint(point, value) {
  if (!context.session) return;
  const configuration = normalizeConfiguration(context.session.configuration, context.session.duration || Infinity);
  const fragment = configuration.fragments[configuration.activeFragmentIndex];
  if (!fragment) return;
  const parsed = parseLoopTime(value);
  const next = { ...fragment, [point]: parsed };
  if (parsed === null || next.start < 0 || next.end > context.session.duration || Math.round(next.end * 100) - Math.round(next.start * 100) < 10) {
    toast(t('app.ab.invalidTime'), true);
    $(point === 'start' ? '#point-a' : '#point-b').value = formatLoopTime(fragment[point]);
    return;
  }
  configuration.fragments[configuration.activeFragmentIndex] = next;
  await setConfiguration(configuration);
}

// Speed and gap steppers update instantly and send one change after the clicks settle.
function stepTempo(kind, delta) {
  const configuration = context.session?.configuration;
  if (!configuration || !playerReady()) return;
  const current = draft[kind] ?? (kind === 'speed' ? configuration.speed : configuration.gapSeconds);
  draft[kind] = kind === 'speed' ? clamp(Math.round((current + delta) * 100) / 100, MIN_SPEED, MAX_SPEED) : clamp(Math.round((current + delta) * 10) / 10, 0, 30);
  renderTempo();
  scheduleDraft(350);
}
function reframe(change) {
  const configuration = context.session?.configuration;
  if (!configuration || !playerReady()) return;
  const mirror = draft.mirror ?? configuration.mirror === true;
  draft.view = { index: configuration.activeFragmentIndex, value: adjustView(activeView(), change, mirror) };
  renderObserve();
  scheduleDraft(150);
}
function toggleMirror() {
  const configuration = context.session?.configuration;
  if (!configuration || !playerReady()) return;
  draft.mirror = !(draft.mirror ?? configuration.mirror === true);
  renderObserve();
  scheduleDraft(150);
}
// The joystick and arrows show their framing live and save it once they settle.
function framingState() {
  const configuration = context.session?.configuration;
  if (!configuration || !playerReady()) return null;
  return { index: configuration.activeFragmentIndex, view: activeView(), mirror: draft.mirror ?? configuration.mirror === true };
}
function liveView(view, state) {
  draft.view = { index: state.index, value: view };
  renderObserve();
}
function previewView(view, state) {
  try { Promise.resolve(api.send({ type: 'PREVIEW_VIEW', index: state.index, view, mirror: state.mirror })).catch(() => {}); } catch { /* The saved framing still follows. */ }
}
function nudge(direction, multiplier = 1) {
  const state = framingState();
  if (!state?.view) return;
  const view = nudgeView(state.view, direction, state.mirror, multiplier);
  liveView(view, state);
  previewView(view, state);
  scheduleDraft(400);
}
function scheduleDraft(delay) {
  clearTimeout(draftTimer);
  draftTimer = setTimeout(flushDraft, delay);
}
function resetTempo(kind) {
  if (!context.session) return;
  stepTempo(kind, (kind === 'speed' ? 1 : 0) - (draft[kind] ?? (kind === 'speed' ? context.session.configuration.speed : context.session.configuration.gapSeconds)));
}
async function flushDraft() {
  if (configurationBusy || joystick.active) { draftTimer = setTimeout(flushDraft, 200); return; }
  const sent = { ...draft };
  if (!Object.keys(sent).length || !context.session) return;
  const configuration = structuredClone(context.session.configuration);
  if (sent.speed !== undefined) configuration.speed = sent.speed;
  if (sent.gap !== undefined) configuration.gapSeconds = sent.gap;
  if (sent.mirror !== undefined) configuration.mirror = sent.mirror;
  const fragment = sent.view && configuration.fragments[sent.view.index];
  if (fragment) {
    if (sent.view.value) fragment.view = sent.view.value;
    else delete fragment.view;
  }
  await setConfiguration(configuration);
  for (const [kind, value] of Object.entries(sent)) if (draft[kind] === value) delete draft[kind];
  renderTempo();
  renderObserve();
}

// Resolves from the clicked button: a late `close` event from a previous dialog must not answer this one.
function confirmAction(title, description, { label = 'Excluir', danger = true } = {}) {
  const dialog = $('#confirm-dialog');
  const confirm = dialog.querySelector('button[value="confirm"]');
  $('#confirm-title').textContent = title;
  $('#confirm-description').textContent = description;
  confirm.textContent = label;
  confirm.className = `btn ${danger ? 'btn-danger' : 'btn-primary'}`;
  dialog.showModal();
  return new Promise((resolve) => {
    const finish = (confirmed) => {
      dialog.removeEventListener('click', onClick);
      dialog.removeEventListener('cancel', onCancel);
      if (dialog.open) dialog.close(confirmed ? 'confirm' : 'cancel');
      resolve(confirmed);
    };
    const onClick = (event) => {
      const button = event.target.closest('button[value]');
      if (!button) return;
      event.preventDefault();
      finish(button.value === 'confirm');
    };
    const onCancel = () => finish(false);
    dialog.addEventListener('click', onClick);
    dialog.addEventListener('cancel', onCancel);
  });
}

async function addPart() {
  const session = context.session;
  if (!session || session.configuration.fragments.length >= MAX_LOOP_FRAGMENTS) return;
  const configuration = structuredClone(session.configuration);
  const end = Math.floor(session.duration * 100) / 100;
  const start = Math.round(Math.max(0, Math.min(liveTime(), end - Math.min(10, end))) * 100) / 100;
  configuration.fragments.push({ start, end: Math.min(end, start + 10) });
  configuration.activeFragmentIndex = configuration.fragments.length - 1;
  await setConfiguration(configuration);
}

// The next part takes the removed one's place; removing the last selects the previous one.
async function removePart() {
  const session = context.session;
  const part = session?.configuration.fragments[session.configuration.activeFragmentIndex];
  if (!part || session.configuration.fragments.length <= 1) return;
  const index = session.configuration.activeFragmentIndex;
  if (!await confirmAction(t('app.parts.removeConfirm', { number: index + 1 }), t('app.parts.removeDetail', { start: formatLoopTime(part.start), end: formatLoopTime(part.end) }))) return;
  // Read again: the session may have changed while the dialog was open.
  const configuration = structuredClone(context.session.configuration);
  if (configuration.fragments.length <= 1 || configuration.activeFragmentIndex !== index) return;
  configuration.fragments.splice(index, 1);
  configuration.activeFragmentIndex = Math.min(index, configuration.fragments.length - 1);
  if (await setConfiguration(configuration)) toast(t('app.parts.removed'));
}

async function focusSessionTab() {
  if (!isExtension || !context.session?.tabId) return false;
  try {
    const tab = await chrome.tabs.update(context.session.tabId, { active: true });
    await chrome.windows.update(tab.windowId, { focused: true });
    return true;
  } catch {
    toast(t('app.practice.tabClosed'), true);
    return false;
  }
}

document.addEventListener('click', async (event) => {
  const button = event.target.closest('button');
  if (!button || button.disabled) return;
  const data = button.dataset;
  if (data.view) setView(data.view);
  if (data.save) await saveVideo(context.candidates.find((candidate) => candidate.videoId === data.save));
  if (data.connect) {
    button.disabled = true;
    button.dataset.busy = 'true';
    try { await connectVideo(data.connect); } finally { button.disabled = false; delete button.dataset.busy; }
  }
  if (data.delete) {
    // Deleting goes to the trash for 30 days, so it needs no confirmation: the toast offers to undo.
    const entry = entryFor(data.delete);
    const response = entry && await request({ type: 'DELETE_VIDEO', videoId: entry.videoId });
    if (response) {
      context = { ...context, library: response.library, trashCount: response.trashCount };
      renderLibrary(true);
      renderCandidates(true);
      toast(t('app.delete.movedToTrash'), false, backupPanel.undoDelete(entry.videoId));
    }
  }
  if (data.command) await command(data.command, data.value === undefined ? undefined : Number(data.value));
  // Clicking the chosen passage again leaves none chosen.
  if (data.part !== undefined) await command('select-part', Number(data.part) === context.session?.configuration.activeFragmentIndex ? NO_FRAGMENT : Number(data.part));
  if (data.adjust) {
    const part = activeFragment(context.session);
    if (part) await editPoint(data.adjust, Math.round((part[data.adjust] + Number(data.value)) * 100) / 100);
  }
  if (data.step) stepTempo(data.step, Number(data.delta));
  if (data.reset) resetTempo(data.reset);
  if (data.zoom) reframe({ zoom: (activeView()?.zoom ?? 1) + Number(data.zoom) });
  if (data.zoomReset !== undefined) reframe({ zoom: 1 });
  if (data.focus !== undefined) reframe({ focus: FOCUS_POINTS[data.focus] });
  if (data.pan) { const [x, y] = data.pan.split(',').map(Number); nudge({ x, y }); }
  if (data.action === 'center-view') reframe({ focus: { x: 0.5, y: 0.5 } });
  if (data.action === 'mirror') toggleMirror();
  if (data.action === 'add-part') await addPart();
  if (data.action === 'remove-part') await removePart();
  if (data.openTool) await openTool(data.openTool);
  if (data.practiceTool) await showPracticeTool(data.practiceTool);
});

// Backup folder, backup file, restore points and trash (Ajustes).
const backupPanel = setupBackup({
  context: () => context, request, toast, confirmAction, isExtension, isWorkspace,
  importLoops: (file) => sharing.importFile(file),
  update(patch) {
    context = { ...context, ...patch };
    renderLibrary(true);
    renderCandidates(true);
    renderSettings();
    backupPanel.render();
  },
});
const sharing = setupSharing({
  context: () => context, request, toast, setView, isExtension, isWorkspace, appVersion, importBackup: (file) => backupPanel.importFile(file),
  update(library, session) {
    context.library = library;
    if (session !== undefined) { applySession(session); renderSession(); }
    renderLibrary(true);
    renderCandidates(true);
  },
});

// Like the other tools, the fretboard floats over the current page (a small window where pages refuse
// it); the arrow button opens the full page in a tab.
for (const [selector, layout] of [['#open-fretboard', 'float'], ['#open-fretboard-tab', 'tab']]) {
  $(selector).addEventListener('click', async () => {
    if (!isExtension) { location.href = layout === 'tab' ? 'fretboard.html' : 'fretboard.html?layout=compact'; return; }
    const response = await request({ type: 'OPEN_FRETBOARD', layout, tabId: context.tab?.id });
    if (!response) return;
    if (!isWorkspace) window.close();
    else if (layout === 'float') toast(t(response.where === 'page' ? 'app.tools.openedOnPage' : 'app.tools.openedInWindow'));
  });
}
$('#mic-allow').addEventListener('click', async () => {
  if (!isExtension) { toast(t('app.demo.allowMic')); return; }
  if (await request({ type: 'TOOLS_OPEN_SETUP' }) && !isWorkspace) window.close();
});
for (const select of [$('#mic-device'), $('#mic-channel')]) {
  select.addEventListener('change', async () => {
    const device = $('#mic-device');
    const option = device.selectedOptions[0];
    const input = { deviceId: device.value, label: device.value ? option?.dataset.label ?? option?.textContent ?? '' : '', channel: Number($('#mic-channel').value) === 2 ? 2 : 1 };
    if (isExtension) await request({ type: 'TOOLS_PREFS', patch: { input } });
    devicesKey = '';
  });
}
if (isExtension) {
  navigator.permissions?.query({ name: 'microphone' }).then((permission) => { permission.onchange = () => { if (view === 'tools') renderTools(); }; }).catch(() => {});
  navigator.mediaDevices?.addEventListener?.('devicechange', () => { devicesKey = ''; if (view === 'tools') renderTools(); });
}

$('#add-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  const videoId = extractYouTubeVideoId($('#video-url').value);
  // A loop code pasted here opens the import confirmation instead.
  if (!videoId && sharing.isCode($('#video-url').value)) {
    if (await sharing.importText($('#video-url').value)) $('#video-url').value = '';
    return;
  }
  if (!videoId) { toast(t('app.discover.invalidLink'), true); return; }
  // "Vídeo <id>" is the stored placeholder title (data); videoTitle() shows it in the current language.
  const candidate = { videoId, title: `Vídeo ${videoId}`, youtubeUrl: youtubeUrl(videoId), pageUrl: youtubeUrl(videoId), kind: 'link' };
  if (await saveVideo(candidate)) { $('#video-url').value = ''; setView('library'); }
});
$('#library-search').addEventListener('input', () => renderLibrary(true));
$('#rescan').addEventListener('click', () => refresh(true));
$('#diagnose').addEventListener('click', async () => {
  const response = await request({ type: 'GET_DIAGNOSTICS' });
  if (!response) return;
  $('#diagnostic-output').hidden = false;
  $('#diagnostic-output').value = JSON.stringify(response.diagnostics, null, 2);
  $('#diagnostic-output').focus();
  $('#diagnostic-output').select();
});
$('#reconnect-video').addEventListener('click', async (event) => {
  const session = context.session;
  if (!session) return;
  const button = event.currentTarget;
  button.disabled = true;
  button.dataset.busy = 'true';
  try { await connectVideo(session.videoId, session.tabId); }
  finally { button.disabled = false; delete button.dataset.busy; }
});
$('#toggle-overlay').addEventListener('click', async () => {
  const showing = !context.overlay?.visible;
  const response = await request({ type: showing ? 'SHOW_OVERLAY' : 'HIDE_OVERLAY' });
  if (!response) return;
  context.overlay = response.overlay;
  renderSession();
  // The floating controller replaces this popup; bring the lesson forward.
  if (showing && !isWorkspace && await focusSessionTab()) window.close();
});
for (const button of document.querySelectorAll('[data-theme-choice]')) button.addEventListener('click', () => updateUiPrefs({ theme: button.dataset.themeChoice }));
for (const button of document.querySelectorAll('[data-accent-choice]')) button.addEventListener('click', () => updateUiPrefs({ accent: button.dataset.accentChoice }));
for (const button of document.querySelectorAll('[data-tool-visual-choice]')) button.addEventListener('click', () => updateUiPrefs({ toolVisual: button.dataset.toolVisualChoice }));
$('#locale-select').addEventListener('change', (event) => updateUiPrefs({ locale: event.target.value }));
// Another Loop Player page changed the appearance or language.
watchUiPrefs((next) => {
  const previousLocale = getLocale();
  uiPrefs = next;
  applyAppearance(document.documentElement, uiPrefs);
  renderAppearance();
  if (applyLocaleChoice(uiPrefs.locale) !== previousLocale) location.reload();
});
$('#overlay-auto').addEventListener('change', async (event) => {
  const response = await request({ type: 'SET_OVERLAY_PREFS', autoShow: event.target.checked });
  if (response) context.overlay = response.overlay;
  event.target.checked = context.overlay?.autoShow !== false;
});
$('#overlay-stage').addEventListener('change', async (event) => {
  const response = await request({ type: 'SET_OVERLAY_PREFS', stage: event.target.checked });
  if (response) context.overlay = response.overlay;
  event.target.checked = context.overlay?.stage === true;
});
$('#page-shortcuts').addEventListener('change', async (event) => {
  const response = await request({ type: 'SET_PAGE_SHORTCUTS', enabled: event.target.checked });
  if (response) context.pageShortcuts = response.pageShortcuts;
  event.target.checked = context.pageShortcuts === true;
});
$('#expand').addEventListener('click', () => {
  if (isExtension) chrome.tabs.create({ url: chrome.runtime.getURL('app.html?view=library') });
  else toast(t('app.demo.openLibrary'));
});
$('#configure-shortcuts').addEventListener('click', () => {
  if (isExtension) chrome.tabs.create({ url: 'chrome://extensions/shortcuts' });
  else toast(t('app.demo.openShortcuts'));
});
$('#focus-video').addEventListener('click', async () => {
  if (isExtension) await focusSessionTab();
  else toast(t('app.demo.focusVideo'));
});
$('#point-a').addEventListener('change', (event) => editPoint('start', event.target.value));
$('#point-b').addEventListener('change', (event) => editPoint('end', event.target.value));
for (const input of [$('#point-a'), $('#point-b')]) {
  input.addEventListener('keydown', (event) => { if (event.key === 'Enter') input.blur(); });
}
$('#timeline').addEventListener('input', () => { scrubbing = true; paintClock(); });
$('#timeline').addEventListener('change', async (event) => {
  const value = Number(event.target.value);
  await command('seek-to', value);
  scrubbing = false;
  startClock();
});
$('#save-notes').addEventListener('click', async () => {
  const videoId = context.session?.videoId;
  if (!videoId) return;
  if (!entryFor(videoId)) {
    if (!await saveVideo({ videoId, title: $('#saved-title').value, pageUrl: youtubeUrl(videoId) })) return;
  }
  const response = await request({ type: 'UPDATE_VIDEO', videoId, patch: { title: $('#saved-title').value.trim(), notes: $('#notes').value } });
  if (response) { context.library = response.library; renderLibrary(true); renderSession(); toast(t('app.notes.saved')); }
});
document.addEventListener('visibilitychange', () => { if (!document.hidden) startClock(); listenToInput(); });
document.addEventListener('keydown', (event) => {
  if (view !== 'practice' || !playerReady() || $('#confirm-dialog').open || event.altKey || event.ctrlKey || event.metaKey || event.repeat) return;
  if (event.composedPath().some((node) => node instanceof HTMLElement && (node.isContentEditable || /^(INPUT|TEXTAREA|SELECT|BUTTON|SUMMARY|A)$/.test(node.tagName)))) return;
  const key = event.key.toLowerCase();
  const commands = { ' ': 'toggle-play', a: 'capture-a', b: 'capture-b', l: 'toggle-loop', r: 'restart' };
  if (commands[key]) { event.preventDefault(); command(commands[key]); }
  else if (/^[1-9]$/.test(key) && Number(key) <= context.session.configuration.fragments.length) { event.preventDefault(); command('select-part', Number(key) - 1 === context.session.configuration.activeFragmentIndex ? NO_FRAGMENT : Number(key) - 1); }
  else if (['arrowleft', 'arrowright'].includes(key)) { event.preventDefault(); command('seek', (key === 'arrowleft' ? -1 : 1) * (event.shiftKey ? 0.1 : 1)); }
  else if (key === ',' || key === '.') { event.preventDefault(); command('frame-step', key === ',' ? -1 : 1); }
});

const joystick = attachJoystick({
  pad: $('#stick'),
  knob: $('#stick-knob'),
  start: framingState,
  change: liveView,
  preview: previewView,
  finish: (view, state) => { liveView(normalizeView(view), state); scheduleDraft(400); },
  nudge,
});

let reopenView = null;
try { reopenView = sessionStorage.getItem('lp-view'); sessionStorage.removeItem('lp-view'); } catch { reopenView = null; }
renderAppearance();
setView(reopenView || params.get('view') || (isWorkspace ? 'library' : 'discover'));
await refresh(true);
subscribe();
sharing.start();
backupPanel.start();
setInterval(() => refresh(), 1000);
