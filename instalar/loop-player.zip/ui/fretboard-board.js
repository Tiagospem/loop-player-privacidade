// The fretboard itself: Explore (scales, shapes, harmonic field, intervals), Draw (ui/fretboard-editor.js)
// and Tab (ui/fretboard-tab.js).
// Mounted in the extension page, in the floating window on a lesson page (closed shadow root, Trusted
// Types) and moved into Picture-in-Picture with its element, so every lookup starts from the board.
import { SCALE_GROUPS, INTERVAL_SHORT, COMPOUND_SHORT, spellScale, spellPitch, degreeLabels, scalePositions, scaleShapes, harmonicField, intervalLabel, fretboardCells, tuningStrings, tuningNames, isArpeggio, parentScale, pitchClass } from '../lib/theory.js';
import { TUNING_IDS } from '../lib/pitch.js';
import { t, getLocale } from '../lib/i18n.js';
import { createFretboard } from './fretboard.js';
import { createEditor } from './fretboard-editor.js';
import { createTabEditor, tabControlsMarkup, tabSheetMarkup, tabDialogsMarkup } from './fretboard-tab.js';
import { createTranscriber, transcribeMarkup, transcribeDialogsMarkup } from './fretboard-transcribe.js';
import { icon } from './icons.js';
import { attachTooltips } from './tooltip.js';
import { setHTML, escapeHTML } from './html.js';

const STATE_KEY = 'loopPlayer.fretboard.v1';
const FRET_CHOICES = [12, 15, 22, 24];
const SCALE_IDS = SCALE_GROUPS.flatMap((group) => group.scales);
const DEFAULT_STATE = Object.freeze({ mode: 'explore', root: 9, scale: 'minorPentatonic', labels: 'notes', shape: 0, hand: 'right', high: 'top', frets: 15, tuning: 'standard', panel: 'scale', sevenths: false, onlyScale: false, compound: true, allNotes: false });

const tx = (key, params) => escapeHTML(t(key, params));
const svg = (name, size = 14) => icon(name, { size });
const radio = (attribute, value, label, content = tx(label)) => `<button type="button" role="radio" ${attribute}="${value}">${content}</button>`;

function boardMarkup() {
  const withIcon = (name, label) => `${svg(name)}<span>${tx(label)}</span>`;
  const iconButton = (id, name, label, extra = '') => `<button type="button" class="icon-btn${extra}" id="${id}" title="${tx(label)}" aria-label="${tx(label)}">${svg(name, 16)}</button>`;
  return `
  <div class="board-bar">
    <div class="seg mode-switch" id="mode" role="radiogroup" aria-label="${tx('fretboard.title')}">
      ${radio('data-mode', 'explore', '', withIcon('fretboard', 'fretboard.mode.explore'))}
      ${radio('data-mode', 'draw', '', withIcon('pen', 'fretboard.mode.draw'))}
      ${radio('data-mode', 'tab', '', withIcon('tab', 'fretboard.mode.tab'))}
      ${radio('data-mode', 'transcribe', '', withIcon('video', 'fretboard.mode.transcribe'))}
    </div>
    <span class="bar-spacer"></span>
    <button type="button" class="btn btn-secondary btn-sm" id="to-draw" title="${tx('fretboard.info.toDrawHint')}">${withIcon('pen', 'fretboard.info.toDraw')}</button>
    <div class="seg seg-sm hand-switch" id="hand" role="radiogroup" aria-label="${tx('fretboard.view.hand')}">${radio('data-hand', 'right', 'fretboard.view.right')}${radio('data-hand', 'left', 'fretboard.view.left')}</div>
    <button type="button" class="btn btn-ghost btn-sm view-toggle" id="view-toggle" popovertarget="view-menu">${withIcon('settings', 'fretboard.view.title')}</button>
    <div class="view-menu" id="view-menu" popover>
      <div class="view-item"><span id="strings-label">${tx('fretboard.view.strings')}</span>
        <div class="seg seg-sm" id="orientation" role="radiogroup" aria-labelledby="strings-label">${radio('data-high', 'top', 'fretboard.view.highTop')}${radio('data-high', 'bottom', 'fretboard.view.highBottom')}</div></div>
      <label class="view-item" id="frets-field"><span>${tx('fretboard.view.frets')}</span>
        <select id="frets" class="input input-sm">${FRET_CHOICES.map((to) => `<option value="${to}">0–${to}</option>`).join('')}</select></label>
      <label class="view-item"><span>${tx('fretboard.view.tuning')}</span>
        <select id="tuning" class="input input-sm">${TUNING_IDS.map((id) => `<option value="${id}">${tx(`tools.tuning.${id}`)}</option>`).join('')}</select></label>
    </div>
  </div>

  <div class="controls" id="explore-controls">
    <div class="control control-keys"><span class="field-label" id="key-label">${tx('fretboard.key')}</span><div class="keys" id="keys" role="radiogroup" aria-labelledby="key-label"></div></div>
    <div class="control"><label class="field-label" for="scale">${tx('fretboard.scale')}</label><select id="scale" class="input">${scaleOptions()}</select></div>
    <div class="control"><span class="field-label" id="labels-label">${tx('fretboard.show')}</span>
      <div class="label-row"><div class="seg" id="labels" role="radiogroup" aria-labelledby="labels-label">${radio('data-labels', 'notes', 'fretboard.show.notes')}${radio('data-labels', 'degrees', 'fretboard.show.degrees')}</div>
        <label class="check" title="${tx('fretboard.allNotesHint')}"><input type="checkbox" id="all-notes"><span>${tx('fretboard.allNotes')}</span></label></div></div>
    <div class="control" id="shapes-control"><span class="field-label" id="shapes-label">${tx('fretboard.shapes')}</span><div class="chips" id="shapes" role="radiogroup" aria-labelledby="shapes-label"></div></div>
  </div>

  <div class="controls" id="draw-controls" hidden>
    <div class="control"><span class="field-label" id="draw-tool-label">${tx('fretboard.draw.tool')}</span>
      <div class="seg seg-icons" id="draw-tool" role="radiogroup" aria-labelledby="draw-tool-label">
        ${radio('data-tool', 'mark', '', withIcon('pen', 'fretboard.draw.tool.mark'))}${radio('data-tool', 'line', '', withIcon('line', 'fretboard.draw.tool.line'))}${radio('data-tool', 'erase', '', withIcon('eraser', 'fretboard.draw.tool.erase'))}
      </div></div>
    <div class="control"><span class="field-label" id="draw-color-label">${tx('fretboard.draw.color')}</span>
      <button type="button" class="color-pick" id="draw-color" popovertarget="draw-colors" aria-haspopup="menu" aria-expanded="false"><span class="color-dot" aria-hidden="true"></span>${svg('chevronDown')}</button>
      <div class="color-menu mark-colors" id="draw-colors" popover role="menu" aria-labelledby="draw-color-label"></div></div>
    <div class="control"><span class="field-label" id="draw-label-label">${tx('fretboard.draw.label')}</span>
      <div class="seg" id="draw-label" role="radiogroup" aria-labelledby="draw-label-label">${['note', 'degree', 'none'].map((label) => radio('data-label', label, `fretboard.draw.label.${label}`)).join('')}</div></div>
    <div class="control"><label class="field-label" for="draw-key">${tx('fretboard.key')}</label><select id="draw-key" class="input input-narrow" title="${tx('fretboard.draw.keyHint')}"></select></div>
    <div class="control"><label class="field-label" for="draw-scale">${tx('fretboard.draw.background')}</label><select id="draw-scale" class="input"><option value="">${tx('fretboard.draw.backgroundNone')}</option>${scaleOptions()}</select></div>
    <div class="control"><span class="field-label" id="draw-frets-label">${tx('fretboard.draw.frets')}</span>
      <div class="fret-range" role="group" aria-labelledby="draw-frets-label">
        <select id="draw-from" class="input input-sm" aria-label="${tx('fretboard.draw.fretsFrom')}"></select><span aria-hidden="true">–</span><select id="draw-to" class="input input-sm" aria-label="${tx('fretboard.draw.fretsTo')}"></select>
      </div></div>
    <div class="control history">${iconButton('draw-undo', 'undo', 'fretboard.draw.undo')}${iconButton('draw-redo', 'redo', 'fretboard.draw.redo')}${iconButton('draw-clear', 'trash', 'fretboard.draw.clear', ' icon-btn-danger')}</div>
  </div>

${tabControlsMarkup()}

  <div class="neck" id="neck"></div>
  <p class="hint draw-hint" id="draw-hint" aria-live="polite" hidden></p>
${tabSheetMarkup()}
${transcribeMarkup()}

  <div class="explore-panel" id="explore-panel">
    <div class="panel-tabs" role="tablist">${['scale', 'field', 'intervals'].map((panel) => `<button type="button" role="tab" data-panel="${panel}">${tx(`fretboard.tabs.${panel}`)}</button>`).join('')}</div>
    <div id="panel-scale" class="panel-body">
      <dl class="scale-facts">
        <div class="fact-name"><dt class="sr-only">${tx('fretboard.scale')}</dt><dd id="scale-name"></dd></div>
        <div><dt>${tx('fretboard.info.notes')}</dt><dd id="scale-notes"></dd></div>
        <div><dt>${tx('fretboard.info.formula')}</dt><dd id="scale-formula"></dd></div>
        <div id="relative-row"><dt>${tx('fretboard.info.relative')}</dt><dd id="scale-relative"></dd></div>
      </dl>
    </div>
    <div id="panel-field" class="panel-body" hidden>
      <div class="panel-row"><p class="hint" id="field-parent"></p>
        <div class="seg seg-sm" id="field-kind" role="radiogroup">${radio('data-sevenths', 'false', 'fretboard.field.triads')}${radio('data-sevenths', 'true', 'fretboard.field.sevenths')}</div></div>
      <div class="chords" id="chords"></div>
      <p class="hint">${tx('fretboard.field.hint')}</p>
    </div>
    <div id="panel-intervals" class="panel-body" hidden>
      <div class="panel-row"><p class="hint" id="interval-reference"></p>
        <div class="panel-row-actions">
          <label class="check"><input type="checkbox" id="only-scale"><span>${tx('fretboard.intervals.onlyScale')}</span></label>
          <label class="check"><input type="checkbox" id="compound"><span>${tx('fretboard.intervals.compound')}</span></label>
          <button type="button" class="btn btn-ghost btn-sm" id="clear-reference" hidden>${tx('fretboard.intervals.clear')}</button>
        </div></div>
      <ul class="legend" id="legend"></ul>
    </div>
  </div>

  <div class="diagram-bar" id="diagram-bar" hidden>
    <div class="diagram-current"><strong id="diagram-title"></strong><span id="diagram-status" class="pill"></span><span id="diagram-counts" class="hint"></span></div>
    <div class="diagram-actions">
      <button type="button" id="diagram-new" class="btn btn-ghost btn-sm">${withIcon('plus', 'fretboard.draw.new')}</button>
      <button type="button" id="diagram-library" class="btn btn-ghost btn-sm">${withIcon('library', 'fretboard.draw.library')}<span class="count" id="diagrams-count">0</span></button>
      <button type="button" id="diagram-import" class="btn btn-ghost btn-sm">${withIcon('upload', 'fretboard.draw.import')}</button>
      <button type="button" id="diagram-share" class="btn btn-secondary btn-sm">${withIcon('share', 'fretboard.draw.share')}</button>
      <button type="button" id="diagram-save" class="btn btn-primary btn-sm">${withIcon('check', 'fretboard.draw.save')}</button>
    </div>
  </div>

  <dialog class="dialog form-dialog" id="save-dialog" aria-labelledby="save-title">
    <h2 id="save-title">${tx('fretboard.save.title')}</h2>
    <p>${tx('fretboard.save.text')}</p>
    <label class="field-label" for="save-name">${tx('fretboard.draw.name')}</label>
    <input id="save-name" class="input" maxlength="60" autocomplete="off" placeholder="${tx('fretboard.draw.namePlaceholder')}">
    <div class="dialog-actions">
      <button type="button" class="btn btn-ghost" value="cancel">${tx('common.cancel')}</button>
      <button type="button" class="btn btn-secondary" value="copy" id="save-copy">${tx('fretboard.draw.saveCopy')}</button>
      <button type="button" class="btn btn-primary" value="save" id="save-confirm">${tx('fretboard.draw.save')}</button>
    </div>
  </dialog>

  <dialog class="dialog list-dialog" id="library-dialog" aria-labelledby="library-title">
    <div class="dialog-head"><h2 id="library-title">${tx('fretboard.draw.library')}</h2><button type="button" class="icon-btn icon-btn-sm" value="cancel" title="${tx('common.close')}" aria-label="${tx('common.close')}">${svg('x', 16)}</button></div>
    <div class="input-group" id="diagrams-search-row" hidden>${svg('search')}<input id="diagrams-search" type="search" autocomplete="off" placeholder="${tx('fretboard.draw.search')}" aria-label="${tx('fretboard.draw.search')}"></div>
    <ul class="diagram-list" id="diagrams-list"></ul>
    <p class="hint" id="diagrams-no-results" hidden>${tx('fretboard.draw.noResults')}</p>
    <div class="empty" id="diagrams-empty" hidden><span class="empty-icon">${svg('fretboard', 22)}</span><strong>${tx('fretboard.draw.emptyTitle')}</strong><p>${tx('fretboard.draw.emptyText')}</p></div>
    <div class="dialog-actions"><button type="button" class="btn btn-ghost" id="diagrams-export">${withIcon('download', 'fretboard.draw.exportAll')}</button></div>
  </dialog>

  <dialog class="dialog form-dialog" id="import-dialog" aria-labelledby="import-title">
    <h2 id="import-title">${tx('fretboard.import.title')}</h2>
    <p>${tx('fretboard.import.text')}</p>
    <textarea id="import-code" class="input mono" rows="3" spellcheck="false" placeholder="${tx('fretboard.import.placeholder')}" aria-label="${tx('fretboard.import.title')}"></textarea>
    <div class="button-row"><button type="button" id="import-pick" class="btn btn-secondary btn-sm">${withIcon('upload', 'fretboard.import.pickFile')}</button><span class="hint" id="import-file-name"></span></div>
    <input type="file" id="import-file" accept=".loop,.json,application/json" hidden>
    <div class="import-preview" id="import-preview" hidden></div>
    <div class="notice" id="import-error" data-tone="danger" role="alert" hidden></div>
    <div class="dialog-actions">
      <button type="button" class="btn btn-ghost" value="cancel">${tx('common.cancel')}</button>
      <button type="button" class="btn btn-primary" value="import" id="import-confirm" disabled>${tx('fretboard.import.confirm')}</button>
    </div>
  </dialog>

  <dialog class="dialog form-dialog" id="share-dialog" aria-labelledby="share-title">
    <div class="dialog-head"><h2 id="share-title">${tx('fretboard.share.title')}</h2><button type="button" class="icon-btn icon-btn-sm" value="cancel" title="${tx('common.close')}" aria-label="${tx('common.close')}">${svg('x', 16)}</button></div>
    <p>${tx('fretboard.draw.shareHint')}</p>
    <label class="field-label" for="share-code">${tx('fretboard.draw.codeLabel')}</label>
    <textarea id="share-code" class="input mono code-output" rows="3" readonly></textarea>
    <div class="share-actions">
      <button type="button" id="share-copy" class="btn btn-primary btn-sm">${withIcon('copy', 'fretboard.draw.copyCode')}</button>
      <button type="button" id="share-file" class="btn btn-secondary btn-sm">${withIcon('download', 'fretboard.draw.downloadFile')}</button>
      <button type="button" id="share-png" class="btn btn-secondary btn-sm">${withIcon('image', 'fretboard.draw.downloadImage')}</button>
    </div>
    <p class="hint share-status" id="share-status" aria-live="polite"></p>
  </dialog>

  <dialog class="dialog" id="discard-dialog" aria-labelledby="discard-title">
    <h2 id="discard-title">${tx('fretboard.discard.title')}</h2>
    <p>${tx('fretboard.discard.text')}</p>
    <div class="dialog-actions">
      <button type="button" class="btn btn-ghost" value="cancel">${tx('fretboard.discard.keep')}</button>
      <button type="button" class="btn btn-secondary" value="discard">${tx('fretboard.discard.confirm')}</button>
      <button type="button" class="btn btn-primary" value="save">${tx('fretboard.discard.save')}</button>
    </div>
  </dialog>

${tabDialogsMarkup()}
${transcribeDialogsMarkup()}

  <div class="toast board-toast" id="toast" role="status" aria-live="polite" hidden></div>`;
}

function scaleOptions() {
  return SCALE_GROUPS.map((group) => `<optgroup label="${tx(`fretboard.group.${group.id}`)}">${group.scales.map((id) => `<option value="${id}">${tx(`fretboard.scales.${id}`)}</option>`).join('')}</optgroup>`).join('');
}

function sanitizeState(raw) {
  const value = raw && typeof raw === 'object' ? raw : {};
  const pick = (key, allowed) => (allowed.includes(value[key]) ? value[key] : DEFAULT_STATE[key]);
  return {
    mode: pick('mode', ['explore', 'draw', 'tab', 'transcribe']),
    root: Number.isInteger(value.root) && value.root >= 0 && value.root < 12 ? value.root : DEFAULT_STATE.root,
    scale: pick('scale', SCALE_IDS),
    labels: pick('labels', ['notes', 'degrees']),
    shape: Number.isInteger(value.shape) && value.shape >= 0 && value.shape <= 7 ? value.shape : 0,
    hand: pick('hand', ['right', 'left']),
    high: pick('high', ['top', 'bottom']),
    frets: pick('frets', FRET_CHOICES),
    tuning: pick('tuning', TUNING_IDS),
    panel: pick('panel', ['scale', 'field', 'intervals']),
    sevenths: value.sevenths === true,
    onlyScale: value.onlyScale === true,
    compound: value.compound !== false,
    allNotes: value.allNotes === true,
  };
}

// Extension pages and content scripts both reach chrome.storage; the static preview uses localStorage.
export function fretboardStorage(isExtension) {
  return {
    async read(key) {
      try {
        if (isExtension) return (await chrome.storage.local.get(key))[key];
        return JSON.parse(localStorage.getItem(key) || 'null');
      } catch { return null; }
    },
    write(key, value) {
      try {
        if (isExtension) chrome.storage.local.set({ [key]: value });
        else localStorage.setItem(key, JSON.stringify(value));
      } catch { /* Preferences are a convenience. */ }
    },
  };
}

/**
 * Builds the fretboard inside `board` and runs it.
 * @param {{board: HTMLElement, isExtension: boolean, layout?: 'page' | 'compact', onRender?: () => void}} options
 * @returns {Promise<{keydown: (event: KeyboardEvent) => void, summary: () => string, render: () => void}>}
 */
export async function mountFretboard({ board, isExtension, layout = 'page', onRender = () => {} }) {
  board.classList.add('board');
  board.dataset.layout = layout;
  setHTML(board, boardMarkup());
  attachTooltips(board);
  const $ = (selector) => board.querySelector(selector);
  const $$ = (selector) => [...board.querySelectorAll(selector)];
  const storage = fretboardStorage(isExtension);

  let state = sanitizeState(await storage.read(STATE_KEY));
  // The harmonic field always shows one chord, starting with the key's own (I).
  let chord = 0;
  let reference = null;
  let toastTimer;

  // `action` adds a button such as "Desfazer"; the toast then stays longer.
  function toast(message, { tone = '', action = null } = {}) {
    clearTimeout(toastTimer);
    const element = $('#toast');
    element.replaceChildren(document.createTextNode(message));
    if (action) {
      const button = Object.assign(document.createElement('button'), { type: 'button', className: 'toast-action', textContent: action.label });
      button.addEventListener('click', () => { element.hidden = true; action.run(); }, { once: true });
      element.append(button);
    }
    if (tone) element.dataset.tone = tone;
    else delete element.dataset.tone;
    element.hidden = false;
    toastTimer = setTimeout(() => { element.hidden = true; }, action ? 8000 : 4500);
  }

  const range = () => ({ from: 0, to: state.frets });
  const chordStyle = () => (getLocale() === 'pt-BR' ? 'br' : 'intl');
  const spelled = () => spellScale(state.root, state.scale);
  const quality = (semitones) => ([0, 5, 7].includes(semitones) ? 'perfect' : semitones === 6 ? 'tritone' : [2, 4, 9, 11].includes(semitones) ? 'major' : 'minor');
  const stringNumber = (string) => 6 - string;
  const nameFor = (pc) => spellPitch(pc, state.root, state.scale);
  const scaleTitle = () => t('fretboard.scaleName', { root: spelled().root, scale: t(`fretboard.scales.${state.scale}`) });
  const currentShape = () => (state.shape ? scaleShapes({ rootPc: state.root, scaleId: state.scale, tuning: state.tuning, range: range() }).find((item) => item.number === state.shape) : null);

  // Intervals start from the lowest tonic, nearest the nut; a click on another note moves the reference.
  function activeReference() {
    if (reference) return reference;
    const roots = scalePositions({ rootPc: state.root, scaleId: state.scale, tuning: state.tuning, range: range() }).filter((cell) => cell.root);
    return roots.sort((a, b) => a.midi - b.midi || a.fret - b.fret)[0] || { string: 0, fret: 0 };
  }

  function exploreDots() {
    const positions = scalePositions({ rootPc: state.root, scaleId: state.scale, tuning: state.tuning, range: range() });
    const strings = tuningStrings(state.tuning);
    if (state.panel === 'intervals') {
      const from = activeReference();
      const referenceMidi = strings[from.string] + from.fret;
      const cells = state.onlyScale ? positions : fretboardCells({ tuning: state.tuning, range: range() });
      return cells.map((cell) => {
        const isReference = cell.string === from.string && cell.fret === from.fret;
        const interval = intervalLabel(referenceMidi, cell.midi, { compound: state.compound });
        return {
          string: cell.string, fret: cell.fret,
          kind: isReference ? 'reference' : 'interval',
          quality: isReference ? undefined : quality(interval.simple),
          text: isReference ? nameFor(cell.pc) : interval.short,
          title: `${nameFor(cell.pc)} · ${t(`fretboard.interval.${interval.index}`)}`,
        };
      });
    }
    if (state.panel === 'field') {
      const selected = harmonicField({ rootPc: state.root, scaleId: state.scale, sevenths: state.sevenths, style: chordStyle() })[chord];
      if (selected) {
        const tones = new Map(selected.tones.map((pc, index) => [pc, index]));
        const inScale = new Set(positions.map((cell) => `${cell.string}:${cell.fret}`));
        return fretboardCells({ tuning: state.tuning, range: range() }).flatMap((cell) => {
          if (tones.has(cell.pc)) {
            const index = tones.get(cell.pc);
            return [{ string: cell.string, fret: cell.fret, kind: index === 0 ? 'root' : 'chord', text: state.labels === 'notes' ? nameFor(cell.pc) : selected.toneLabels[index], title: `${nameFor(cell.pc)} · ${selected.toneLabels[index]} · ${selected.symbol}` }];
          }
          return inScale.has(`${cell.string}:${cell.fret}`) ? [{ string: cell.string, fret: cell.fret, kind: 'ghost', text: '' }] : [];
        });
      }
    }
    const shape = currentShape();
    const inShape = shape ? new Set(shape.cells.map((cell) => `${cell.string}:${cell.fret}`)) : null;
    // "Todas as notas": every note of the neck by name, the scale's still highlighted.
    const inScale = new Set(positions.map((cell) => `${cell.string}:${cell.fret}`));
    const others = state.allNotes ? fretboardCells({ tuning: state.tuning, range: range() }).filter((cell) => !inScale.has(`${cell.string}:${cell.fret}`)).map((cell) => ({
      string: cell.string, fret: cell.fret, kind: 'ghost', text: nameFor(cell.pc),
      title: t('fretboard.noteOutside', { note: nameFor(cell.pc), string: stringNumber(cell.string), fret: cell.fret }),
    })) : [];
    return [...others, ...positions.map((cell) => ({
      string: cell.string, fret: cell.fret,
      kind: cell.root ? 'root' : 'scale',
      text: state.labels === 'notes' ? cell.name : cell.label,
      dim: inShape ? !inShape.has(`${cell.string}:${cell.fret}`) : false,
      title: t('fretboard.noteTitle', { note: cell.name, label: cell.label, string: stringNumber(cell.string), fret: cell.fret }),
    }))];
  }

  // What Explore shows (the scale, one shape, a chord or the intervals from a note) as a drawing to annotate.
  function drawingFromExplore() {
    const field = state.panel === 'field' ? harmonicField({ rootPc: state.root, scaleId: state.scale, sevenths: state.sevenths, style: chordStyle() })[chord] : null;
    const referenceCell = state.panel === 'intervals' ? activeReference() : null;
    const referencePc = referenceCell ? pitchClass(tuningStrings(state.tuning)[referenceCell.string] + referenceCell.fret) : null;
    const shape = !field && referencePc === null ? currentShape() : null;
    const marks = exploreDots().filter((dot) => !dot.dim && dot.kind !== 'ghost').map((dot) => ({
      string: dot.string, fret: dot.fret, color: ['root', 'reference'].includes(dot.kind) ? 0 : 4,
    }));
    return {
      name: field ? field.symbol : shape ? t('fretboard.draw.fromShape', { scale: scaleTitle(), number: shape.number }) : t('fretboard.draw.fromScale', { scale: scaleTitle() }),
      // Chord tones and intervals read from their own root; the scale stays in the background otherwise.
      root: referencePc ?? field?.rootPc ?? state.root,
      scale: field || referencePc !== null ? '' : state.scale,
      tuning: state.tuning,
      range: shape ? { from: Math.max(0, shape.from - 1), to: Math.min(state.frets, shape.to + 1) } : range(),
      labels: referencePc !== null || state.labels === 'degrees' ? 'degree' : 'note',
      marks,
      lines: [],
    };
  }

  function onCell(cell) {
    if (state.mode === 'draw') { editor.cell(cell); return; }
    if (state.mode === 'tab') { tabEditor.cell(cell); return; }
    if (state.mode === 'transcribe') { transcriber.cell(cell); return; }
    if (state.panel !== 'intervals') return;
    // Clicking the reference again goes back to the tonic.
    reference = reference && reference.string === cell.string && reference.fret === cell.fret ? null : cell;
    render();
  }

  const neck = createFretboard({ label: t('fretboard.neckLabel'), onCell });
  $('#neck').append(neck.element);
  const editor = await createEditor({ view: () => state, render, toast, isExtension, active: () => state.mode === 'draw', $, $$, imageHost: () => board });
  const tabEditor = await createTabEditor({ view: () => state, render, renderNeck: () => renderNeck(), toast, isExtension, active: () => state.mode === 'tab', $, $$ });
  // "Enviar para a Tablatura" opens the new tab in the Tab mode.
  const transcriber = await createTranscriber({ view: () => state, render, renderNeck: () => renderNeck(), toast, isExtension, active: () => state.mode === 'transcribe', $, $$, openTab: async (id) => { await tabEditor.show(id); update({ mode: 'tab' }); } });

  const setChecked = (selector, attribute, value) => {
    for (const button of $$(selector)) button.setAttribute('aria-checked', String(button.getAttribute(attribute) === String(value)));
  };

  function renderNeck() {
    if (state.mode === 'draw') { neck.render(editor.model()); return; }
    if (state.mode === 'tab') { neck.render(tabEditor.model()); return; }
    if (state.mode === 'transcribe') { neck.render(transcriber.model()); return; }
    neck.render({
      range: range(), leftHanded: state.hand === 'left', highOnTop: state.high === 'top', stringNames: tuningNames(state.tuning),
      interactive: state.panel === 'intervals', dots: exploreDots(), lines: [],
    });
  }

  function renderControls() {
    const exploring = state.mode === 'explore';
    const drawing = state.mode === 'draw';
    const writing = state.mode === 'tab';
    board.dataset.mode = state.mode;
    setChecked('#mode [data-mode]', 'data-mode', state.mode);
    $('#explore-controls').hidden = !exploring;
    $('#explore-panel').hidden = !exploring;
    $('#to-draw').hidden = !exploring;
    $('#draw-controls').hidden = !drawing;
    $('#diagram-bar').hidden = !drawing;
    for (const id of ['#tab-top', '#tab-sheet-wrap', '#tab-neck-head']) $(id).hidden = !writing;
    for (const id of ['#tr-top', '#tr-stage']) $(id).hidden = state.mode !== 'transcribe';
    $('#all-notes').checked = state.allNotes;

    $('#keys').replaceChildren(...Array.from({ length: 12 }, (_, pc) => {
      const button = Object.assign(document.createElement('button'), { type: 'button', className: 'chip', textContent: spellScale(pc, state.scale).root });
      button.setAttribute('role', 'radio');
      button.setAttribute('aria-checked', String(pc === state.root));
      button.dataset.root = String(pc);
      return button;
    }));
    $('#scale').value = state.scale;
    setChecked('#labels [data-labels]', 'data-labels', state.labels);
    setChecked('#hand [data-hand]', 'data-hand', state.hand);
    setChecked('#orientation [data-high]', 'data-high', state.high);
    setChecked('#field-kind [data-sevenths]', 'data-sevenths', state.sevenths);
    $('#frets').value = String(state.frets);
    // In Draw, each diagram has its own frets (in the toolbar) and tuning.
    $('#frets-field').hidden = drawing;
    $('#tuning').value = exploring || state.mode === 'transcribe' ? state.tuning : writing ? tabEditor.tuning() : editor.tuning();

    const shapes = isArpeggio(state.scale) ? [] : scaleShapes({ rootPc: state.root, scaleId: state.scale, tuning: state.tuning, range: range() }).sort((a, b) => a.number - b.number);
    if (state.shape && !shapes.some((shape) => shape.number === state.shape)) state.shape = 0;
    $('#shapes-control').hidden = !shapes.length;
    const all = Object.assign(document.createElement('button'), { type: 'button', className: 'chip', textContent: t('fretboard.shapes.all') });
    all.dataset.shape = '0';
    $('#shapes').replaceChildren(all, ...shapes.map((shape) => {
      const button = Object.assign(document.createElement('button'), { type: 'button', className: 'chip', textContent: String(shape.number), title: t('fretboard.shape', { number: shape.number, from: shape.from, to: shape.to }) });
      button.dataset.shape = String(shape.number);
      return button;
    }));
    for (const button of $$('#shapes [data-shape]')) {
      button.setAttribute('role', 'radio');
      button.setAttribute('aria-checked', String(Number(button.dataset.shape) === state.shape));
    }
    $('#shapes-label').title = shapes.length ? t('fretboard.shapes.hint', { count: shapes[0].cells.filter((cell) => cell.string === 0).length }) : '';
  }

  function renderPanels() {
    for (const tab of $$('[data-panel]')) tab.setAttribute('aria-selected', String(tab.dataset.panel === state.panel));
    for (const panel of ['scale', 'field', 'intervals']) $(`#panel-${panel}`).hidden = state.panel !== panel;

    $('#scale-name').textContent = scaleTitle();
    $('#scale-notes').replaceChildren(...spelled().names.map((name, index) => Object.assign(document.createElement('span'), { className: `note-chip${index === 0 ? ' is-root' : ''}`, textContent: name })));
    $('#scale-formula').textContent = degreeLabels(state.scale).join(' · ');
    const relative = ['major', 'majorPentatonic'].includes(state.scale) ? `${spellScale(pitchClass(state.root + 9), 'naturalMinor').root}m`
      : ['naturalMinor', 'minorPentatonic', 'blues'].includes(state.scale) ? spellScale(pitchClass(state.root + 3), 'major').root : '';
    $('#relative-row').hidden = !relative;
    $('#scale-relative').textContent = relative;

    const parent = parentScale(state.scale);
    $('#field-parent').textContent = t('fretboard.field.parent', { scale: t('fretboard.scaleName', { root: spellScale(state.root, parent).root, scale: t(`fretboard.scales.${parent}`) }) });
    const field = harmonicField({ rootPc: state.root, scaleId: state.scale, sevenths: state.sevenths, style: chordStyle() });
    $('#chords').replaceChildren(...field.map((item, index) => {
      const button = Object.assign(document.createElement('button'), { type: 'button', className: 'chord', title: t('fretboard.field.chordTitle', { symbol: item.symbol, notes: item.tones.map(nameFor).join(' ') }) });
      button.dataset.chord = String(index);
      button.setAttribute('aria-pressed', String(chord === index));
      button.append(Object.assign(document.createElement('small'), { textContent: item.roman }), Object.assign(document.createElement('strong'), { textContent: item.symbol }));
      return button;
    }));

    $('#only-scale').checked = state.onlyScale;
    $('#compound').checked = state.compound;
    $('#clear-reference').hidden = !reference;
    const from = activeReference();
    $('#interval-reference').textContent = t('fretboard.intervals.reference', { note: nameFor(pitchClass(tuningStrings(state.tuning)[from.string] + from.fret)), string: stringNumber(from.string), fret: from.fret });
    const legend = [...INTERVAL_SHORT.map((short, index) => ({ short, index, simple: index })),
      ...(state.compound ? COMPOUND_SHORT.slice(1).map((short, offset) => ({ short, index: 13 + offset, simple: (13 + offset) % 12 })) : [])];
    $('#legend').replaceChildren(...legend.map(({ short, index, simple }) => {
      const item = document.createElement('li');
      item.dataset.quality = quality(simple);
      item.append(Object.assign(document.createElement('b'), { textContent: short }), document.createTextNode(t(`fretboard.interval.${index}`)));
      return item;
    }));
  }

  function render() {
    renderControls();
    renderPanels();
    editor.render();
    tabEditor.render();
    transcriber.render();
    renderNeck();
    onRender();
  }

  function update(patch) {
    const scaleOrKeyChanged = ('scale' in patch && patch.scale !== state.scale) || ('root' in patch && patch.root !== state.root) || ('sevenths' in patch);
    state = { ...state, ...patch };
    if (scaleOrKeyChanged) { chord = 0; reference = null; }
    storage.write(STATE_KEY, state);
    render();
  }

  const onButton = (selector, attribute, callback) => $(selector).addEventListener('click', (event) => {
    const button = event.target.closest(`[${attribute}]`);
    if (button) callback(button.getAttribute(attribute));
  });
  onButton('#mode', 'data-mode', (mode) => update({ mode }));
  onButton('#keys', 'data-root', (root) => update({ root: Number(root) }));
  onButton('#labels', 'data-labels', (labels) => update({ labels }));
  onButton('#shapes', 'data-shape', (shape) => update({ shape: Number(shape) }));
  onButton('#hand', 'data-hand', (hand) => update({ hand }));
  onButton('#orientation', 'data-high', (high) => update({ high }));
  onButton('#field-kind', 'data-sevenths', (sevenths) => update({ sevenths: sevenths === 'true' }));
  onButton('.panel-tabs', 'data-panel', (panel) => update({ panel }));
  onButton('#chords', 'data-chord', (index) => {
    chord = Number(index);
    render();
  });
  $('#scale').addEventListener('change', (event) => update({ scale: event.target.value, shape: 0 }));
  $('#frets').addEventListener('change', (event) => update({ frets: Number(event.target.value) }));
  $('#tuning').addEventListener('change', (event) => {
    if (state.mode === 'draw') editor.setTuning(event.target.value);
    else if (state.mode === 'tab') tabEditor.setTuning(event.target.value);
    else update({ tuning: event.target.value });
  });
  $('#only-scale').addEventListener('change', (event) => update({ onlyScale: event.target.checked }));
  $('#compound').addEventListener('change', (event) => update({ compound: event.target.checked }));
  $('#all-notes').addEventListener('change', (event) => update({ allNotes: event.target.checked }));
  $('#clear-reference').addEventListener('click', () => { reference = null; render(); });
  $('#to-draw').addEventListener('click', async () => {
    if (await editor.open(drawingFromExplore())) update({ mode: 'draw' });
  });
  // The view menu opens under its button (CSS anchor positioning where available).
  $('#view-menu').addEventListener('beforetoggle', (event) => {
    if (event.newState !== 'open' || globalThis.CSS?.supports?.('position-anchor: --view')) return;
    const box = $('#view-toggle').getBoundingClientRect();
    const menu = $('#view-menu');
    menu.style.setProperty('top', `${Math.round(box.bottom + 6)}px`);
    menu.style.setProperty('right', `${Math.round(board.ownerDocument.defaultView.innerWidth - box.right)}px`);
  });
  const keydown = (event) => (state.mode === 'tab' ? tabEditor.keydown(event) : state.mode === 'transcribe' ? transcriber.keydown(event) : editor.keydown(event));
  board.addEventListener('keydown', keydown);

  render();
  return {
    keydown,
    render,
    toast,
    // One line for a minimized window.
    summary: () => (state.mode === 'draw' ? editor.title() : state.mode === 'tab' ? tabEditor.title() : state.mode === 'transcribe' ? transcriber.title() : scaleTitle()),
  };
}
