// The tab sheet's drawing: a canvas under the columns paints the strings, the measures (numbered, every other
// one shaded), bar lines, the selection, the column under the pointer, the cursor and the column playing, which
// glides to the next. The frets and the rhythm stay as text and SVG in the columns (sharp, readable by screen
// readers and by the tests); the canvas only reads where they are. A small overview of the whole section sits
// under the sheet when it is wider than the view: drag it, or click it, to move there.
const GLIDE_MS = 140;

function cssColor(style, name, fallback) {
  return style.getPropertyValue(name).trim() || fallback;
}

/**
 * @param {HTMLElement} sheet The scrolling row of columns (`.tab-col[data-index]`).
 * @param {HTMLElement} overview An empty element under the sheet for the overview.
 */
export function createSheetCanvas(sheet, overview) {
  const canvas = sheet.ownerDocument.createElement('canvas');
  canvas.className = 'tab-canvas';
  canvas.setAttribute('aria-hidden', 'true');
  sheet.before(canvas);
  const mini = sheet.ownerDocument.createElement('canvas');
  mini.className = 'tab-overview-canvas';
  mini.setAttribute('aria-hidden', 'true');
  overview.append(mini);

  let frame = 0;
  let hover = null;
  let glide = null; // the playhead moving from one column to the next: {from, to, start}
  let lastPlaying = null;
  const view = () => sheet.ownerDocument.defaultView;

  function schedule() {
    if (frame) return;
    try { frame = view().requestAnimationFrame(() => { frame = 0; draw(); }); } catch { frame = 0; }
  }

  function sizeCanvas(target, width, height) {
    const ratio = view().devicePixelRatio || 1;
    if (target.width !== Math.round(width * ratio) || target.height !== Math.round(height * ratio)) {
      target.width = Math.round(width * ratio);
      target.height = Math.round(height * ratio);
    }
    target.style.width = `${width}px`;
    target.style.height = `${height}px`;
    const context = target.getContext('2d');
    context.setTransform(ratio, 0, 0, ratio, 0, 0);
    return context;
  }

  // Where each column is, in the sheet's visible box.
  function layout() {
    const columns = [...sheet.querySelectorAll('.tab-col[data-index]')];
    // A string's height, from any column that has cells (bar lines have none).
    const cellHeight = sheet.querySelector('.tab-col[data-index] .tab-cell')?.offsetHeight || 21;
    return columns.map((node) => {
      const cells = node.querySelectorAll('.tab-cell');
      return {
        node,
        index: Number(node.dataset.index),
        x: node.offsetLeft - sheet.scrollLeft,
        y: node.offsetTop - sheet.scrollTop,
        width: node.offsetWidth,
        cell: cellHeight,
        bar: node.classList.contains('is-bar'),
        warn: Boolean(node.dataset.measure),
        current: node.dataset.current === 'true',
        selected: node.dataset.selected === 'true',
        playing: node.dataset.playing === 'true',
        end: node.classList.contains('tab-end') || node.classList.contains('tab-start'),
        texts: [...cells].map((cell) => cell.textContent),
        row: [...cells].findIndex((cell) => cell.dataset.row === 'true'),
      };
    });
  }

  const roundRect = (context, x, y, width, height, radius) => {
    context.beginPath();
    context.roundRect(x, y, width, height, radius);
  };

  function draw() {
    if (!sheet.isConnected) return;
    const width = sheet.clientWidth;
    const height = sheet.clientHeight;
    if (!width || !height) return;
    canvas.style.left = `${sheet.offsetLeft}px`;
    canvas.style.top = `${sheet.offsetTop}px`;
    const context = sizeCanvas(canvas, width, height);
    const style = view().getComputedStyle(sheet);
    const colors = {
      bg: cssColor(style, '--lp-bg', '#111'),
      shade: cssColor(style, '--lp-surface-2', '#1a1a1a'),
      line: cssColor(style, '--lp-tick', 'rgba(255,255,255,0.18)'),
      bar: cssColor(style, '--lp-text-2', '#aaa'),
      dim: cssColor(style, '--lp-text-3', '#888'),
      warn: cssColor(style, '--lp-warning-text', '#e5a50a'),
      accent: cssColor(style, '--lp-accent', '#c5f36b'),
      soft: cssColor(style, '--lp-accent-soft', 'rgba(197,243,107,0.16)'),
      hover: cssColor(style, '--lp-hover', 'rgba(255,255,255,0.06)'),
    };
    const font = view().getComputedStyle(sheet.querySelector('.tab-col:not(.tab-names)') || sheet).font;
    context.clearRect(0, 0, width, height);
    roundRect(context, 0, 0, width, height, 10);
    context.fillStyle = colors.bg;
    context.fill();
    context.save();
    roundRect(context, 0, 0, width, height, 10);
    context.clip();

    const columns = layout();
    // Rows: one in the normal sheet, several when the reading mode wraps it.
    const rows = [];
    for (const item of columns) {
      const row = rows.find((candidate) => Math.abs(candidate.y - item.y) < 4);
      if (row) row.items.push(item); else rows.push({ y: item.y, items: [item] });
    }
    const visible = (item) => item.x + item.width >= -40 && item.x <= width + 40;

    let measure = 1;
    for (const row of rows) {
      const first = row.items[0];
      const last = row.items.at(-1);
      const cell = first.cell;
      const top = row.y + cell / 2;
      const bottom = row.y + cell * 5.5;
      // Measures: every other one shaded, numbered at its start.
      let start = first.x;
      const shadeTo = (end) => {
        if (measure % 2 === 0) { context.fillStyle = colors.shade; context.globalAlpha = 0.55; context.fillRect(start, row.y, end - start, cell * 6); context.globalAlpha = 1; }
      };
      context.font = `600 10px ${style.getPropertyValue('--lp-font-mono') || 'monospace'}`;
      context.textBaseline = 'bottom';
      const label = (x) => { if (row.y - 1 > -10) { context.fillStyle = colors.dim; context.fillText(String(measure), x + 3, row.y + 1); } };
      label(start);
      for (const item of row.items) {
        if (!item.bar) continue;
        const middle = item.x + item.width / 2;
        shadeTo(middle);
        measure += 1;
        start = middle;
        label(start);
      }
      shadeTo(last.x + last.width);

      // Selection, hover, playing and the cursor, behind the strings.
      for (const item of row.items) {
        if (!visible(item)) continue;
        if (item.selected) { context.fillStyle = colors.soft; roundRect(context, item.x, item.y - 2, item.width, cell * 6 + 4, 4); context.fill(); }
        if (hover === item.index && !item.current) { context.fillStyle = colors.hover; roundRect(context, item.x, item.y - 2, item.width, cell * 6 + 4, 4); context.fill(); }
      }

      // The strings, broken where a fret is written.
      context.strokeStyle = colors.line;
      context.lineWidth = 1;
      context.font = font;
      for (let string = 0; string < 6; string++) {
        const y = Math.round(row.y + cell * (string + 0.5)) + 0.5;
        context.beginPath();
        let from = first.x;
        for (const item of row.items) {
          const text = item.texts[string];
          if (!text || item.bar) continue;
          const gap = context.measureText(text).width + 6;
          const middle = item.x + item.width / 2;
          context.moveTo(from, y);
          context.lineTo(middle - gap / 2, y);
          from = middle + gap / 2;
        }
        context.moveTo(from, y);
        context.lineTo(last.x + last.width, y);
        context.stroke();
      }

      // Bar lines (in the warning color when the measure does not add up).
      for (const item of row.items) {
        if (!item.bar || !visible(item)) continue;
        const x = Math.round(item.x + item.width / 2) + 0.5;
        context.strokeStyle = item.warn ? colors.warn : colors.bar;
        context.lineWidth = 2;
        context.beginPath();
        context.moveTo(x, top);
        context.lineTo(x, bottom);
        context.stroke();
      }
    }

    // The column playing: a glow that glides from the last one.
    const playing = columns.find((item) => item.playing);
    if (playing) {
      const now = view().performance.now();
      if (lastPlaying !== playing.index) {
        const from = columns.find((item) => item.index === lastPlaying);
        glide = from && Math.abs(from.y - playing.y) < 4 ? { from: from.x, start: now } : null;
        lastPlaying = playing.index;
      }
      let x = playing.x;
      if (glide) {
        const progress = Math.min(1, (now - glide.start) / GLIDE_MS);
        x = glide.from + (playing.x - glide.from) * (1 - (1 - progress) ** 3);
        if (progress < 1) schedule(); else glide = null;
      }
      context.save();
      context.shadowColor = colors.accent;
      context.shadowBlur = 14;
      context.fillStyle = colors.soft;
      roundRect(context, x, playing.y - 2, playing.width, playing.cell * 6 + 4, 5);
      context.fill();
      context.fillStyle = colors.accent;
      context.fillRect(x + 2, playing.y + playing.cell * 6 + 1, playing.width - 4, 3);
      context.restore();
    } else {
      lastPlaying = null;
      glide = null;
    }

    // The cursor: an outline, and the string the next number goes to.
    const current = columns.find((item) => item.current);
    if (current && visible(current)) {
      context.save();
      context.shadowColor = colors.accent;
      context.shadowBlur = 8;
      context.strokeStyle = colors.accent;
      context.lineWidth = 2;
      roundRect(context, current.x + 1, current.y - 1, current.width - 2, current.cell * 6 + 2, 5);
      context.stroke();
      context.restore();
      if (current.row >= 0) {
        context.fillStyle = colors.accent;
        context.fillRect(current.x + 5, current.y + current.cell * (current.row + 1) - 2, current.width - 10, 2);
      }
    }
    context.restore();
    drawOverview(columns, colors);
  }

  // The whole section in miniature: notes as dots on six lines, bars as ticks, the view as a window.
  // Shown only when the row is wider than the view; decided at once (frames may wait while the page is hidden).
  function showOverview() {
    overview.hidden = sheet.scrollWidth <= sheet.clientWidth + 4;
    return !overview.hidden;
  }

  function drawOverview(columns, colors) {
    const total = sheet.scrollWidth;
    const shown = sheet.clientWidth;
    if (!showOverview()) return;
    const width = overview.clientWidth;
    const height = overview.clientHeight;
    if (!width || !height) return;
    const context = sizeCanvas(mini, width, height);
    context.clearRect(0, 0, width, height);
    const scale = width / total;
    const lineGap = (height - 6) / 5;
    for (const item of columns) {
      const x = (item.x + sheet.scrollLeft + item.width / 2) * scale;
      if (item.bar) {
        context.fillStyle = item.warn ? colors.warn : colors.dim;
        context.fillRect(Math.round(x), 2, 1, height - 4);
        continue;
      }
      item.texts.forEach((text, line) => {
        if (!text) return;
        context.fillStyle = item.playing ? colors.accent : colors.bar;
        context.fillRect(Math.round(x) - 1, Math.round(3 + line * lineGap) - 1, 2, 2);
      });
    }
    const left = sheet.scrollLeft * scale;
    context.fillStyle = colors.soft;
    context.strokeStyle = colors.accent;
    context.lineWidth = 1.5;
    roundRect(context, left + 0.75, 0.75, Math.max(8, shown * scale) - 1.5, height - 1.5, 4);
    context.fill();
    context.stroke();
  }

  // The overview moves the sheet: dragging keeps the grab point, a click centers the view there.
  let drag = null;
  const scrollTo = (event, offset) => {
    const box = mini.getBoundingClientRect();
    const scale = sheet.scrollWidth / box.width;
    sheet.scrollLeft = (event.clientX - box.left) * scale - offset;
  };
  mini.addEventListener('pointerdown', (event) => {
    if (event.button !== 0) return;
    const box = mini.getBoundingClientRect();
    const scale = sheet.scrollWidth / box.width;
    const at = (event.clientX - box.left) * scale;
    const inside = at >= sheet.scrollLeft && at <= sheet.scrollLeft + sheet.clientWidth;
    drag = { id: event.pointerId, offset: inside ? at - sheet.scrollLeft : sheet.clientWidth / 2 };
    mini.setPointerCapture(event.pointerId);
    scrollTo(event, drag.offset);
  });
  mini.addEventListener('pointermove', (event) => { if (drag?.id === event.pointerId) scrollTo(event, drag.offset); });
  const end = (event) => { if (drag?.id === event.pointerId) drag = null; };
  mini.addEventListener('pointerup', end);
  mini.addEventListener('pointercancel', end);

  sheet.addEventListener('scroll', schedule, { passive: true });
  sheet.addEventListener('pointermove', (event) => {
    const index = event.target.closest?.('[data-index]')?.dataset.index;
    const next = index === undefined ? null : Number(index);
    if (next !== hover) { hover = next; schedule(); }
  });
  sheet.addEventListener('pointerleave', () => { if (hover !== null) { hover = null; schedule(); } });
  // A vertical wheel moves the single row sideways (the reading mode wraps and scrolls down as usual).
  sheet.addEventListener('wheel', (event) => {
    if (event.ctrlKey || event.metaKey || sheet.scrollWidth <= sheet.clientWidth + 4 || sheet.scrollHeight > sheet.clientHeight + 4) return;
    if (Math.abs(event.deltaY) <= Math.abs(event.deltaX)) return;
    event.preventDefault();
    sheet.scrollLeft += event.deltaY;
  }, { passive: false });

  // Sizes change with the window (and the window changes when the board pops out).
  let observed = null;
  const observe = () => {
    const View = view();
    if (observed === View || !View.ResizeObserver) return;
    observed = View;
    new View.ResizeObserver(schedule).observe(sheet);
  };

  return {
    draw() { observe(); showOverview(); schedule(); },
    /** Keeps a column in sight while playing: it moves the row so the column sits a quarter in. */
    follow(node) {
      if (!node) return;
      if (sheet.scrollWidth > sheet.clientWidth + 4 && (node.offsetLeft < sheet.scrollLeft || node.offsetLeft + node.offsetWidth > sheet.scrollLeft + sheet.clientWidth)) {
        sheet.scrollTo({ left: Math.max(0, node.offsetLeft - sheet.clientWidth * 0.25), behavior: 'smooth' });
      } else if (node.offsetTop < sheet.scrollTop || node.offsetTop + node.offsetHeight > sheet.scrollTop + sheet.clientHeight) {
        sheet.scrollTop = Math.max(0, node.offsetTop - 8);
      }
      schedule();
    },
  };
}
