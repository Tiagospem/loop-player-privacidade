// Drawn tooltips for a board: the name of a button shows under it on hover or keyboard focus. Native
// `title` tips do not show in the always-on-top window (and wait too long elsewhere), so a `title` found
// on hover becomes `data-tip`. Built with DOM nodes, so it works in closed shadow roots too.
const DELAY_MS = 350;

/** @param {HTMLElement} board an element with `position: relative` */
export function attachTooltips(board) {
  const tip = board.ownerDocument.createElement('div');
  tip.className = 'board-tip';
  tip.setAttribute('role', 'tooltip');
  tip.hidden = true;
  board.append(tip);
  let target = null;
  let timer = null;

  const hide = () => { clearTimeout(timer); target = null; tip.hidden = true; };
  function show(element) {
    const text = element.dataset.tip;
    if (!text || !board.contains(element) || element.closest('[popover]:not(:popover-open)')) return;
    tip.textContent = text;
    tip.hidden = false;
    const area = board.getBoundingClientRect();
    const box = element.getBoundingClientRect();
    const width = tip.offsetWidth;
    const left = Math.min(Math.max(4, box.left - area.left + box.width / 2 - width / 2), Math.max(4, area.width - width - 4));
    // Below the button, or above it near the bottom of the board.
    const below = box.bottom - area.top + 6;
    const top = below + tip.offsetHeight > area.height - 4 ? box.top - area.top - tip.offsetHeight - 6 : below;
    tip.style.setProperty('left', `${Math.round(left)}px`);
    tip.style.setProperty('top', `${Math.round(top)}px`);
  }
  function arm(event, delay) {
    const element = event.target.closest?.('[data-tip], [title]');
    if (!element || !board.contains(element) || element === target) return;
    if (element.hasAttribute('title')) {
      element.dataset.tip = element.getAttribute('title');
      element.removeAttribute('title');
    }
    target = element;
    clearTimeout(timer);
    tip.hidden = true;
    timer = setTimeout(() => { if (target === element) show(element); }, delay);
  }

  board.addEventListener('pointerover', (event) => arm(event, DELAY_MS));
  board.addEventListener('pointerout', (event) => { if (target && !target.contains(event.relatedTarget)) hide(); });
  board.addEventListener('focusin', (event) => { if (event.target.matches?.(':focus-visible')) arm(event, 0); });
  board.addEventListener('focusout', hide);
  board.addEventListener('pointerdown', hide);
  // A menu opening covers what the tip was about.
  board.addEventListener('toggle', hide, true);
  board.addEventListener('keydown', (event) => { if (event.key === 'Escape') hide(); });
  return { hide };
}
