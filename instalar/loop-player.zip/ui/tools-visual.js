// Animated look of the Tuner and Notes (Settings → Tuner and Notes look): Canvas 2D, no library.
// A spring pointer fills the 60 ms between readings, the in-tune zone glows and throws particles once
// the string holds in tune, "strobe" swaps the arc for drifting stripes, and Notes get a glow, a
// ripple per new note and the pitch trail of the last seconds. Text stays in the DOM; the canvas is
// decoration only. The loop sleeps when nothing moves and draws at most ~60 frames per second.
const clamp = (value, minimum, maximum) => Math.min(Math.max(value, minimum), maximum);
const approach = (value, target, rate, dt) => value + (target - value) * Math.min(1, rate * dt);
const TUNED = 3;
const LOCK_SECONDS = 0.25;
const SWEEP = (62 * Math.PI) / 180;
const FRAME_MS = 1000 / 62;
const TOKENS = ['accent', 'warning', 'text-2', 'text-3', 'surface-3', 'bg'];

/** Pointer in cents with inertia. Particle units: the gauge radius is 1, y points up. */
function createTunerMotion(reducedMotion) {
  const stiffness = reducedMotion ? 420 : 170;
  const damping = 2 * Math.sqrt(stiffness) * (reducedMotion ? 1 : 0.6);
  const state = { cents: 0, velocity: 0, target: 0, detected: false, presence: 0, tunedFor: 0, lock: 0, pulse: 1, strobe: 0, burst: false };
  let fired = false;
  return {
    state,
    update(reading) {
      state.detected = reading.detected;
      state.target = reading.detected ? clamp(reading.cents, -50, 50) : 0;
    },
    step(dt) {
      // Two half steps keep the spring stable on slow frames.
      for (let index = 0; index < 2; index++) {
        const h = dt / 2;
        state.velocity += (stiffness * (state.target - state.cents) - damping * state.velocity) * h;
        state.cents += state.velocity * h;
      }
      state.presence = approach(state.presence, state.detected ? 1 : 0, 9, dt);
      const tuned = state.detected && Math.abs(state.target) <= TUNED && Math.abs(state.cents) <= TUNED;
      state.tunedFor = tuned ? state.tunedFor + dt : 0;
      state.lock = approach(state.lock, state.tunedFor >= LOCK_SECONDS ? 1 : 0, 7, dt);
      state.burst = false;
      if (state.tunedFor >= LOCK_SECONDS && !fired) { fired = true; state.burst = true; state.pulse = reducedMotion ? 1 : 0; }
      if (!tuned && Math.abs(state.target) > TUNED * 2) fired = false;
      state.pulse = Math.min(1, state.pulse + dt / 0.7);
      // Strobe: stripes drift one period per second at 10 cents and stand still in tune.
      if (state.detected) state.strobe += state.cents * 0.1 * dt;
      return state;
    },
    moving() {
      return state.detected || Math.abs(state.velocity) > 0.02 || Math.abs(state.target - state.cents) > 0.02
        || Math.abs(state.presence - (state.detected ? 1 : 0)) > 0.01 || state.lock > 0.01 || state.pulse < 1;
    },
  };
}

/** Fixed pool, no allocation per frame. */
function createParticles(capacity) {
  const pool = { capacity, alive: 0, x: new Float32Array(capacity), y: new Float32Array(capacity), vx: new Float32Array(capacity), vy: new Float32Array(capacity), life: new Float32Array(capacity), span: new Float32Array(capacity).fill(1), size: new Float32Array(capacity) };
  let cursor = 0;
  let seed = 11;
  const random = () => { seed = (seed * 16807) % 2147483647; return seed / 2147483647; };
  // Burst from (ox, oy) upwards, within ±spread radians of vertical.
  pool.emit = (count, ox, oy, spread, speed) => {
    for (let index = 0; index < count; index++) {
      const slot = cursor;
      cursor = (cursor + 1) % capacity;
      const angle = Math.PI / 2 + (random() - 0.5) * 2 * spread;
      const velocity = speed * (0.35 + random() * 0.65);
      pool.x[slot] = ox + (random() - 0.5) * 0.08;
      pool.y[slot] = oy + (random() - 0.5) * 0.04;
      pool.vx[slot] = Math.cos(angle) * velocity;
      pool.vy[slot] = Math.sin(angle) * velocity;
      pool.span[slot] = 0.6 + random() * 0.6;
      pool.life[slot] = pool.span[slot];
      pool.size[slot] = 0.5 + random();
    }
  };
  pool.step = (dt) => {
    pool.alive = 0;
    const drag = Math.exp(-2.2 * dt);
    for (let index = 0; index < capacity; index++) {
      if (pool.life[index] <= 0) continue;
      pool.life[index] -= dt;
      pool.vx[index] *= drag;
      pool.vy[index] = pool.vy[index] * drag - 1.6 * dt;
      pool.x[index] += pool.vx[index] * dt;
      pool.y[index] += pool.vy[index] * dt;
      if (pool.life[index] > 0) pool.alive++;
    }
  };
  return pool;
}

/** Recent pitch (MIDI with cents as a fraction) as a scrolling trail. */
function createNotesMotion(reducedMotion, seconds = 4, capacity = 400) {
  const times = new Float64Array(capacity);
  const pitches = new Float32Array(capacity).fill(Number.NaN);
  const onsets = [];
  const state = { pitch: 0, target: 0, detected: false, presence: 0, cents: 0, center: 57, ripple: 1, latest: -Infinity, seconds, now: 0 };
  let head = 0;
  let count = 0;
  let pendingOnset = null;
  return {
    state, times, pitches, onsets,
    get count() { return count; },
    update(reading) {
      state.detected = reading.detected;
      state.cents = reading.cents;
      if (reading.detected) {
        // Jumps between notes snap; small pitch changes glide.
        if (!state.pitch || Math.abs(reading.midi - state.pitch) > 0.8) state.pitch = reading.midi;
        state.target = reading.midi;
      }
      if (reading.onset) pendingOnset = reading.label;
    },
    clear() { onsets.length = 0; count = 0; },
    step(now, dt) {
      state.now = now;
      state.pitch = approach(state.pitch, state.target, reducedMotion ? 40 : 18, dt);
      state.presence = approach(state.presence, state.detected ? 1 : 0, 10, dt);
      if (state.detected) {
        state.center = approach(state.center, state.target, 1.6, dt);
        state.latest = now;
      }
      state.ripple = Math.min(1, state.ripple + dt / 0.65);
      if (pendingOnset) {
        onsets.push({ time: now, pitch: state.target, label: pendingOnset });
        if (onsets.length > 12) onsets.shift();
        if (!reducedMotion) state.ripple = 0;
        pendingOnset = null;
      }
      while (onsets.length && now - onsets[0].time > seconds) onsets.shift();
      times[head] = now;
      pitches[head] = state.detected ? state.pitch : Number.NaN;
      head = (head + 1) % capacity;
      count = Math.min(capacity, count + 1);
    },
    // Index of the sample `back` steps before the newest.
    sample(back) { return (head - 1 - back + capacity * 2) % capacity; },
    moving() { return state.detected || state.now - state.latest < seconds + 0.2 || state.ripple < 1 || state.presence > 0.01; },
  };
}

// Computed colors arrive as rgb()/rgba() or, from color-mix(), as color(srgb r g b / a).
function parseColor(value) {
  const numbers = String(value).match(/[\d.]+/g)?.map(Number) || [0, 0, 0];
  if (String(value).startsWith('color(')) return { r: numbers[0] * 255, g: numbers[1] * 255, b: numbers[2] * 255, a: numbers[3] ?? 1 };
  return { r: numbers[0], g: numbers[1], b: numbers[2], a: numbers[3] ?? 1 };
}
const rgba = (color, alpha = 1) => `rgba(${Math.round(color.r)}, ${Math.round(color.g)}, ${Math.round(color.b)}, ${(color.a * alpha).toFixed(3)})`;
const mix = (from, to, amount) => ({ r: from.r + (to.r - from.r) * amount, g: from.g + (to.g - from.g) * amount, b: from.b + (to.b - from.b) * amount, a: from.a + (to.a - from.a) * amount });

/**
 * @param {{tunerCanvas: HTMLCanvasElement, notesCanvas: HTMLCanvasElement, probe: HTMLElement}} options
 * `probe` is an empty element inside the panel; colors are resolved through it, so the theme,
 * accent and light/dark "auto" of the shadow host or extension page all apply.
 */
export function createToolsVisual({ tunerCanvas, notesCanvas, probe }) {
  const view = () => probe.ownerDocument.defaultView;
  const reducedMotion = () => Boolean(view()?.matchMedia?.('(prefers-reduced-motion: reduce)').matches);
  const tuner = createTunerMotion(reducedMotion());
  const notes = createNotesMotion(reducedMotion());
  const particles = createParticles(96);
  let mode = 'classic';
  let tab = 'tuner';
  let active = false;
  let colors = null;
  let colorsKey = '';
  let frameHandle = 0;
  let frameWindow = null;
  let lastFrame = 0;
  let lastDrawn = 0;

  // Re-read the palette only when the theme, accent or system light/dark changes.
  function syncColors() {
    const root = probe.getRootNode();
    const owner = root.host || probe.ownerDocument.documentElement;
    const light = view()?.matchMedia?.('(prefers-color-scheme: light)').matches;
    const key = `${owner.getAttribute('data-theme')}|${owner.getAttribute('data-accent')}|${light}`;
    if (key === colorsKey && colors) return;
    colorsKey = key;
    const next = {};
    const style = view().getComputedStyle(probe);
    for (const token of TOKENS) {
      probe.style.setProperty('color', `var(--lp-${token})`);
      next[token] = parseColor(style.color);
    }
    probe.style.removeProperty('color');
    const bg = next.bg;
    next.light = (0.2126 * bg.r + 0.7152 * bg.g + 0.0722 * bg.b) / 255 > 0.5;
    next.font = style.getPropertyValue('--lp-font').trim() || 'system-ui, sans-serif';
    colors = next;
  }

  const canvas = () => (tab === 'notes' ? notesCanvas : tunerCanvas);

  // Matches the backing store to the element's size (it changes in Picture-in-Picture and stage mode).
  function prepare(target) {
    const width = target.clientWidth;
    const height = target.clientHeight;
    if (!width || !height) return null;
    const dpr = Math.min(2, view().devicePixelRatio || 1);
    const pixelWidth = Math.round(width * dpr);
    const pixelHeight = Math.round(height * dpr);
    if (target.width !== pixelWidth || target.height !== pixelHeight) { target.width = pixelWidth; target.height = pixelHeight; }
    const context = target.getContext('2d');
    context.setTransform(dpr, 0, 0, dpr, 0, 0);
    context.clearRect(0, 0, width, height);
    return { context, width, height };
  }

  function drawParticles(context, toX, toY) {
    if (!particles.alive) return;
    context.globalCompositeOperation = colors.light ? 'source-over' : 'lighter';
    context.fillStyle = rgba(colors.accent);
    for (let index = 0; index < particles.capacity; index++) {
      const life = particles.life[index];
      if (life <= 0) continue;
      const fade = life / particles.span[index];
      context.globalAlpha = fade * fade;
      const size = (1.2 + particles.size[index] * 1.6) * (0.6 + fade * 0.4);
      context.fillRect(toX(particles.x[index]) - size / 2, toY(particles.y[index]) - size / 2, size, size);
    }
    context.globalAlpha = 1;
    context.globalCompositeOperation = 'source-over';
  }

  function drawGauge({ context, width, height }, state) {
    const cx = width / 2;
    const cy = height - 30;
    const radius = Math.max(20, Math.min(width / 2 - 20, height - 40));
    const ring = Math.max(6, radius * 0.075);
    const angleFor = (cents) => -Math.PI / 2 + (cents / 50) * SWEEP;
    context.lineCap = 'round';

    context.lineWidth = ring;
    context.strokeStyle = rgba(colors['surface-3']);
    context.beginPath();
    context.arc(cx, cy, radius, angleFor(-50), angleFor(50));
    context.stroke();
    context.lineWidth = 1.5;
    for (let cents = -50; cents <= 50; cents += 10) {
      const angle = angleFor(cents);
      const inner = radius + ring / 2 + 4;
      const outer = inner + (cents === 0 ? 8 : cents % 50 === 0 ? 6 : 4);
      context.strokeStyle = rgba(cents === 0 ? colors['text-2'] : colors['text-3'], cents === 0 ? 0.9 : 0.6);
      context.beginPath();
      context.moveTo(cx + Math.cos(angle) * inner, cy + Math.sin(angle) * inner);
      context.lineTo(cx + Math.cos(angle) * outer, cy + Math.sin(angle) * outer);
      context.stroke();
    }
    // How far off: a filled arc from the center mark to the pointer.
    if (state.presence > 0.02 && Math.abs(state.cents) > TUNED) {
      context.lineWidth = ring;
      context.strokeStyle = rgba(colors.warning, 0.45 * state.presence);
      context.beginPath();
      context.arc(cx, cy, radius, Math.min(angleFor(0), angleFor(state.cents)), Math.max(angleFor(0), angleFor(state.cents)));
      context.stroke();
    }
    // In-tune zone: lights up and glows once locked.
    context.lineWidth = ring;
    context.strokeStyle = rgba(colors.accent, 0.35 + 0.65 * state.lock);
    if (state.lock > 0.02) { context.shadowColor = rgba(colors.accent, colors.light ? 0.5 : 0.9); context.shadowBlur = 18 * state.lock; }
    context.beginPath();
    context.arc(cx, cy, radius, angleFor(-TUNED), angleFor(TUNED));
    context.stroke();
    context.shadowBlur = 0;
    if (state.lock > 0.02) {
      const halo = context.createRadialGradient(cx, cy - radius, 0, cx, cy - radius, radius * 0.6);
      halo.addColorStop(0, rgba(colors.accent, (colors.light ? 0.22 : 0.3) * state.lock));
      halo.addColorStop(1, rgba(colors.accent, 0));
      context.fillStyle = halo;
      context.fillRect(0, 0, width, height);
    }
    if (state.pulse < 1) {
      context.lineWidth = 2;
      context.strokeStyle = rgba(colors.accent, (1 - state.pulse) * 0.8);
      context.beginPath();
      context.arc(cx, cy - radius, 6 + state.pulse * radius * 0.5, 0, Math.PI * 2);
      context.stroke();
    }
    // Pointer: a short blade on the ring with a glowing tip.
    const angle = angleFor(state.cents);
    const closeness = clamp(1 - (Math.abs(state.cents) - TUNED) / 10, 0, 1);
    const color = state.presence < 0.05 ? colors['text-3'] : mix(colors.warning, colors.accent, closeness);
    const alpha = 0.35 + 0.65 * state.presence;
    context.strokeStyle = rgba(color, alpha);
    context.lineWidth = Math.max(3, ring * 0.45);
    context.beginPath();
    context.moveTo(cx + Math.cos(angle) * (radius - ring * 2.2), cy + Math.sin(angle) * (radius - ring * 2.2));
    context.lineTo(cx + Math.cos(angle) * (radius + ring * 1.4), cy + Math.sin(angle) * (radius + ring * 1.4));
    context.stroke();
    context.fillStyle = rgba(color, alpha);
    if (state.presence > 0.05) { context.shadowColor = rgba(color, colors.light ? 0.45 : 0.85); context.shadowBlur = 10 + 8 * state.lock; }
    context.beginPath();
    context.arc(cx + Math.cos(angle) * radius, cy + Math.sin(angle) * radius, ring * 0.62, 0, Math.PI * 2);
    context.fill();
    context.shadowBlur = 0;
    drawParticles(context, (x) => cx + x * radius, (y) => cy - y * radius);
  }

  // Three stripe rows drifting at 1×, 2× and 3×, like a strobe tuner's harmonics.
  function drawStrobe({ context, width }, state) {
    const left = 14;
    const right = width - 14;
    const top = 14;
    const rowHeight = 15;
    const gap = 5;
    const period = 18;
    const bandHeight = rowHeight * 3 + gap * 2;
    const tuned = Math.abs(state.cents) <= TUNED && state.detected;
    const color = state.presence < 0.05 ? colors['text-3'] : tuned ? colors.accent : colors.warning;
    context.save();
    context.beginPath();
    context.roundRect(left, top, right - left, bandHeight, 8);
    context.clip();
    context.fillStyle = rgba(colors['surface-3'], 0.6);
    context.fillRect(left, top, right - left, bandHeight);
    context.fillStyle = rgba(color, 0.35 + 0.6 * state.presence);
    for (let row = 0; row < 3; row++) {
      const offset = ((((state.strobe * (row + 1)) % 1) + 1) % 1) * period;
      const y = top + row * (rowHeight + gap);
      for (let x = left - period + offset; x < right; x += period) context.fillRect(x, y, period / 2, rowHeight);
    }
    // Fade the ends out.
    context.globalCompositeOperation = 'destination-out';
    const fade = context.createLinearGradient(left, 0, right, 0);
    fade.addColorStop(0, 'rgba(0,0,0,1)');
    fade.addColorStop(0.18, 'rgba(0,0,0,0)');
    fade.addColorStop(0.82, 'rgba(0,0,0,0)');
    fade.addColorStop(1, 'rgba(0,0,0,1)');
    context.fillStyle = fade;
    context.fillRect(left, top, right - left, bandHeight);
    context.restore();
    context.fillStyle = rgba(colors['text-2'], 0.8);
    context.fillRect(width / 2 - 1, top - 6, 2, bandHeight + 12);
    if (state.lock > 0.02) {
      context.shadowColor = rgba(colors.accent, 0.9);
      context.shadowBlur = 16 * state.lock;
      context.strokeStyle = rgba(colors.accent, state.lock);
      context.lineWidth = 2;
      context.beginPath();
      context.roundRect(left, top, right - left, bandHeight, 8);
      context.stroke();
      context.shadowBlur = 0;
    }
    const unit = (right - left) / 2;
    drawParticles(context, (x) => width / 2 + x * unit, (y) => top + bandHeight / 2 - y * unit);
  }

  function drawNotes({ context, width, height }, now) {
    const state = notes.state;
    const noteY = 44;
    const tone = Math.abs(state.cents) <= TUNED * 3 ? colors.accent : colors.warning;
    if (state.presence > 0.02) {
      const glow = context.createRadialGradient(width / 2, noteY, 0, width / 2, noteY, 78);
      glow.addColorStop(0, rgba(tone, (colors.light ? 0.16 : 0.24) * state.presence));
      glow.addColorStop(1, rgba(tone, 0));
      context.fillStyle = glow;
      context.fillRect(0, 0, width, height);
    }
    if (state.ripple < 1) {
      context.lineWidth = 2;
      context.strokeStyle = rgba(colors.accent, (1 - state.ripple) * 0.7);
      context.beginPath();
      context.arc(width / 2, noteY, 30 + state.ripple * 60, 0, Math.PI * 2);
      context.stroke();
    }
    // Trail: the last few seconds, newest on the right, one semitone per guide line.
    const top = height - 58;
    const bottom = height - 8;
    const middle = (top + bottom) / 2;
    const semitone = (bottom - top) / 9;
    const left = 10;
    const right = width - 14;
    const xFor = (time) => right - ((now - time) / state.seconds) * (right - left);
    const yFor = (pitch) => clamp(middle - (pitch - state.center) * semitone, top, bottom);
    context.lineWidth = 1;
    context.strokeStyle = rgba(colors['text-3'], 0.14);
    for (let line = Math.ceil(state.center - 4.5); line <= state.center + 4.5; line++) {
      const y = yFor(line);
      context.beginPath();
      context.moveTo(left, y);
      context.lineTo(right, y);
      context.stroke();
    }
    const gradient = context.createLinearGradient(left, 0, right, 0);
    gradient.addColorStop(0, rgba(colors.accent, 0));
    gradient.addColorStop(1, rgba(colors.accent, 1));
    context.strokeStyle = gradient;
    context.lineWidth = 2.5;
    context.lineJoin = 'round';
    context.lineCap = 'round';
    context.beginPath();
    let drawing = false;
    for (let back = 0; back < notes.count; back++) {
      const index = notes.sample(back);
      const time = notes.times[index];
      if (now - time > state.seconds) break;
      const pitch = notes.pitches[index];
      if (Number.isNaN(pitch)) { drawing = false; continue; }
      if (drawing) context.lineTo(xFor(time), yFor(pitch)); else context.moveTo(xFor(time), yFor(pitch));
      drawing = true;
    }
    context.stroke();
    // Note names where each note started.
    context.font = `650 10px ${colors.font}`;
    context.textAlign = 'center';
    for (const onset of notes.onsets) {
      const age = (now - onset.time) / state.seconds;
      const x = xFor(onset.time);
      const y = yFor(onset.pitch);
      context.fillStyle = rgba(colors['text-2'], 1 - age);
      context.fillText(onset.label, x, Math.max(top - 2, y - 7));
      context.beginPath();
      context.arc(x, y, 2.5, 0, Math.PI * 2);
      context.fill();
    }
    if (state.presence > 0.02) {
      context.fillStyle = rgba(tone, state.presence);
      context.shadowColor = rgba(tone, colors.light ? 0.5 : 0.9);
      context.shadowBlur = 12;
      context.beginPath();
      context.arc(right, yFor(state.pitch), 4, 0, Math.PI * 2);
      context.fill();
      context.shadowBlur = 0;
    }
  }

  function frame(now) {
    frameHandle = 0;
    if (!running()) return;
    // ~60 frames per second is enough, also on 100–120 Hz screens.
    if (lastDrawn && now - lastDrawn < FRAME_MS) { frameHandle = frameWindow.requestAnimationFrame(frame); return; }
    const dt = lastFrame ? Math.min(0.05, (now - lastFrame) / 1000) : 1 / 60;
    lastFrame = now;
    lastDrawn = now;
    const seconds = now / 1000;
    let moving;
    if (tab === 'notes') {
      notes.step(seconds, dt);
      moving = notes.moving();
    } else {
      const state = tuner.step(dt);
      if (state.burst && !reducedMotion()) particles.emit(mode === 'strobe' ? 36 : 28, 0, mode === 'strobe' ? 0 : 1, mode === 'strobe' ? 1.4 : 1.1, mode === 'strobe' ? 1.1 : 1.4);
      particles.step(dt);
      moving = tuner.moving() || particles.alive > 0;
    }
    const target = prepare(canvas());
    // Hidden (minimized, another tab): nothing to draw; the next reading checks again.
    if (target) {
      syncColors();
      if (tab === 'notes') drawNotes(target, seconds);
      else if (mode === 'strobe') drawStrobe(target, tuner.state);
      else drawGauge(target, tuner.state);
    }
    if (moving && target) frameHandle = frameWindow.requestAnimationFrame(frame);
  }

  const running = () => active && mode !== 'classic' && tab !== 'metronome';

  function sleep() {
    if (frameHandle) frameWindow?.cancelAnimationFrame(frameHandle);
    frameHandle = 0;
  }

  function wake() {
    if (!running()) { sleep(); return; }
    // The panel may have moved to Picture-in-Picture: follow that window's frame clock.
    if (frameHandle && frameWindow === view()) return;
    sleep();
    frameWindow = view();
    if (!frameWindow) return;
    lastFrame = 0;
    lastDrawn = 0;
    frameHandle = frameWindow.requestAnimationFrame(frame);
  }

  return {
    get mode() { return mode; },
    setMode(next) {
      if (next === mode) return;
      mode = next;
      wake();
    },
    setTab(next) {
      tab = next;
      wake();
    },
    setActive(next) {
      active = Boolean(next);
      wake();
    },
    tuner(reading) {
      tuner.update(reading);
      if (tab === 'tuner') wake();
    },
    notes(reading) {
      notes.update(reading);
      if (tab === 'notes') wake();
    },
    clearNotes() { notes.clear(); },
    destroy() {
      active = false;
      sleep();
    },
  };
}
