/* Active passage drawn on the player's own progress bar, with draggable A and B handles.
   Runs in the player's frame (content.js). Built with DOM calls only: YouTube enforces
   Trusted Types, and a closed shadow root keeps the page's styles out. */

const MIN_LENGTH = 0.1;
const LOUPE_SPAN = 4; // seconds shown by the precision ruler while dragging
const LOUPE_WIDTH = 360;

const CSS = `
:host { all: initial; position: absolute; inset: 0; pointer-events: none; z-index: 61; contain: layout style; }
.track { position: absolute; display: none; }
.track[data-mode] { display: block; }
.band { position: absolute; top: 0; bottom: 0; border-radius: 3px; background: rgba(197, 243, 107, 0.42); box-shadow: inset 0 0 0 1.5px #c5f36b; }
.track[data-mode="slim"] .band { border-radius: 0; background: #c5f36b; box-shadow: none; opacity: 0.85; }
.track[data-mode="slim"] .handle, .track[data-mode="slim"] .grip, .track[data-mode="slim"] .label { display: none; }
.track[data-mode="own"] { border-radius: 3px; background: rgba(255, 255, 255, 0.28); }
.handle {
  position: absolute; top: 50%; width: 14px; height: 26px; margin: -13px 0 0 -7px; padding: 0; border: 0; border-radius: 5px;
  font: 700 10px/26px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif; color: #12180a; text-align: center;
  background: #c5f36b; box-shadow: 0 1px 6px rgba(0, 0, 0, 0.5); cursor: ew-resize; pointer-events: auto; touch-action: none; outline: none;
}
.handle:focus-visible { box-shadow: 0 0 0 2px #12180a, 0 0 0 4px #c5f36b; }
.grip {
  position: absolute; bottom: calc(100% + 9px); height: 18px; min-width: 30px; padding: 0 7px; margin-left: -15px; border: 0; border-radius: 9px;
  display: inline-flex; align-items: center; justify-content: center; gap: 4px;
  font: 700 10px/1 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif; color: #12180a;
  background: #c5f36b; box-shadow: 0 1px 6px rgba(0, 0, 0, 0.5); cursor: grab; pointer-events: auto; touch-action: none; outline: none;
  opacity: 0; transition: opacity 0.15s;
}
.grip:focus-visible { box-shadow: 0 0 0 2px #12180a, 0 0 0 4px #c5f36b; }
.track[data-hover="true"] .grip, .track[data-dragging] .grip, .grip:focus-visible { opacity: 1; }
.track[data-dragging] .grip { cursor: grabbing; }
.label {
  position: absolute; bottom: calc(100% + 32px); padding: 3px 6px; border-radius: 5px; transform: translateX(-50%);
  font: 600 11px/1.2 ui-monospace, "SF Mono", Menlo, Consolas, monospace; color: #f2f4ee; background: rgba(13, 15, 12, 0.92);
  white-space: nowrap; opacity: 0; transition: opacity 0.12s;
}
.track[data-hover="true"] .label { opacity: 1; }
.track[data-dragging] .label { opacity: 0; }
.loupe {
  position: absolute; display: none; width: ${LOUPE_WIDTH}px; height: 46px; border-radius: 8px; overflow: hidden;
  background: rgba(13, 15, 12, 0.94); box-shadow: 0 4px 18px rgba(0, 0, 0, 0.55), inset 0 0 0 1px rgba(255, 255, 255, 0.12);
}
.loupe[data-open] { display: block; }
.loupe-band { position: absolute; top: 8px; bottom: 16px; background: rgba(197, 243, 107, 0.3); }
.loupe-tick { position: absolute; bottom: 0; width: 1px; background: rgba(255, 255, 255, 0.35); }
.loupe-mark { position: absolute; top: 4px; bottom: 4px; width: 2px; margin-left: -1px; background: #c5f36b; }
.loupe-now { position: absolute; top: 0; bottom: 0; width: 2px; margin-left: -1px; background: #ff4d4d; }
.loupe-text { position: absolute; left: 8px; top: 5px; font: 600 10px/1 ui-monospace, "SF Mono", Menlo, Consolas, monospace; color: rgba(242, 244, 238, 0.7); }
`;

export function formatStripTime(seconds) {
  const value = Math.max(0, seconds);
  const minutes = Math.floor(value / 60);
  const rest = value - minutes * 60;
  return `${minutes}:${rest.toFixed(2).padStart(5, '0')}`;
}

// Pure geometry, exported for tests: the bounds after dragging `part` to `time`.
export function dragBounds(part, time, origin, duration) {
  const end = Number.isFinite(duration) && duration > 0 ? duration : Infinity;
  if (part === 'start') return {start: clamp(time, 0, origin.end - MIN_LENGTH), end: origin.end};
  if (part === 'end') return {start: origin.start, end: clamp(time, origin.start + MIN_LENGTH, end)};
  const length = origin.end - origin.start;
  const start = clamp(time, 0, Math.max(0, end - length));
  return {start, end: start + length};
}

function clamp(value, low, high) { return Math.min(Math.max(value, low), high); }
const round = (value) => Math.round(value * 100) / 100;

export function createTimelineStrip({labels, onCommit, onScrub}) {
  const host = document.createElement('loop-player-strip');
  const root = host.attachShadow({mode: 'closed'});
  const sheet = new CSSStyleSheet();
  sheet.replaceSync(CSS);
  root.adoptedStyleSheets = [sheet];
  const element = (tag, className, parent = root) => {
    const node = document.createElement(tag);
    if (className) node.className = className;
    parent.append(node);
    return node;
  };
  const track = element('div', 'track');
  const band = element('div', 'band', track);
  const handleA = element('button', 'handle', track);
  const handleB = element('button', 'handle', track);
  const grip = element('button', 'grip', track);
  const labelA = element('div', 'label', track);
  const labelB = element('div', 'label', track);
  const loupe = element('div', 'loupe');
  handleA.textContent = 'A';
  handleB.textContent = 'B';
  for (const [button, label] of [[handleA, labels.start], [handleB, labels.end], [grip, labels.move]]) {
    button.type = 'button';
    button.setAttribute('aria-label', label);
    button.setAttribute('role', 'slider');
  }

  let model = null; // {start, end, duration, currentTime, index, count}
  let drag = null; // {part, pointerId, origin, offset, bounds}
  let hover = false;
  let geometry = null;
  let keyTimer = null;
  let keyBounds = null;

  const shown = () => drag?.bounds || keyBounds || model;
  const timeAt = (clientX) => {
    if (!geometry || !model) return 0;
    return ((clientX - geometry.originX - geometry.left) / geometry.width) * model.duration;
  };
  const xAt = (time) => (model.duration > 0 ? (time / model.duration) * geometry.width : 0);

  function render() {
    if (!model || !geometry) { track.removeAttribute('data-mode'); loupe.removeAttribute('data-open'); return; }
    const {start, end} = shown();
    track.dataset.mode = geometry.mode;
    track.dataset.hover = String(hover || !!drag);
    if (drag) track.dataset.dragging = drag.part; else track.removeAttribute('data-dragging');
    Object.assign(track.style, {left: `${geometry.left}px`, top: `${geometry.top}px`, width: `${geometry.width}px`, height: `${geometry.height}px`});
    const a = xAt(start);
    const b = xAt(end);
    Object.assign(band.style, {left: `${a}px`, width: `${Math.max(2, b - a)}px`});
    handleA.style.left = `${a}px`;
    handleB.style.left = `${b}px`;
    grip.style.left = `${(a + b) / 2}px`;
    grip.textContent = model.count > 1 ? `⇔ ${model.index + 1}` : '⇔';
    // Labels stay inside the player, and apart when the passage is short.
    const edge = (x) => clamp(x, 44 - geometry.left, geometry.hostWidth - geometry.left - 44);
    const labelLeft = edge(a);
    labelA.style.left = `${labelLeft}px`;
    labelB.style.left = `${Math.max(edge(b), labelLeft + 92)}px`;
    labelA.textContent = `A ${formatStripTime(start)}`;
    labelB.textContent = `B ${formatStripTime(end)}`;
    for (const [button, value] of [[handleA, start], [handleB, end], [grip, start]]) {
      button.setAttribute('aria-valuenow', String(round(value)));
      button.setAttribute('aria-valuetext', formatStripTime(value));
    }
    renderLoupe(start, end);
  }

  // Precision ruler: ±2 s around the dragged edge, ticks every 0.1 s.
  function renderLoupe(start, end) {
    if (!drag || drag.part === 'move' || geometry.mode === 'slim') { loupe.removeAttribute('data-open'); return; }
    const focus = drag.part === 'start' ? start : end;
    const from = focus - LOUPE_SPAN / 2;
    const scale = LOUPE_WIDTH / LOUPE_SPAN;
    const at = (time) => (time - from) * scale;
    const left = clamp(geometry.left + xAt(focus) - LOUPE_WIDTH / 2, 4, geometry.hostWidth - LOUPE_WIDTH - 4);
    Object.assign(loupe.style, {left: `${left}px`, top: `${geometry.top - 92}px`});
    loupe.dataset.open = '';
    loupe.replaceChildren();
    const node = (className, style) => { const child = element('div', className, loupe); Object.assign(child.style, style); return child; };
    node('loupe-band', {left: `${clamp(at(start), 0, LOUPE_WIDTH)}px`, width: `${Math.max(0, clamp(at(end), 0, LOUPE_WIDTH) - clamp(at(start), 0, LOUPE_WIDTH))}px`});
    for (let tick = Math.ceil(from * 10); tick <= (from + LOUPE_SPAN) * 10; tick++) {
      const whole = tick % 10 === 0;
      node('loupe-tick', {left: `${at(tick / 10)}px`, height: whole ? '14px' : tick % 5 === 0 ? '9px' : '5px', opacity: whole ? '0.9' : '0.6'});
    }
    if (model.currentTime >= from && model.currentTime <= from + LOUPE_SPAN) node('loupe-now', {left: `${at(model.currentTime)}px`});
    node('loupe-mark', {left: `${at(focus)}px`});
    const text = node('loupe-text', {});
    text.textContent = `${drag.part === 'start' ? 'A' : 'B'} ${formatStripTime(focus)}`;
  }

  function begin(part, event) {
    if (!model || event.button !== 0) return;
    event.preventDefault();
    event.stopPropagation();
    const origin = {start: model.start, end: model.end};
    drag = {part, pointerId: event.pointerId, origin, offset: part === 'move' ? timeAt(event.clientX) - origin.start : 0, bounds: origin, fine: null};
    event.currentTarget.setPointerCapture?.(event.pointerId);
    render();
  }

  function move(event) {
    if (!drag || event.pointerId !== drag.pointerId) return;
    event.preventDefault();
    event.stopPropagation();
    // Shift slows the drag tenfold, for hundredths of a second.
    let time = timeAt(event.clientX) - drag.offset;
    if (event.shiftKey) {
      drag.fine ??= {x: event.clientX, time: drag.part === 'end' ? drag.bounds.end : drag.bounds.start};
      time = drag.fine.time + (timeAt(event.clientX) - timeAt(drag.fine.x)) / 10;
    } else {
      drag.fine = null;
    }
    drag.bounds = dragBounds(drag.part, time, drag.origin, model.duration);
    onScrub?.(drag.part === 'end' ? drag.bounds.end : drag.bounds.start, false);
    render();
  }

  function end(event) {
    if (!drag || event.pointerId !== drag.pointerId) return;
    event.preventDefault();
    event.stopPropagation();
    const finished = drag;
    drag = null;
    const changed = Math.abs(finished.bounds.start - finished.origin.start) > 0.004 || Math.abs(finished.bounds.end - finished.origin.end) > 0.004;
    if (changed) {
      model = {...model, start: round(finished.bounds.start), end: round(finished.bounds.end)};
      onCommit({start: model.start, end: model.end}, finished.part);
    }
    render();
  }

  function key(part, event) {
    if (!model || !['ArrowLeft', 'ArrowRight'].includes(event.key) || event.altKey || event.ctrlKey || event.metaKey) return;
    event.preventDefault();
    event.stopPropagation();
    const step = (event.key === 'ArrowLeft' ? -1 : 1) * (event.shiftKey ? 0.01 : 0.1);
    const origin = keyBounds || {start: model.start, end: model.end};
    const value = (part === 'end' ? origin.end : origin.start) + step;
    keyBounds = dragBounds(part, value, origin, model.duration);
    keyBounds = {start: round(keyBounds.start), end: round(keyBounds.end)};
    render();
    clearTimeout(keyTimer);
    // Several presses become one change, so the loop is not restarted at every step.
    keyTimer = setTimeout(() => {
      const bounds = keyBounds;
      keyBounds = null;
      if (!bounds) return;
      model = {...model, ...bounds};
      onCommit(bounds, part);
      render();
    }, 450);
  }

  for (const [button, part] of [[handleA, 'start'], [handleB, 'end'], [grip, 'move']]) {
    button.addEventListener('pointerdown', (event) => begin(part, event));
    button.addEventListener('pointermove', move);
    button.addEventListener('pointerup', end);
    button.addEventListener('pointercancel', end);
    button.addEventListener('lostpointercapture', end);
    button.addEventListener('keydown', (event) => key(part, event));
    // The player must not toggle playback or seek because of these clicks.
    for (const type of ['click', 'mousedown', 'mouseup', 'dblclick']) button.addEventListener(type, (event) => event.stopPropagation());
  }

  return {
    element: host,
    dragging: () => !!drag || !!keyBounds,
    setHover(value) { if (hover !== value) { hover = value; render(); } },
    // `place`: {parent, mode: 'bar' | 'own' | 'slim', rect: {left, top, width, height} relative to parent, originX, hostWidth}
    update(next, place) {
      if (!next || !place) {
        model = null;
        geometry = null;
        render();
        host.remove();
        return;
      }
      if (host.parentElement !== place.parent) place.parent.append(host);
      // While dragging, the page keeps its own bounds; ours win until the change is committed.
      model = drag || keyBounds ? {...next, start: model?.start ?? next.start, end: model?.end ?? next.end} : next;
      geometry = {...place.rect, mode: place.mode, originX: place.originX, hostWidth: place.hostWidth};
      render();
    },
    destroy() { clearTimeout(keyTimer); host.remove(); },
  };
}
