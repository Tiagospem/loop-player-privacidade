// Plays a tab with a synthesized guitar in the window that shows it (extension page, the floating
// window on a lesson page or Picture-in-Picture): no worklet, so no page's script policy is involved.
// Each pitch is rendered once with the Karplus-Strong plucked string into an AudioBuffer; a note is a
// buffer source whose detune glides (slides), rises (bends) or wavers (vibrato). Strings are monophonic:
// a new note on a string stops the one sounding there, but a note lets ring past its written length, so
// arpeggios and chords sound together as on a guitar. Three timbres (nylon, steel, clean electric) set the
// pluck, how fast the highs fade, the body's resonances and the room.
// The voice is replaceable: anything with `note(context, destination, planned, when)` and `release()`
// can play the plan, such as recorded samples of the player's own guitar (see ROADMAP).
const RENDER_SECONDS = 4;
const RELEASE = 0.04;
// After its written length a note fades over this long (time constant), unless its string plays again.
const LET_RING = 0.35;

/**
 * Timbres: `bright` is how much high noise the pluck has, `pick` where it plucks (0 = bridge), `ring` scales
 * how long a string sounds, `tone` the lowpass that closes from `from` to `to` Hz while the note rings,
 * `body` the resonances (Hz, gain dB, Q), `air` the shelf above 4 kHz and `room` the reverb.
 */
export const TIMBRES = Object.freeze({
  nylon: { bright: 0.32, pick: 0.2, ring: 0.8, tone: { from: 2800, to: 850, fade: 0.3 }, body: [[105, 6, 1.4], [210, 4, 1.2], [420, 1.5, 1.4]], air: -9, room: 0.22 },
  steel: { bright: 0.48, pick: 0.15, ring: 1, tone: { from: 4800, to: 1500, fade: 0.38 }, body: [[110, 4.5, 1.3], [230, 3, 1.2], [3000, -2, 1]], air: -6, room: 0.18 },
  electric: { bright: 0.42, pick: 0.11, ring: 1.35, tone: { from: 3800, to: 1900, fade: 0.6 }, body: [[140, 2, 1], [700, 2.5, 0.9], [2600, -3, 1.2]], air: -10, room: 0.12 },
});
export const TIMBRE_IDS = Object.freeze(Object.keys(TIMBRES));
const LOOKAHEAD = 0.25;
const TICK_MS = 40;

const frequency = (midi) => 440 * 2 ** ((midi - 69) / 12);

// A small repeatable noise, so the same note always sounds the same.
function noise(seed) {
  let state = (seed * 2654435761) >>> 0 || 1;
  return () => {
    state ^= state << 13; state >>>= 0;
    state ^= state >>> 17;
    state ^= state << 5; state >>>= 0;
    return state / 0xffffffff * 2 - 1;
  };
}

/**
 * Karplus-Strong: a noise burst circulates in a delay line one period long and is averaged each pass,
 * so high harmonics fade first, like a string. `soft` excites it gently (hammer-ons, slides);
 * `muted` damps it at once. Returns the samples and the playback rate that corrects the period's rounding.
 */
export function renderString(sampleRate, midi, { soft = false, muted = false, seconds = RENDER_SECONDS, timbre = TIMBRES.steel } = {}) {
  const target = frequency(midi);
  // The averaging filter damps short periods hard; weighting it toward one side ("stretch") keeps high
  // notes ringing. It also delays by `stretch` samples, which the period and the rate account for.
  const stretch = Math.min(0.5, Math.max(0.08, 0.5 * (200 / target) ** 0.7));
  const period = Math.max(2, Math.floor(sampleRate / target - stretch));
  const rate = target * (period + stretch) / sampleRate;
  const length = Math.round(sampleRate * (muted ? 0.18 : seconds));
  const data = new Float32Array(length);
  const line = new Float32Array(period);
  const random = noise(midi * 31 + (soft ? 7 : 0) + (muted ? 13 : 0));
  // Excitation: noise, smoothed twice (softer for legato and muted notes, and for the nylon), minus a copy
  // shifted by the pick's place on the string, which removes the harmonics that have a node there.
  let smooth = 0;
  let smoother = 0;
  const brightness = muted ? 0.12 : soft ? timbre.bright * 0.5 : timbre.bright;
  for (let index = 0; index < period; index++) {
    smooth += brightness * (random() - smooth);
    smoother += Math.min(1, brightness * 1.6) * (smooth - smoother);
    line[index] = smoother;
  }
  const pick = Math.max(1, Math.round(period * timbre.pick));
  const excited = line.map((value, index) => value - line[(index + pick) % period]);
  let peak = 0;
  for (const value of excited) peak = Math.max(peak, Math.abs(value));
  for (let index = 0; index < period; index++) line[index] = excited[index] / (peak || 1) * (soft ? 0.55 : 0.85);
  // Lower strings ring longer; a muted note dies in a few hundredths of a second.
  const ring = muted ? 0.04 : Math.min(6, Math.max(1.6, 5 * Math.sqrt(110 / target))) * timbre.ring;
  // Each sample passes the loss once per trip around the line: −60 dB after `ring` seconds.
  const loss = 10 ** (-3 * (period + stretch) / (sampleRate * ring));
  let position = 0;
  let previous = 0;
  for (let index = 0; index < length; index++) {
    const current = line[position];
    line[position] = loss * ((1 - stretch) * current + stretch * previous);
    previous = current;
    data[index] = current;
    position = (position + 1) % period;
  }
  // The highs fade faster than the lows: a lowpass that closes while the note rings (it changes the tone,
  // never the pitch, since it is outside the string's loop).
  const { from, to, fade } = timbre.tone;
  let low = 0;
  for (let index = 0; index < length; index++) {
    const cutoff = to + (from - to) * Math.exp(-index / (sampleRate * fade));
    const amount = 1 - Math.exp(-2 * Math.PI * Math.min(cutoff, sampleRate * 0.45) / sampleRate);
    low += amount * (data[index] - low);
    data[index] = low;
  }
  // A short fade-in removes the click of the first sample.
  for (let index = 0; index < Math.min(length, 48); index++) data[index] *= index / 48;
  return { data, rate };
}

/** The synthesized guitar voice. */
export function createGuitarVoice({ timbre = () => 'steel' } = {}) {
  const buffers = new Map();
  const strings = new Map(); // string → {source, gain}

  function buffer(context, midi, kind) {
    const name = TIMBRES[timbre()] ? timbre() : 'steel';
    const key = `${context.sampleRate}:${name}:${midi}:${kind}`;
    if (!buffers.has(key)) {
      const { data, rate } = renderString(context.sampleRate, midi, { soft: kind === 'soft', muted: kind === 'muted', timbre: TIMBRES[name] });
      const audio = context.createBuffer(1, data.length, context.sampleRate);
      audio.copyToChannel(data, 0);
      buffers.set(key, { audio, rate });
    }
    return buffers.get(key);
  }

  function stopString(string, when) {
    const playing = strings.get(string);
    if (!playing) return;
    playing.gain.gain.cancelScheduledValues(when);
    playing.gain.gain.setTargetAtTime(0, when, 0.008);
    try { playing.source.stop(when + 0.06); } catch { /* Already stopped. */ }
    strings.delete(string);
  }

  return {
    note(context, destination, planned, when) {
      stopString(planned.string, when);
      const { audio, rate } = buffer(context, planned.midi, planned.muted ? 'muted' : planned.legato ? 'soft' : 'pick');
      const source = context.createBufferSource();
      source.buffer = audio;
      source.playbackRate.value = rate;
      const gain = context.createGain();
      gain.gain.setValueAtTime(planned.legato ? 0.8 : 1, when);
      // The strings spread a little, low on the left and high on the right.
      const pan = context.createStereoPanner?.();
      if (pan) { pan.pan.value = ((planned.string ?? 2.5) - 2.5) / 2.5 * 0.3; source.connect(gain).connect(pan).connect(destination); }
      else source.connect(gain).connect(destination);
      const end = when + planned.duration;
      if (planned.slideFrom !== undefined) {
        source.detune.setValueAtTime((planned.slideFrom - planned.midi) * 100, when);
        source.detune.linearRampToValueAtTime(0, when + Math.min(0.18, planned.duration * 0.6));
      }
      if (planned.bend) {
        source.detune.setValueAtTime(0, when + planned.duration * 0.12);
        source.detune.linearRampToValueAtTime(planned.bend, when + Math.min(planned.duration * 0.55, 0.45));
      }
      if (planned.vibrato) {
        const wobble = context.createOscillator();
        const depth = context.createGain();
        wobble.frequency.value = 5.5;
        depth.gain.setValueAtTime(0, when);
        depth.gain.linearRampToValueAtTime(28, when + Math.min(0.3, planned.duration * 0.4));
        wobble.connect(depth).connect(source.detune);
        wobble.start(when);
        wobble.stop(end + RELEASE * 4);
      }
      // Written length over, the note keeps ringing and fades (muted notes stop); its string cuts it sooner.
      const fadeOut = planned.muted ? RELEASE : LET_RING;
      gain.gain.setTargetAtTime(0, end, fadeOut);
      source.start(when);
      source.stop(Math.min(end + fadeOut * 6, when + audio.duration / rate));
      const playing = { source, gain };
      strings.set(planned.string, playing);
      source.addEventListener('ended', () => { if (strings.get(planned.string) === playing) strings.delete(planned.string); });
    },
    release(when) {
      for (const string of [...strings.keys()]) stopString(string, when);
    },
  };
}

/**
 * Plays plans and tells where it is. The audio context belongs to this script's window and starts on the
 * first play (a click). Timers and animation frames run in `view()`, the window showing the tab now:
 * with the board in Picture-in-Picture, the page behind may be hidden and have its timers slowed.
 * @param {{voice?: ReturnType<typeof createGuitarVoice>, view?: () => Window}} options
 */
// A small room: two channels of noise fading out, darker as they fade.
function roomImpulse(context, seconds = 1.3) {
  const length = Math.round(context.sampleRate * seconds);
  const impulse = context.createBuffer(2, length, context.sampleRate);
  for (let channel = 0; channel < 2; channel++) {
    const random = noise(97 + channel * 11);
    const data = impulse.getChannelData(channel);
    let low = 0;
    for (let index = 0; index < length; index++) {
      const time = index / context.sampleRate;
      low += (0.5 - 0.4 * Math.min(1, time / seconds)) * (random() - low);
      data[index] = low * Math.exp(-time / 0.32) * (index < 240 ? index / 240 : 1);
    }
  }
  return impulse;
}

export function createTabPlayer({ view = () => globalThis, timbre: initialTimbre = 'steel' } = {}) {
  let timbre = TIMBRES[initialTimbre] ? initialTimbre : 'steel';
  const voice = createGuitarVoice({ timbre: () => timbre });
  let context = null;
  let output = null;
  let chain = null;
  let run = null;

  // The guitar's body (resonances), the highs tamed, a little room, and the peaks held in.
  function shape() {
    if (!chain) return;
    const profile = TIMBRES[timbre];
    chain.body.forEach((filter, index) => {
      const [frequency, gain, q] = profile.body[index];
      filter.frequency.value = frequency;
      filter.gain.value = gain;
      filter.Q.value = q;
    });
    chain.air.gain.value = profile.air;
    chain.wet.gain.value = profile.room;
  }

  function audio() {
    if (!context) {
      context = new globalThis.AudioContext({ latencyHint: 'interactive' });
      const input = context.createGain();
      const body = [0, 1, 2].map(() => { const filter = context.createBiquadFilter(); filter.type = 'peaking'; return filter; });
      const air = context.createBiquadFilter();
      air.type = 'highshelf';
      air.frequency.value = 4000;
      const top = context.createBiquadFilter();
      top.type = 'lowpass';
      top.frequency.value = 7500;
      top.Q.value = 0.5;
      const level = context.createGain();
      level.gain.value = 0.42;
      const limiter = context.createDynamicsCompressor();
      limiter.threshold.value = -12;
      limiter.ratio.value = 5;
      limiter.attack.value = 0.004;
      limiter.release.value = 0.2;
      const room = context.createConvolver();
      room.buffer = roomImpulse(context);
      const wet = context.createGain();
      input.connect(body[0]).connect(body[1]).connect(body[2]).connect(air).connect(top).connect(level);
      level.connect(limiter);
      level.connect(room).connect(wet).connect(limiter);
      limiter.connect(context.destination);
      chain = { body, air, wet };
      output = input;
      shape();
    }
    return context;
  }

  function stop() {
    if (!run) return;
    try { run.timerView.clearInterval(run.timer); } catch { /* The window closed. */ }
    try { run.frameView.cancelAnimationFrame(run.frame); } catch { /* The window closed. */ }
    clearInterval(run.watchdog);
    voice.release(context.currentTime);
    const { onStop } = run;
    run = null;
    onStop?.();
  }

  /**
   * @param {{events: object[], length: number}} plan from lib/tab-player.js
   * @param {{loop?: boolean, onEvent?: (event: object) => void, onStop?: () => void}} options
   */
  async function play(plan, { loop = false, onEvent, onStop } = {}) {
    stop();
    if (!plan.events.length || plan.length <= 0) return false;
    const ctx = audio();
    if (ctx.state !== 'running') await ctx.resume().catch(() => {});
    const state = { plan, loop, onEvent, onStop, start: ctx.currentTime + 0.08, scheduled: 0, pass: 0, shown: null, timer: 0, timerView: null, frame: 0, frameView: null };
    run = state;
    // Notes are handed to the audio clock a little ahead; the screen follows on animation frames.
    const schedule = () => {
      if (run !== state) return;
      const horizon = ctx.currentTime + LOOKAHEAD;
      for (;;) {
        if (state.scheduled >= plan.events.length) {
          if (!loop) break;
          state.scheduled = 0;
          state.pass++;
        }
        const event = plan.events[state.scheduled];
        const when = state.start + state.pass * plan.length + event.at;
        if (when > horizon) break;
        for (const note of event.notes) voice.note(ctx, output, note, Math.max(when, ctx.currentTime));
        state.scheduled++;
      }
      if (!loop && state.scheduled >= plan.events.length && ctx.currentTime > state.start + plan.length + 0.1) stop();
    };
    // The board may move between the page and Picture-in-Picture while playing; the timer follows it.
    const keepTimer = () => {
      const win = view();
      if (state.timerView === win) return;
      try { state.timerView?.clearInterval(state.timer); } catch { /* The window closed. */ }
      state.timerView = win;
      state.timer = win.setInterval(schedule, TICK_MS);
    };
    const follow = () => {
      if (run !== state) return;
      keepTimer();
      const elapsed = ctx.currentTime - state.start;
      if (elapsed >= 0) {
        const time = loop ? elapsed % plan.length : Math.min(elapsed, plan.length);
        let current = null;
        for (const event of plan.events) { if (event.at > time + 1e-6) break; current = event; }
        if (current && current !== state.shown) { state.shown = current; onEvent?.(current); }
      }
      state.frameView = view();
      state.frame = state.frameView.requestAnimationFrame(follow);
    };
    const watchFrames = () => {
      if (state.frameView === view()) return;
      state.frameView = view();
      state.frame = state.frameView.requestAnimationFrame(follow);
    };
    schedule();
    keepTimer();
    watchFrames();
    // If the window it ran in closes (Picture-in-Picture back to the page), this picks it up again.
    state.watchdog = setInterval(() => { keepTimer(); watchFrames(); schedule(); }, 200);
    return true;
  }

  return {
    play,
    stop,
    playing: () => Boolean(run),
    /** Changes the guitar (nylon, steel or electric); the next notes use it. */
    setTimbre(next) {
      if (!TIMBRES[next]) return;
      timbre = next;
      shape();
    },
    /** Sounds one note right away, as feedback when writing. */
    async preview(planned) {
      const ctx = audio();
      if (ctx.state !== 'running') await ctx.resume().catch(() => {});
      voice.note(ctx, output, planned, ctx.currentTime + 0.01);
    },
  };
}
