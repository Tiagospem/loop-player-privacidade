// Pages such as YouTube enforce Trusted Types; all markup set here is built from our own templates.
let policy;

export function setHTML(element, markup) {
  if (policy === undefined) {
    try { policy = globalThis.trustedTypes?.createPolicy?.('loop-player-overlay', { createHTML: (value) => value }) ?? null; }
    catch { policy = null; }
  }
  element.innerHTML = policy ? policy.createHTML(markup) : markup;
}

export function escapeHTML(value) {
  return String(value ?? '').replace(/[&<>"']/g, (character) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[character]);
}

/**
 * Puts an open popover under its button and inside the window (above the button when there is no room
 * below). It is measured where it lands and moved by the difference, so a page that zooms or widens its
 * document (some lesson pages do) cannot push it off screen.
 * @param {HTMLElement} menu An open popover.
 * @param {HTMLElement} trigger Its button.
 * @param {{align?: 'start' | 'end'}} options `end` lines its right edge up with the button's.
 */
export function placePopover(menu, trigger, { align = 'start' } = {}) {
  if (!menu.matches(':popover-open')) {
    // Before it shows: a first guess under the button, corrected once it can be measured.
    const anchor = trigger.getBoundingClientRect();
    for (const side of ['right', 'bottom']) menu.style.removeProperty(side);
    menu.style.setProperty('left', `${Math.round(align === 'end' ? Math.max(8, anchor.right - 240) : anchor.left)}px`);
    menu.style.setProperty('top', `${Math.round(anchor.bottom + 6)}px`);
    return;
  }
  const view = menu.ownerDocument.defaultView;
  for (const side of ['right', 'bottom']) menu.style.removeProperty(side);
  const at = (left, top) => { menu.style.setProperty('left', `${left}px`); menu.style.setProperty('top', `${top}px`); return menu.getBoundingClientRect(); };
  const origin = at(0, 0);
  const moved = at(100, 100);
  const scaleX = (moved.left - origin.left) / 100 || 1;
  const scaleY = (moved.top - origin.top) / 100 || 1;
  const anchor = trigger.getBoundingClientRect();
  const width = view.innerWidth;
  const height = view.innerHeight;
  let left = align === 'end' || anchor.left + origin.width > width - 8 ? anchor.right - origin.width : anchor.left;
  left = Math.max(8, Math.min(left, width - origin.width - 16));
  let top = anchor.bottom + 6;
  if (top + origin.height > height - 8 && anchor.top - 6 - origin.height >= 8) top = anchor.top - 6 - origin.height;
  at(Math.round((left - origin.left) / scaleX), Math.round((top - origin.top) / scaleY));
}
