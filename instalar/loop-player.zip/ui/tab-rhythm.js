// Rhythm drawn under the tab: a stem per note, beams joining eighths and sixteenths of the same beat,
// flags on loose ones, rests and the "3" of triplets (the layout comes from lib/tabs.js rhythmLayout).
// Built with createElementNS, never HTML text, so it works in the closed shadow root of lesson pages.
const NS = 'http://www.w3.org/2000/svg';
const STEM_TOP = 3;
const STEM_BOTTOM = 21;
const BEAM_GAP = 4;

function svgNode(documentRef, tag, attributes = {}, parent) {
  const node = documentRef.createElementNS(NS, tag);
  for (const [name, value] of Object.entries(attributes)) node.setAttribute(name, String(value));
  parent?.append(node);
  return node;
}

// Rests, centered on x = 0 of a nested svg placed at the middle of the column.
const RESTS = {
  w: (g, doc) => { svgNode(doc, 'line', { x1: -5, x2: 5, y1: 8, y2: 8 }, g); svgNode(doc, 'rect', { x: -3.5, y: 8, width: 7, height: 3.5, class: 'fill' }, g); },
  h: (g, doc) => { svgNode(doc, 'line', { x1: -5, x2: 5, y1: 12, y2: 12 }, g); svgNode(doc, 'rect', { x: -3.5, y: 8.5, width: 7, height: 3.5, class: 'fill' }, g); },
  q: (g, doc) => svgNode(doc, 'path', { d: 'M-1.5 3 L2 7 L-1.5 10.5 L2 14 Q-3 13 -0.5 18' }, g),
  e: (g, doc) => { svgNode(doc, 'circle', { cx: -1.5, cy: 8, r: 1.6, class: 'fill' }, g); svgNode(doc, 'path', { d: 'M-1.5 9.3 Q1.5 9.3 3 7 L-0.5 18' }, g); },
  s: (g, doc) => {
    svgNode(doc, 'circle', { cx: -1, cy: 6, r: 1.5, class: 'fill' }, g); svgNode(doc, 'path', { d: 'M-1 7.2 Q2 7.2 3.5 5 L-1.5 19' }, g);
    svgNode(doc, 'circle', { cx: -2.5, cy: 11, r: 1.5, class: 'fill' }, g); svgNode(doc, 'path', { d: 'M-2.5 12.2 Q0.5 12.2 2 10' }, g);
  },
};

/**
 * The rhythm of one column as an SVG that fills the column's width (stems sit in the middle, beams
 * run to the edges so neighbors join).
 * @param {Document} documentRef
 * @param {ReturnType<typeof import('../lib/tabs.js').rhythmLayout>[number]} item
 */
export function rhythmGlyph(documentRef, item) {
  const svg = svgNode(documentRef, 'svg', { class: 'tab-beat-svg', width: '100%', height: 30, 'aria-hidden': 'true' });
  if (!item || item.bar) return svg;
  const center = svgNode(documentRef, 'svg', { x: '50%', y: 0, overflow: 'visible' }, svg);
  if (item.rest) RESTS[item.d](center, documentRef);
  else if (item.d === 'w') svgNode(documentRef, 'ellipse', { cx: 0, cy: 10, rx: 4, ry: 2.8, transform: 'rotate(-20 0 10)' }, center);
  else {
    svgNode(documentRef, 'line', { x1: '50%', x2: '50%', y1: STEM_TOP, y2: STEM_BOTTOM }, svg);
    // A half note keeps a hollow head at the end of its stem, so it never reads as a quarter.
    if (item.d === 'h') svgNode(documentRef, 'ellipse', { cx: 0, cy: STEM_BOTTOM + 1, rx: 3.6, ry: 2.5, transform: `rotate(-20 0 ${STEM_BOTTOM + 1})` }, center);
    for (let level = 0; level < item.flags; level++) {
      const y = STEM_BOTTOM - level * BEAM_GAP;
      const beam = (x1, x2) => svgNode(documentRef, 'line', { x1, x2, y1: y, y2: y, class: 'beam' }, svg);
      if (level < item.beamLeft) beam('0%', '50%');
      if (level < item.beamRight) beam('50%', '100%');
      // Beamed on one side only for the main beam: the extra one is a short stub toward the neighbor.
      if (level >= item.beamLeft && level >= item.beamRight) {
        if (item.beamRight || item.beamLeft) {
          const toRight = item.beamRight > 0;
          svgNode(documentRef, 'line', { x1: 0, x2: toRight ? 6 : -6, y1: y, y2: y, class: 'beam' }, center);
        } else {
          svgNode(documentRef, 'path', { d: `M0 ${y} q5 -3 6 -9`, class: 'flag' }, center);
        }
      }
    }
  }
  if (item.dot) svgNode(documentRef, 'circle', { cx: 5, cy: item.rest ? 12 : STEM_BOTTOM - 2, r: 1.5, class: 'fill' }, center);
  if (item.triplet) {
    const label = svgNode(documentRef, 'text', { x: 0, y: 29.5, 'text-anchor': 'middle', class: 'tuplet' }, center);
    label.textContent = '3';
  }
  return svg;
}

// Small upright notes for the duration buttons (24 × 24, like the other icons).
const head = (filled) => `<ellipse cx="9" cy="18" rx="4.2" ry="3" transform="rotate(-20 9 18)"${filled ? ' fill="currentColor" stroke="none"' : ''}/>`;
const stem = '<path d="M13 17.5V4"/>';
const flag = (y) => `<path d="M13 ${y}c3 1.5 5 3.5 4 7"/>`;
export const DURATION_ICONS = Object.freeze({
  w: `<ellipse cx="12" cy="13" rx="5.5" ry="3.8" transform="rotate(-20 12 13)"/>`,
  h: `${head(false)}${stem}`,
  q: `${head(true)}${stem}`,
  e: `${head(true)}${stem}${flag(4)}`,
  s: `${head(true)}${stem}${flag(4)}${flag(8.5)}`,
});

export const durationIcon = (d, size = 18) => `<svg viewBox="0 0 24 24" width="${size}" height="${size}" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${DURATION_ICONS[d]}</svg>`;
