// Tab mode of the fretboard: write tablature by clicking the neck (or typing frets), in named sections.
// Columns can be selected, copied and pasted (also between tabs), and a tab, a section or a selection is
// shared with an `LPT1` code, a `.loop` file or as plain text. Tabs pasted as text from song sites are read too.
// The worker is the only writer of saved tabs (so every window shows the same ones); this page keeps
// only where the editor was and its own clipboard.
import { SCALE_GROUPS, MAX_FRET, STRING_COUNT, fretboardCells, pitchClass, scalePositions, spellPitch, spellScale, tuningNames, tuningStrings } from '../lib/theory.js';
import { TUNINGS } from '../lib/pitch.js';
import {
  MAX_COLUMNS, MAX_SECTIONS, MAX_TABS, MAX_TAB_NAME, MAX_SECTION_NAME, MUTED, TECHNIQUES,
  barColumn, column, noteCount, sectionNoteCount, containsOtherFretboardCode, containsTabCode, createTabFile, decodeTabCode, encodeTabCode, hasColumns, isBar, isRest,
  DEFAULT_DURATION, DURATIONS, MAX_BPM, MIN_BPM, meterText, normalizeBpm, rhythmLayout, sectionTempo, transposeColumns,
  guessTabTitle, isTranscription, newSectionId, normalizeColumn, normalizeSection, normalizeTab, parseAsciiTab, parseTabFile, sameTab, sanitizeTabs, tabFileName, tabToAscii,
} from '../lib/tabs.js';
import { MAX_FILE_BYTES } from '../lib/share.js';
import { pageStorage, tabStore } from './tab-store.js';
import { t } from '../lib/i18n.js';
import { ask } from './dialogs.js';
import { icon } from './icons.js';
import { escapeHTML, placePopover } from './html.js';
import { durationIcon, rhythmGlyph } from './tab-rhythm.js';
import { PLAY_SCOPES, PLAY_SPEEDS, playbackPlan } from '../lib/tab-player.js';
import { TIMBRE_IDS, createTabPlayer } from './tab-audio.js';
import { tabPng } from './tab-image.js';
import { createSheetCanvas } from './tab-canvas.js';
import { TAB_EXAMPLES, exampleTab } from '../lib/tab-examples.js';

const EDITOR_KEY = 'loopPlayer.tabEditor.v1';
const SAVE_DELAY_MS = 400;
const CLIPBOARD_KEY = 'loopPlayer.tabClipboard.v1';
const HISTORY_LIMIT = 100;
const tx = (key, params) => escapeHTML(t(key, params));
const svg = (name, size = 14) => icon(name, { size });
const element = (tag, properties = {}) => Object.assign(document.createElement(tag), properties);
const fold = (text) => text.normalize('NFD').replace(/\p{M}/gu, '').toLowerCase();
const withIcon = (name, label) => `${svg(name)}<span>${tx(label)}</span>`;
const iconButton = (id, name, label, extra = '') => `<button type="button" class="icon-btn${extra}" id="${id}" title="${tx(label)}" aria-label="${tx(label)}">${svg(name, 16)}</button>`;
const METERS = ['2/4', '3/4', '4/4', '5/4', '6/4', '2/2', '3/8', '6/8', '7/8', '9/8', '12/8'];
const TECH_LABELS = { '': 'fretboard.tab.tech.plain', h: 'fretboard.tab.tech.h', p: 'fretboard.tab.tech.p', '/': 'fretboard.tab.tech.slideUp', '\\': 'fretboard.tab.tech.slideDown', b: 'fretboard.tab.tech.b', '~': 'fretboard.tab.tech.vibrato', x: 'fretboard.tab.tech.muted' };

// A button whose name shows as a drawn tooltip (ui/tooltip.js), also in Picture-in-Picture.
const tool = (id, content, label, { extra = '', attrs = '' } = {}) => `<button type="button" class="icon-btn${extra}" id="${id}" data-tip="${tx(label)}" aria-label="${tx(label)}"${attrs}>${content}</button>`;
const menuItem = (id, iconName, label, extra = '') => `<button type="button" class="tab-menu-item" id="${id}" role="menuitem">${iconName ? svg(iconName, 16) : '<span class="tab-menu-blank"></span>'}<span>${tx(label)}</span>${extra}</button>`;
const REST_ICON = '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M10 3l4 5-4 4 4 4c-3-1-5 1-3 5"/></svg>';

// The top of the Tab mode: the tab (name, saved, tempo, share), one toolbar and the sections as tabs.
export function tabControlsMarkup() {
  return `
  <div class="tab-top" id="tab-top" hidden>
    <div class="tab-doc">
      <button type="button" class="tab-doc-library" id="tab-library" data-tip="${tx('fretboard.tab.library')}" aria-label="${tx('fretboard.tab.library')}">${svg('library', 16)}<span class="count" id="tabs-count">0</span></button>
      <input id="tab-name" class="tab-name" maxlength="${MAX_TAB_NAME}" autocomplete="off" placeholder="${tx('fretboard.tab.namePlaceholder')}" aria-label="${tx('fretboard.tab.name')}">
      <span class="tab-status" id="tab-status" role="status"></span>
      <span class="tab-counts" id="tab-counts"></span>
      <span class="bar-spacer"></span>
      <button type="button" class="tab-tempo" id="tab-tempo" data-tip="${tx('fretboard.tab.tempoHint')}"></button>
      <button type="button" class="btn btn-secondary btn-sm" id="tab-share">${withIcon('share', 'fretboard.tab.share')}</button>
    </div>
    <div class="tab-toolbar" id="tab-controls" role="toolbar" aria-label="${tx('fretboard.tab.toolbar')}">
      <span class="tab-group tab-play-group">
        <button type="button" class="btn btn-primary btn-sm tab-play" id="tab-play" aria-pressed="false" data-tip="${tx('fretboard.tab.play.hint')}"><span class="tab-play-start">${svg('play')}<span>${tx('fretboard.tab.play.start')}</span></span><span class="tab-play-stop" hidden>${svg('stop')}<span>${tx('fretboard.tab.play.stop')}</span></span></button>
        ${tool('tab-play-options', svg('chevronDown', 14), 'fretboard.tab.play.options', { extra: ' tab-caret', attrs: ' popovertarget="tab-play-menu"' })}
        ${tool('tab-loop', svg('repeat', 16), 'fretboard.tab.play.loopHint', { attrs: ' aria-pressed="false"' })}
      </span>
      <span class="tab-reading-tools">
        ${tool('tab-zoom-out', '<b>A−</b>', 'fretboard.tab.reading.smaller')}
        ${tool('tab-zoom-in', '<b>A+</b>', 'fretboard.tab.reading.bigger')}
        <button type="button" class="btn btn-ghost btn-sm" id="tab-reading-exit">${tx('fretboard.tab.reading.off')}</button>
      </span>
      <span class="tab-sep" aria-hidden="true"></span>
      <span class="tab-group tab-edit">
        <span class="seg seg-icons tab-durations" id="tab-duration" role="radiogroup" aria-label="${tx('fretboard.tab.rhythm')}">
          ${DURATIONS.map((d) => `<button type="button" role="radio" data-duration="${d}" data-tip="${tx(`fretboard.tab.duration.${d}`)}" aria-label="${tx(`fretboard.tab.duration.${d}`)}">${durationIcon(d)}</button>`).join('')}
        </span>
        ${tool('tab-dot', '<b>•</b>', 'fretboard.tab.dotted', { extra: ' tab-flag', attrs: ' aria-pressed="false"' })}
        ${tool('tab-triplet', '<b>3</b>', 'fretboard.tab.triplet', { extra: ' tab-flag', attrs: ' aria-pressed="false"' })}
        ${tool('tab-tie', '<b>‿</b>', 'fretboard.tab.tie', { extra: ' tab-flag', attrs: ' aria-pressed="false"' })}
      </span>
      <span class="tab-sep" aria-hidden="true"></span>
      <span class="seg seg-icons tab-techs" id="tab-tech" role="radiogroup" aria-label="${tx('fretboard.tab.technique')}">
        ${Object.entries(TECH_LABELS).filter(([tech]) => tech).map(([tech, label]) => `<button type="button" role="radio" data-tech="${escapeHTML(tech)}" data-tip="${tx(`${label}Hint`)}" aria-label="${tx(label)}"><b>${tech === '' ? '♪' : escapeHTML(tech)}</b></button>`).join('')}
      </span>
      <span class="tab-sep" aria-hidden="true"></span>
      <span class="tab-group">
        <button type="button" class="btn btn-ghost btn-sm tab-chord" id="tab-chord" aria-pressed="false" data-tip="${tx('fretboard.tab.chordHint')}">${tx('fretboard.tab.chord')}</button>
        ${tool('tab-bar', '<b>|</b>', 'fretboard.tab.barHint')}
        ${tool('tab-rest', REST_ICON, 'fretboard.tab.restHint')}
      </span>
      <span class="bar-spacer"></span>
      ${tool('tab-undo', svg('undo', 16), 'fretboard.draw.undo')}${tool('tab-redo', svg('redo', 16), 'fretboard.draw.redo')}
      ${tool('tab-more', svg('more', 16), 'fretboard.tab.more', { attrs: ' popovertarget="tab-more-menu"' })}
    </div>
    <div class="tab-menu" id="tab-play-menu" popover>
      <span class="tab-menu-label">${tx('fretboard.tab.play.scope')}</span>
      <div class="seg seg-sm" id="tab-play-scope" role="radiogroup" aria-label="${tx('fretboard.tab.play.scope')}">
        ${PLAY_SCOPES.map((scope) => `<button type="button" role="radio" data-play-scope="${scope}">${tx(`fretboard.tab.scope.${scope}`)}</button>`).join('')}
      </div>
      <label class="check tab-menu-check"><input type="checkbox" id="tab-loop-check"><span>${tx('fretboard.tab.play.loop')}</span></label>
      <label class="tab-menu-label" for="tab-speed">${tx('fretboard.tab.play.speed')}</label>
      <select id="tab-speed" class="input input-sm">${PLAY_SPEEDS.map((speed) => `<option value="${speed}">${Math.round(speed * 100)}%</option>`).join('')}</select>
      <span class="tab-menu-label">${tx('fretboard.tab.play.timbre')}</span>
      <div class="seg seg-sm" id="tab-timbre" role="radiogroup" aria-label="${tx('fretboard.tab.play.timbre')}">
        ${TIMBRE_IDS.map((id) => `<button type="button" role="radio" data-timbre="${id}">${tx(`fretboard.tab.timbre.${id}`)}</button>`).join('')}
      </div>
    </div>
    <div class="tab-menu" id="tab-more-menu" popover role="menu">
      <span class="tab-menu-narrow">
        ${menuItem('tab-undo-item', 'undo', 'fretboard.draw.undo')}
        ${menuItem('tab-redo-item', 'redo', 'fretboard.draw.redo')}
        <span class="tab-menu-sep"></span>
      </span>
      ${menuItem('tab-new', 'plus', 'fretboard.tab.newTab')}
      ${menuItem('tab-import', 'upload', 'fretboard.tab.import')}
      ${menuItem('tab-examples', 'tab', 'fretboard.tab.examples.open')}
      <span class="tab-menu-sep"></span>
      ${menuItem('tab-copy', 'copy', 'fretboard.tab.copy')}
      ${menuItem('tab-paste', 'download', 'fretboard.tab.paste')}
      ${menuItem('tab-delete', 'trash', 'fretboard.tab.deleteColumns')}
      <span class="tab-menu-sep"></span>
      ${menuItem('tab-transpose', '', 'fretboard.tab.transpose.title')}
      ${menuItem('tab-reading', 'expand', 'fretboard.tab.reading.on')}
    </div>
    <div class="tab-sections-bar">
      <div class="tab-sections" role="tablist" aria-label="${tx('fretboard.tab.sections')}" id="tab-sections"></div>
      ${tool('tab-add-section', svg('plus', 14), 'fretboard.tab.addSectionHint')}
      <span class="bar-spacer"></span>
      ${tool('tab-section-more', svg('more', 16), 'fretboard.tab.sectionMenu', { attrs: ' popovertarget="tab-section-menu"' })}
    </div>
    <div class="tab-menu" id="tab-section-menu" popover role="menu">
      ${menuItem('tab-section-rename', 'pen', 'fretboard.tab.rename')}
      ${menuItem('tab-section-copy', 'copy', 'fretboard.tab.duplicate')}
      ${menuItem('tab-section-left', 'chevronLeft', 'fretboard.tab.moveLeft')}
      ${menuItem('tab-section-right', 'chevronRight', 'fretboard.tab.moveRight')}
      <span class="tab-menu-sep"></span>
      ${menuItem('tab-section-delete', 'trash', 'fretboard.tab.deleteSection')}
    </div>
  </div>`;
}

// The sheet with its status line, then the header of the neck, which the board's grid places under the sheet
// (the neck itself belongs to the board).
export function tabSheetMarkup() {
  const scaleOptions = SCALE_GROUPS.map((group) => `<optgroup label="${tx(`fretboard.group.${group.id}`)}">${group.scales.map((id) => `<option value="${id}">${tx(`fretboard.scales.${id}`)}</option>`).join('')}</optgroup>`).join('');
  return `
  <div class="tab-sheet-wrap" id="tab-sheet-wrap" hidden>
    <div class="tab-sheet" id="tab-sheet" tabindex="0" role="grid" aria-label="${tx('fretboard.tab.sheet')}"></div>
    <div class="tab-overview" id="tab-overview" data-tip="${tx('fretboard.tab.overview')}" hidden></div>
    <div class="tab-status-line">
      <span id="tab-position"></span>
      <span class="bar-spacer"></span>
      <span id="tab-hint" class="hint"></span>
    </div>
  </div>
  <div class="tab-neck-head" id="tab-neck-head" hidden>
    <button type="button" class="tab-neck-toggle" id="tab-neck-toggle" aria-expanded="true">${svg('chevronDown', 14)}<span>${tx('fretboard.tab.neck')}</span></button>
    <label class="sr-only" for="tab-background">${tx('fretboard.tab.background')}</label>
    <select id="tab-key" class="input input-sm" aria-label="${tx('fretboard.key')}" data-tip="${tx('fretboard.key')}"></select>
    <select id="tab-background" class="input input-sm" data-tip="${tx('fretboard.tab.background')}"><option value="">${tx('fretboard.draw.backgroundNone')}</option><option value="all">${tx('fretboard.allNotes')}</option>${scaleOptions}</select>
    <span class="bar-spacer"></span>
    <span class="hint" id="tab-neck-hint">${tx('fretboard.tab.neckHint')}</span>
  </div>
`;
}

export function tabDialogsMarkup() {
  const close = `<button type="button" class="icon-btn icon-btn-sm" value="cancel" title="${tx('common.close')}" aria-label="${tx('common.close')}">${svg('x', 16)}</button>`;
  return `
  <dialog class="dialog list-dialog" id="tab-examples-dialog" aria-labelledby="tab-examples-title">
    <div class="dialog-head"><h2 id="tab-examples-title">${tx('fretboard.tab.examples.title')}</h2>${close}</div>
    <p class="hint">${tx('fretboard.tab.examples.intro')}</p>
    <ul class="diagram-list" id="tab-examples-list"></ul>
  </dialog>

  <dialog class="dialog list-dialog" id="tab-library-dialog" aria-labelledby="tab-library-title">
    <div class="dialog-head"><h2 id="tab-library-title">${tx('fretboard.tab.library')}</h2>${close}</div>
    <div class="input-group">${svg('search')}<input id="tabs-search" type="search" autocomplete="off" placeholder="${tx('fretboard.tab.search')}" aria-label="${tx('fretboard.tab.search')}"></div>
    <ul class="diagram-list" id="tabs-list"></ul>
    <p class="hint" id="tabs-no-results" hidden>${tx('fretboard.tab.noResults')}</p>
    <div class="empty" id="tabs-empty" hidden><span class="empty-icon">${svg('tab', 22)}</span><strong>${tx('fretboard.tab.emptyTitle')}</strong><p>${tx('fretboard.tab.emptyText')}</p></div>
    <div class="dialog-actions"><button type="button" class="btn btn-ghost" id="tabs-export">${withIcon('download', 'fretboard.tab.exportAll')}</button></div>
  </dialog>

  <dialog class="dialog form-dialog" id="tab-import-dialog" aria-labelledby="tab-import-title">
    <h2 id="tab-import-title">${tx('fretboard.tab.importTitle')}</h2>
    <p>${tx('fretboard.tab.importText')}</p>
    <textarea id="tab-import-text" class="input mono" rows="7" spellcheck="false" placeholder="${tx('fretboard.tab.importPlaceholder')}" aria-label="${tx('fretboard.tab.importTitle')}"></textarea>
    <div class="button-row"><button type="button" id="tab-import-pick" class="btn btn-secondary btn-sm">${withIcon('upload', 'fretboard.import.pickFile')}</button><span class="hint" id="tab-import-file-name"></span></div>
    <input type="file" id="tab-import-file" accept=".loop,.json,application/json" hidden>
    <div class="import-preview" id="tab-import-preview" hidden></div>
    <div class="notice" id="tab-import-error" data-tone="danger" role="alert" hidden></div>
    <div class="dialog-actions">
      <button type="button" class="btn btn-ghost" value="cancel">${tx('common.cancel')}</button>
      <button type="button" class="btn btn-secondary" value="insert" id="tab-import-insert" disabled>${tx('fretboard.tab.importInsert')}</button>
      <button type="button" class="btn btn-primary" value="new" id="tab-import-new" disabled>${tx('fretboard.tab.importNew')}</button>
    </div>
  </dialog>

  <dialog class="dialog form-dialog tab-share-dialog" id="tab-share-dialog" aria-labelledby="tab-share-title">
    <div class="dialog-head"><h2 id="tab-share-title">${tx('fretboard.tab.shareTitle')}</h2>${close}</div>
    <div class="seg seg-sm" id="tab-share-scope" role="radiogroup" aria-label="${tx('fretboard.tab.shareScope')}">
      <button type="button" role="radio" data-scope="tab">${tx('fretboard.tab.scope.tab')}</button>
      <button type="button" role="radio" data-scope="section">${tx('fretboard.tab.scope.section')}</button>
      <button type="button" role="radio" data-scope="selection">${tx('fretboard.tab.scope.selection')}</button>
    </div>
    <p class="tab-share-summary" id="tab-share-summary"></p>
    <section class="tab-share-group" aria-labelledby="tab-share-users">
      <h3 id="tab-share-users">${tx('fretboard.tab.share.users')}</h3>
      <p class="hint">${tx('fretboard.tab.share.usersHint')}</p>
      <textarea id="tab-share-code" class="input mono code-output" rows="3" readonly aria-label="${tx('fretboard.tab.codeLabel')}"></textarea>
      <div class="notice" id="tab-share-too-long" data-tone="warning" hidden>${tx('fretboard.tab.share.tooLong')}</div>
      <div class="share-actions">
        <button type="button" id="tab-share-copy" class="btn btn-primary btn-sm">${withIcon('copy', 'fretboard.draw.copyCode')}</button>
        <button type="button" id="tab-share-file" class="btn btn-secondary btn-sm">${withIcon('download', 'fretboard.draw.downloadFile')}</button>
      </div>
    </section>
    <section class="tab-share-group" aria-labelledby="tab-share-anyone">
      <div class="tab-share-text-head"><h3 id="tab-share-anyone">${tx('fretboard.tab.share.anyone')}</h3>
        <label class="check" id="tab-share-rhythm-row"><input type="checkbox" id="tab-share-rhythm" checked><span>${tx('fretboard.tab.rhythmLine')}</span></label></div>
      <textarea id="tab-share-text" class="input mono tab-text-output" rows="7" readonly aria-label="${tx('fretboard.tab.asText')}"></textarea>
      <div class="share-actions">
        <button type="button" id="tab-share-copy-text" class="btn btn-secondary btn-sm">${withIcon('copy', 'fretboard.tab.copyText')}</button>
        <button type="button" id="tab-share-png" class="btn btn-secondary btn-sm">${withIcon('image', 'fretboard.draw.downloadImage')}</button>
      </div>
    </section>
    <p class="hint share-status" id="tab-share-status" aria-live="polite"></p>
  </dialog>

  <dialog class="dialog form-dialog" id="tab-transpose-dialog" aria-labelledby="tab-transpose-title">
    <h2 id="tab-transpose-title">${tx('fretboard.tab.transpose.title')}</h2>
    <p>${tx('fretboard.tab.transpose.text')}</p>
    <div class="tab-transpose-row">
      <button type="button" class="icon-btn" data-transpose="-1" title="${tx('fretboard.tab.transpose.down')}" aria-label="${tx('fretboard.tab.transpose.down')}">${svg('minus', 16)}</button>
      <output id="tab-transpose-value" class="tab-transpose-value">0</output>
      <button type="button" class="icon-btn" data-transpose="1" title="${tx('fretboard.tab.transpose.up')}" aria-label="${tx('fretboard.tab.transpose.up')}">${svg('plus', 16)}</button>
      <div class="seg seg-sm" id="tab-transpose-scope" role="radiogroup" aria-label="${tx('fretboard.tab.shareScope')}">
        <button type="button" role="radio" data-scope="tab">${tx('fretboard.tab.scope.tab')}</button>
        <button type="button" role="radio" data-scope="section">${tx('fretboard.tab.scope.section')}</button>
        <button type="button" role="radio" data-scope="selection">${tx('fretboard.tab.scope.selection')}</button>
      </div>
    </div>
    <p class="hint" id="tab-transpose-preview" aria-live="polite"></p>
    <div class="dialog-actions">
      <button type="button" class="btn btn-ghost" value="cancel">${tx('common.cancel')}</button>
      <button type="button" class="btn btn-primary" value="apply" id="tab-transpose-apply">${tx('fretboard.tab.transpose.apply')}</button>
    </div>
  </dialog>

  <dialog class="dialog form-dialog" id="tab-tempo-dialog" aria-labelledby="tab-tempo-title">
    <h2 id="tab-tempo-title">${tx('fretboard.tab.tempoTitle')}</h2>
    <div class="tab-tempo-fields">
      <label class="field-label" for="tab-bpm">${tx('fretboard.tab.bpm')}</label>
      <label class="field-label" for="tab-meter">${tx('fretboard.tab.meter')}</label>
      <input id="tab-bpm" class="input" type="number" min="${MIN_BPM}" max="${MAX_BPM}" step="1" inputmode="numeric">
      <select id="tab-meter" class="input">${METERS.map((meter) => `<option value="${meter}">${meter}</option>`).join('')}</select>
    </div>
    <label class="check"><input type="checkbox" id="tab-tempo-section"><span id="tab-tempo-section-label"></span></label>
    <p class="hint">${tx('fretboard.tab.tempoText')}</p>
    <div class="dialog-actions">
      <button type="button" class="btn btn-ghost" value="cancel">${tx('common.cancel')}</button>
      <button type="button" class="btn btn-primary" value="save">${tx('fretboard.draw.save')}</button>
    </div>
  </dialog>

  <dialog class="dialog form-dialog" id="tab-rename-dialog" aria-labelledby="tab-rename-title">
    <h2 id="tab-rename-title">${tx('fretboard.tab.renameTitle')}</h2>
    <input id="tab-rename-name" class="input" maxlength="${MAX_SECTION_NAME}" autocomplete="off">
    <div class="chips tab-name-suggestions" id="tab-name-suggestions"></div>
    <div class="dialog-actions">
      <button type="button" class="btn btn-ghost" value="cancel">${tx('common.cancel')}</button>
      <button type="button" class="btn btn-primary" value="save">${tx('fretboard.draw.save')}</button>
    </div>
  </dialog>`;
}

function download(blob, name) {
  const url = URL.createObjectURL(blob);
  const link = element('a', { href: url, download: name });
  document.body.append(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}

async function writeClipboard(text, field) {
  const view = field.ownerDocument.defaultView;
  try { await view.navigator.clipboard.writeText(text); return true; } catch {
    field.focus();
    field.select();
    try { return field.ownerDocument.execCommand('copy'); } catch { return false; }
  }
}

/**
 * @param {{view: () => object, render: () => void, toast: Function, isExtension: boolean, active: () => boolean, $: Function, $$: Function}} options
 */
export async function createTabEditor({ view, render, renderNeck = render, toast, isExtension, active, $, $$ }) {
  const store = tabStore(isExtension);
  const storage = pageStorage(isExtension);
  const place = (await storage.read(EDITOR_KEY)) || {};
  // Transcriptions (tabs tied to a video) belong to the Transcribe mode.
  const own = (list) => list.filter((item) => !isTranscription(item));
  let tabs = own(await store.list().catch(() => []));
  const blank = (tuning = 'standard') => normalizeTab({ tuning, sections: [{ name: t('fretboard.tab.firstSection') }] });
  let tab = tabs.find((item) => item.id === place.currentId) || tabs[0] || blank();
  let sectionIndex = Math.min(Math.max(0, Number(place.sectionIndex) || 0), tab.sections.length - 1);
  let cursor = section().columns.length - 1; // the current column; −1 before the first
  let anchor = null; // the other end of a selection
  let row = 0; // the string the keyboard writes on (0 = low string)
  let tech = '';
  let chordMode = false;
  let chordOpen = false; // in chord mode, the cursor's column is the chord being written
  let duration = { d: DEFAULT_DURATION, dot: false, tri: false }; // of the next columns
  let picked = false; // the cursor's column was chosen in the sheet (not just written), so durations change it
  let key = Number.isInteger(place.key) && place.key >= 0 && place.key < 12 ? place.key : 9;
  // Playback: what to play, repeat and speed are remembered; the playhead is the column sounding now.
  let playScope = PLAY_SCOPES.includes(place.playScope) ? place.playScope : 'section';
  let loop = place.loop === true;
  let speed = PLAY_SPEEDS.includes(place.speed) ? place.speed : 1;
  let timbre = TIMBRE_IDS.includes(place.timbre) ? place.timbre : 'steel';
  let playhead = null;
  const player = createTabPlayer({ view: () => $('#tab-sheet').ownerDocument.defaultView, timbre });
  // The sheet is one row that scrolls sideways, drawn on a canvas under the columns.
  const sheetCanvas = createSheetCanvas($('#tab-sheet'), $('#tab-overview'));
  // Reading: a big sheet without the editing controls, for playing along (in the always-on-top window too).
  let reading = place.reading === true;
  // The neck under the sheet can fold away while reading or editing with the keyboard.
  let neckOpen = place.neckOpen !== false;
  let readingSize = Number.isInteger(place.readingSize) && place.readingSize >= 0 && place.readingSize <= 4 ? place.readingSize : 2;
  let background = typeof place.background === 'string' ? place.background : 'all';
  let typed = null; // digits typed for a two-digit fret
  let saveTimer = null;
  let dirty = false; // edits the worker has not saved yet
  let saving = 0; // saves on their way to the worker
  let syncedAt = tab.updatedAt; // the newest copy of this tab known to be saved
  let status = tabs.some((item) => item.id === tab.id) ? 'saved' : '';
  let undo = [];
  let redo = [];

  function section() { return tab.sections[sectionIndex]; }
  const columns = () => section().columns;
  const selection = () => (anchor === null || anchor === cursor ? null : { from: Math.min(anchor, cursor), to: Math.max(anchor, cursor) });
  const names = () => tuningNames(tab.tuning);
  const isSaved = () => tabs.some((item) => item.id === tab.id);
  // The saved list, with the tab being edited as it is now.
  const listed = () => {
    const others = tabs.filter((item) => item.id !== tab.id);
    return isSaved() || dirty || hasColumns(tab) || tab.name ? [tab, ...others] : others;
  };

  function showStatus(next) {
    status = next;
    $('#tab-status').textContent = next ? t(`fretboard.tab.${next}`) : '';
    $('#tab-status').hidden = !next;
    $('#tab-status').dataset.tone = next === 'saveFailed' ? 'danger' : '';
  }

  function rememberPlace() {
    storage.write(EDITOR_KEY, { currentId: tab.id, sectionIndex, key, background, playScope, loop, speed, timbre, reading, readingSize, neckOpen });
  }

  // Edits reach the worker a moment after the last one, in one message.
  function persist() {
    dirty = true;
    clearTimeout(saveTimer);
    showStatus('saving');
    saveTimer = setTimeout(flush, SAVE_DELAY_MS);
    rememberPlace();
  }

  async function flush() {
    clearTimeout(saveTimer);
    saveTimer = null;
    if (!dirty) return;
    dirty = false;
    // A new tab is saved once it has a name or a column.
    if (!isSaved() && !tab.name && !hasColumns(tab)) { showStatus(''); return; }
    const sent = structuredClone(tab);
    saving++;
    try {
      const response = await store.save(sent);
      tabs = own(sanitizeTabs(response.tabs));
      if (response.tab?.id === tab.id) syncedAt = Math.max(syncedAt, response.tab.updatedAt);
      if (!dirty && saving === 1) showStatus('saved');
    } catch (error) {
      dirty = true;
      showStatus('saveFailed');
      toast(error.message, { tone: 'danger' });
    } finally {
      saving--;
    }
    if (active()) renderControls();
  }

  // Another window saved, imported or deleted tabs. The tab being edited follows a newer saved copy,
  // unless this window has edits of its own on the way.
  function external(list) {
    const wasSaved = isSaved();
    tabs = own(list);
    if (dirty || saving || saveTimer) { if (active()) renderControls(); return; }
    const fresh = tabs.find((item) => item.id === tab.id);
    if (fresh && fresh.updatedAt > syncedAt && !sameTab(fresh, tab)) {
      tab = fresh;
      syncedAt = fresh.updatedAt;
      sectionIndex = Math.min(sectionIndex, tab.sections.length - 1);
      cursor = Math.min(cursor, columns().length - 1);
      anchor = null;
      render();
      return;
    }
    if (!fresh && wasSaved) {
      openTab(tabs[0] || blank(tab.tuning));
      return;
    }
    if (active()) renderControls();
  }
  store.watch(external);
  $('#tab-sheet').ownerDocument.defaultView.addEventListener('pagehide', () => { if (dirty) flush(); });

  // Every edit goes through here: one undo step, then save and redraw.
  function change(mutate, { keepSelection = false } = {}) {
    player.stop();
    undo.push(JSON.stringify({ tab, sectionIndex, cursor }));
    if (undo.length > HISTORY_LIMIT) undo.shift();
    redo = [];
    mutate();
    tab.updatedAt = Date.now();
    if (!keepSelection) anchor = null;
    persist();
    render();
  }

  function restore(snapshot) {
    const value = JSON.parse(snapshot);
    tab = normalizeTab(value.tab);
    sectionIndex = Math.min(value.sectionIndex, tab.sections.length - 1);
    cursor = Math.min(value.cursor, columns().length - 1);
    anchor = null;
    persist();
    render();
  }
  const current = () => JSON.stringify({ tab, sectionIndex, cursor });
  function undoStep() { if (undo.length) { redo.push(current()); restore(undo.pop()); } }
  function redoStep() { if (redo.length) { undo.push(current()); restore(redo.pop()); } }

  // Playing ------------------------------------------------------------------------------------------
  // The selection, the section or the whole tab, from its tempo (each section's own) times the speed.
  async function togglePlay() {
    if (player.playing()) { player.stop(); return; }
    const range = selection();
    const scope = playScope === 'selection' && !range ? 'section' : playScope;
    const plan = playbackPlan({ ...tab, rhythm: true }, { scope, section: sectionIndex, from: range?.from, to: range?.to, speed });
    if (!plan.events.length) { toast(t('fretboard.tab.play.empty')); return; }
    await player.play(plan, { loop, onEvent: showPlayhead, onStop: stopped });
    renderPlayControls();
  }

  function stopped() {
    playhead = null;
    markPlayhead();
    renderNeck();
    renderPlayControls();
  }

  function restartPlaying() {
    if (!player.playing()) return;
    player.stop();
    togglePlay();
  }

  // The sheet and the neck follow the column that sounds, without redrawing the sheet each time.
  function showPlayhead(event) {
    if (!active()) { player.stop(); return; }
    playhead = { section: event.section, index: event.index };
    if (event.section !== sectionIndex) {
      sectionIndex = event.section;
      cursor = columns().length - 1;
      anchor = null;
      renderView();
    }
    markPlayhead();
    renderNeck();
  }

  function markPlayhead() {
    const sheet = $('#tab-sheet');
    sheet.querySelector('[data-playing]')?.removeAttribute('data-playing');
    const target = playhead?.section === sectionIndex ? sheet.querySelector(`.tab-col[data-index="${playhead.index}"]`) : null;
    if (!target) { sheetCanvas.draw(); return; }
    target.dataset.playing = 'true';
    // Scrolls the sheet only, never the page around it.
    sheetCanvas.follow(target);
  }

  function renderPlayControls() {
    const playing = player.playing();
    $('#tab-play').setAttribute('aria-pressed', String(playing));
    $('#tab-play .tab-play-start').hidden = playing;
    $('#tab-play .tab-play-stop').hidden = !playing;
    for (const button of $$('#tab-play-scope [data-play-scope]')) {
      button.setAttribute('aria-checked', String(button.dataset.playScope === playScope));
      const unavailable = button.dataset.playScope === 'selection' && !selection();
      button.disabled = unavailable;
      button.title = unavailable ? t('fretboard.tab.selectionHint') : '';
    }
    $('#tab-loop').setAttribute('aria-pressed', String(loop));
    $('#tab-loop-check').checked = loop;
    $('#tab-speed').value = String(speed);
    for (const button of $$('#tab-timbre [data-timbre]')) button.setAttribute('aria-checked', String(button.dataset.timbre === timbre));
  }

  // Writing ------------------------------------------------------------------------------------------
  // Every column has a duration: the one chosen for the next notes.
  const rhythmOf = () => ({ ...duration });
  const restColumn = () => column({}, '', rhythmOf());

  // A duration is for the next notes; a column picked in the sheet (or a selection) takes it too, and
  // the buttons then show that column's.
  function followCursor() {
    const target = columns()[cursor];
    if (picked && target && !isBar(target) && target.d) duration = { d: target.d, dot: !!target.dot, tri: !!target.tri };
  }

  function editedRange({ current = picked } = {}) {
    const range = selection() || (current && cursor >= 0 ? { from: cursor, to: cursor } : null);
    return range && columns().slice(range.from, range.to + 1).some((item) => !isBar(item)) ? range : null;
  }

  function setDuration(patch) {
    duration = { ...duration, ...patch };
    const range = editedRange();
    if (!range) { renderView(); return; }
    change(() => {
      for (let index = range.from; index <= range.to; index++) {
        const target = columns()[index];
        if (!isBar(target)) columns()[index] = normalizeColumn({ ...target, ...duration });
      }
    }, { keepSelection: true });
  }

  function stepDuration(step) {
    const index = Math.min(DURATIONS.length - 1, Math.max(0, DURATIONS.indexOf(duration.d) + step));
    setDuration({ d: DURATIONS[index] });
  }

  // A tie continues the notes of the column before into this one.
  function toggleTie() {
    const range = editedRange({ current: true });
    if (!range) return;
    const notes = columns().slice(range.from, range.to + 1).filter((item) => !isBar(item) && !isRest(item));
    if (!notes.length) { toast(t('fretboard.tab.tieNeedsNotes')); return; }
    const tie = !notes.every((item) => item.tie);
    change(() => {
      for (let index = range.from; index <= range.to; index++) {
        const target = columns()[index];
        if (!isBar(target)) columns()[index] = normalizeColumn({ ...target, tie });
      }
    }, { keepSelection: true });
  }

  async function tempoDialog() {
    const dialog = $('#tab-tempo-dialog');
    const own = Boolean(section().bpm || section().meter);
    const { bpm, meter } = sectionTempo(tab, section());
    $('#tab-bpm').value = String(bpm);
    $('#tab-meter').value = meterText(meter);
    if (!$('#tab-meter').value) $('#tab-meter').value = '4/4';
    $('#tab-tempo-section').checked = own;
    $('#tab-tempo-section-label').textContent = t('fretboard.tab.tempoSection', { name: section().name });
    const onKey = (event) => { if (event.key === 'Enter') { event.preventDefault(); dialog.querySelector('button[value="save"]').click(); } };
    $('#tab-bpm').addEventListener('keydown', onKey);
    setTimeout(() => $('#tab-bpm').select(), 0);
    const answer = await ask(dialog);
    $('#tab-bpm').removeEventListener('keydown', onKey);
    if (answer !== 'save') return;
    const nextBpm = normalizeBpm(Number($('#tab-bpm').value)) ?? bpm;
    const [beats, unit] = $('#tab-meter').value.split('/').map(Number);
    const nextMeter = { beats, unit };
    change(() => {
      if ($('#tab-tempo-section').checked) {
        section().bpm = nextBpm;
        section().meter = nextMeter;
      } else {
        delete section().bpm;
        delete section().meter;
        tab.bpm = nextBpm;
        tab.meter = nextMeter;
      }
    });
  }

  // In chord mode the first note starts a new column and the next ones join it (or the column picked in
  // the sheet); a string the chord already uses, with another fret, starts the next chord.
  function writeNote(string, fret) {
    const joining = chordMode && (chordOpen || picked);
    picked = false;
    change(() => {
      const list = columns();
      const target = list[cursor];
      if (joining && target && !isBar(target) && (target.n[string] === null || target.n[string] === fret)) {
        const n = [...target.n];
        n[string] = n[string] === fret ? null : fret;
        list[cursor] = normalizeColumn({ ...target, n });
      } else if (list.length < MAX_COLUMNS) {
        list.splice(cursor + 1, 0, column({ [string]: fret }, fret === MUTED ? '' : tech, rhythmOf()));
        cursor += 1;
        tech = '';
        chordOpen = chordMode;
      }
    });
    row = string;
  }

  function insert(value) {
    picked = false;
    change(() => {
      if (columns().length >= MAX_COLUMNS) return;
      columns().splice(cursor + 1, 0, value);
      cursor += 1;
    });
  }

  function removeColumns() {
    const range = selection() || (cursor >= 0 ? { from: cursor, to: cursor } : null);
    if (!range) return;
    change(() => {
      columns().splice(range.from, range.to - range.from + 1);
      cursor = Math.min(range.from - 1, columns().length - 1);
    });
  }

  function clearNote() {
    const target = columns()[cursor];
    if (!target || isBar(target)) return;
    change(() => {
      const n = [...target.n];
      n[row] = null;
      columns()[cursor] = normalizeColumn({ ...target, n });
    });
  }

  function typeDigit(digit) {
    const target = columns()[cursor];
    const now = Date.now();
    const joined = typed && now - typed.at < 700 && typed.cursor === cursor ? Number(`${typed.value}${digit}`) : null;
    const fret = joined !== null && joined <= MAX_FRET ? joined : Number(digit);
    if (!target || isBar(target) || (joined === null && !chordMode && target.n[row] !== null)) {
      // A new column, unless the digit completes the one just typed.
      writeNote(row, fret);
    } else {
      change(() => {
        const n = [...target.n];
        n[row] = fret;
        columns()[cursor] = normalizeColumn({ ...target, n });
      });
    }
    typed = { value: String(fret), at: now, cursor };
  }

  // Clipboard: the internal clipboard survives between tabs and windows; the system one gets text.
  async function copyColumns() {
    const range = selection() || (cursor >= 0 ? { from: cursor, to: cursor } : null);
    if (!range) { toast(t('fretboard.tab.nothingSelected')); return; }
    const picked = columns().slice(range.from, range.to + 1);
    storage.write(CLIPBOARD_KEY, picked);
    const text = tabToAscii({ name: '', sections: [{ name: section().name, columns: picked }] }, { names: names() });
    try { await $('#tab-sheet').ownerDocument.defaultView.navigator.clipboard.writeText(text); } catch { /* The internal copy still works. */ }
    toast(t('fretboard.tab.copied', { count: picked.length }));
  }

  async function pasteColumns() {
    const picked = (await storage.read(CLIPBOARD_KEY));
    const list = (Array.isArray(picked) ? picked : []).map(normalizeColumn).filter(Boolean);
    if (!list.length) { importDialog(); return; }
    change(() => {
      const room = MAX_COLUMNS - columns().length;
      const pasted = list.slice(0, room);
      columns().splice(cursor + 1, 0, ...pasted.map((item) => structuredClone(item)));
      cursor += pasted.length;
    });
    toast(t('fretboard.tab.pasted', { count: list.length }));
  }

  // Sections -----------------------------------------------------------------------------------------
  function selectSection(index) {
    player.stop();
    sectionIndex = index;
    picked = false;
    cursor = columns().length - 1;
    anchor = null;
    rememberPlace();
    render();
  }

  function addSection() {
    if (tab.sections.length >= MAX_SECTIONS) { toast(t('fretboard.tab.tooManySections', { count: MAX_SECTIONS })); return; }
    change(() => {
      tab.sections.splice(sectionIndex + 1, 0, normalizeSection({ name: t('fretboard.tab.sectionDefault', { number: tab.sections.length + 1 }) }, tab.sections.length));
      sectionIndex += 1;
      cursor = -1;
    });
    renameSection();
  }

  async function renameSection() {
    const input = $('#tab-rename-name');
    input.value = section().name;
    const suggestions = t('fretboard.tab.suggestions').split(',');
    $('#tab-name-suggestions').replaceChildren(...suggestions.map((name) => {
      const button = element('button', { type: 'button', className: 'chip', textContent: name });
      button.addEventListener('click', () => { input.value = name; input.focus(); });
      return button;
    }));
    const dialog = $('#tab-rename-dialog');
    const onKey = (event) => { if (event.key === 'Enter') { event.preventDefault(); dialog.querySelector('button[value="save"]').click(); } };
    input.addEventListener('keydown', onKey);
    setTimeout(() => input.select(), 0);
    const answer = await ask(dialog);
    input.removeEventListener('keydown', onKey);
    const name = input.value.trim().slice(0, MAX_SECTION_NAME);
    if (answer === 'save' && name && name !== section().name) change(() => { section().name = name; });
  }

  function moveSection(step) {
    const target = sectionIndex + step;
    if (target < 0 || target >= tab.sections.length) return;
    change(() => {
      const [moved] = tab.sections.splice(sectionIndex, 1);
      tab.sections.splice(target, 0, moved);
      sectionIndex = target;
    });
  }

  function duplicateSection() {
    if (tab.sections.length >= MAX_SECTIONS) { toast(t('fretboard.tab.tooManySections', { count: MAX_SECTIONS })); return; }
    change(() => {
      const copy = { ...structuredClone(section()), id: newSectionId(), name: t('fretboard.tab.copyOf', { name: section().name }).slice(0, MAX_SECTION_NAME) };
      tab.sections.splice(sectionIndex + 1, 0, copy);
      sectionIndex += 1;
    });
  }

  function deleteSection() {
    const removed = section();
    const index = sectionIndex;
    change(() => {
      tab.sections.splice(sectionIndex, 1);
      if (!tab.sections.length) tab.sections.push(normalizeSection({}, 0));
      sectionIndex = Math.min(sectionIndex, tab.sections.length - 1);
      cursor = columns().length - 1;
    });
    toast(t('fretboard.tab.sectionDeleted', { name: removed.name }), { action: { label: t('fretboard.draw.undo'), run: () => change(() => { tab.sections.splice(index, 0, removed); sectionIndex = index; }) } });
  }

  // Tabs ---------------------------------------------------------------------------------------------
  function openTab(target, { section: index = 0 } = {}) {
    if (dirty) flush();
    player.stop();
    tab = target;
    picked = false;
    syncedAt = target.updatedAt;
    sectionIndex = Math.min(index, tab.sections.length - 1);
    cursor = columns().length - 1;
    anchor = null;
    undo = [];
    redo = [];
    showStatus(isSaved() ? 'saved' : '');
    rememberPlace();
    render();
  }

  function newTab() {
    openTab(blank(tab.tuning));
    $('#tab-name').focus();
  }

  async function importTabs(list) {
    const response = await store.import(list);
    tabs = own(sanitizeTabs(response.tabs));
    return response.summary;
  }

  function downloadTabs(list) {
    const shareable = list.filter(hasColumns);
    if (!shareable.length) { toast(t('fretboard.tab.nothingToShare'), { tone: 'danger' }); return false; }
    const file = createTabFile(shareable, { appVersion: globalThis.chrome?.runtime?.getManifest?.().version || '' });
    download(new Blob([JSON.stringify(file, null, 2)], { type: 'application/json' }), tabFileName(shareable));
    return true;
  }

  async function libraryDialog() {
    const list = $('#tabs-list');
    const search = $('#tabs-search');
    search.value = '';
    const draw = () => {
      const query = fold(search.value.trim());
      const all = listed();
      const shown = all.filter((item) => !query || fold(`${item.name} ${item.sections.map((part) => part.name).join(' ')}`).includes(query));
      $('#tabs-empty').hidden = all.length > 0;
      $('#tabs-no-results').hidden = !all.length || shown.length > 0;
      $('#tabs-export').disabled = !all.some(hasColumns);
      list.replaceChildren(...shown.map((item) => {
        const li = element('li', { className: 'diagram-item' });
        const open = element('button', { type: 'button', className: 'diagram-open' });
        open.dataset.open = item.id;
        open.append(element('strong', { textContent: item.name || t('fretboard.tab.untitled') }), element('span', { className: 'hint', textContent: `${item.sections.map((part) => part.name).join(' · ')} · ${t('fretboard.tab.noteCount', { count: noteCount(item) })}` }));
        const remove = element('button', { type: 'button', className: 'icon-btn icon-btn-sm icon-btn-danger', title: t('fretboard.tab.deleteTab'), ariaLabel: t('fretboard.tab.deleteTab') });
        remove.dataset.remove = item.id;
        remove.append(element('span', { textContent: '×' }));
        li.append(open, remove);
        if (item.id === tab.id) li.setAttribute('aria-current', 'true');
        return li;
      }));
    };
    const onClick = async (event) => {
      const opened = event.target.closest('[data-open]')?.dataset.open;
      const removed = event.target.closest('[data-remove]')?.dataset.remove;
      if (opened) {
        const target = listed().find((item) => item.id === opened);
        if (target && target.id !== tab.id) openTab(target);
        $('#tab-library-dialog').close('open');
      }
      if (removed) {
        const gone = structuredClone(listed().find((item) => item.id === removed));
        if (!gone) return;
        try {
          if (removed === tab.id) { clearTimeout(saveTimer); saveTimer = null; dirty = false; }
          tabs = own(sanitizeTabs((await store.remove(removed)).tabs));
        } catch (error) { toast(error.message, { tone: 'danger' }); return; }
        if (removed === tab.id) openTab(tabs[0] || blank(tab.tuning));
        draw();
        renderControls();
        toast(t('fretboard.tab.tabDeleted', { name: gone.name || t('fretboard.tab.untitled') }), { action: { label: t('fretboard.draw.undo'), run: async () => {
          try { await importTabs([gone]); } catch (error) { toast(error.message, { tone: 'danger' }); return; }
          renderControls();
        } } });
      }
    };
    const onExport = () => downloadTabs(listed());
    search.addEventListener('input', draw);
    list.addEventListener('click', onClick);
    $('#tabs-export').addEventListener('click', onExport);
    draw();
    await ask($('#tab-library-dialog'));
    search.removeEventListener('input', draw);
    list.removeEventListener('click', onClick);
    $('#tabs-export').removeEventListener('click', onExport);
  }

  // Import: an LPT1 code, a plain-text tab or a `.loop` file, as new tabs or inserted at the cursor.
  // Examples to try the editor: each opens as a tab of its own (opening one again finds the same copy).
  async function examplesDialog() {
    const list = $('#tab-examples-list');
    list.replaceChildren(...TAB_EXAMPLES.map((example) => {
      const li = element('li', { className: 'diagram-item' });
      const open = element('button', { type: 'button', className: 'diagram-open', value: 'open' });
      open.dataset.example = example.id;
      const meta = `${t(`fretboard.tab.examples.source.${example.source}`)} · ${t(`fretboard.tab.examples.${example.id}.text`)}`;
      open.append(element('strong', { textContent: t(`fretboard.tab.examples.${example.id}.name`) }), element('span', { className: 'hint', textContent: meta, title: meta }));
      li.append(open);
      return li;
    }));
    let chosen = null;
    const onClick = (event) => { chosen = event.target.closest('[data-example]')?.dataset.example ?? chosen; };
    list.addEventListener('click', onClick);
    const answer = await ask($('#tab-examples-dialog'));
    list.removeEventListener('click', onClick);
    if (answer !== 'open') return;
    const example = TAB_EXAMPLES.find((item) => item.id === chosen);
    if (!example) return;
    const incoming = exampleTab(example, { name: t(`fretboard.tab.examples.${example.id}.name`), partName: (part) => t(`fretboard.tab.examples.part.${part}`) });
    let summary;
    try { summary = await importTabs([incoming]); } catch (error) { toast(error.message, { tone: 'danger' }); return; }
    const opened = tabs.find((item) => item.id === summary.ids[0]);
    if (!opened) { toast(t('fretboard.tab.importSkipped', { count: 1, max: MAX_TABS }), { tone: 'danger' }); return; }
    openTab(opened);
    toast(t('fretboard.tab.examples.opened', { name: opened.name }));
  }

  async function importDialog() {
    const area = $('#tab-import-text');
    area.value = '';
    $('#tab-import-file').value = '';
    $('#tab-import-file-name').textContent = '';
    let parsed = [];
    let ignored = 0;
    const show = (list, problem = '') => {
      parsed = list;
      $('#tab-import-error').textContent = problem;
      $('#tab-import-error').hidden = !problem;
      const preview = $('#tab-import-preview');
      preview.hidden = !list.length;
      preview.replaceChildren();
      if (list.length) {
        const items = element('ul');
        items.append(...list.slice(0, 8).map((item) => element('li', { textContent: t('fretboard.tab.importPreview', { name: item.name || t('fretboard.tab.untitled'), sections: item.sections.map((part) => part.name).join(', '), notes: t('fretboard.tab.noteCount', { count: noteCount(item) }) }) })));
        if (list.length > 8) items.append(element('li', { textContent: '…' }));
        preview.append(items);
        if (ignored) preview.append(element('p', { className: 'hint', textContent: t('fretboard.tab.importIgnored', { count: ignored }) }));
      }
      $('#tab-import-new').disabled = !list.length;
      $('#tab-import-new').textContent = list.length > 1 ? t('fretboard.tab.importMany', { count: list.length }) : t('fretboard.tab.importNew');
      // Inserting at the cursor takes one tab's columns.
      $('#tab-import-insert').disabled = list.length !== 1;
    };
    const check = () => {
      ignored = 0;
      $('#tab-import-file-name').textContent = '';
      const value = area.value;
      if (!value.trim()) { show([]); return; }
      try {
        if (containsTabCode(value)) { show([decodeTabCode(value)]); return; }
        if (containsOtherFretboardCode(value)) throw new Error(t('fretboard.tab.diagramCode'));
        const sections = parseAsciiTab(value);
        if (!sections) throw new Error(t('fretboard.tab.notATab'));
        show([normalizeTab({ name: guessTabTitle(value), tuning: tab.tuning, sections, rhythm: sections.rhythm })]);
      } catch (error) { show([], error.message); }
    };
    const onPick = () => $('#tab-import-file').click();
    const onFile = async () => {
      const file = $('#tab-import-file').files?.[0];
      if (!file) return;
      area.value = '';
      $('#tab-import-file-name').textContent = file.name;
      try {
        if (file.size > MAX_FILE_BYTES) throw new Error(t('share.file.tooLarge'));
        const result = parseTabFile(await file.text());
        ignored = result.ignored;
        show(result.tabs);
      } catch (error) { ignored = 0; show([], error.message); }
    };
    area.addEventListener('input', check);
    $('#tab-import-pick').addEventListener('click', onPick);
    $('#tab-import-file').addEventListener('change', onFile);
    show([]);
    setTimeout(() => area.focus(), 0);
    const answer = await ask($('#tab-import-dialog'));
    area.removeEventListener('input', check);
    $('#tab-import-pick').removeEventListener('click', onPick);
    $('#tab-import-file').removeEventListener('change', onFile);
    if (!parsed.length) return;
    if (answer === 'new') {
      let summary;
      // A tab written here has no video (a transcription is opened in the Transcribe mode).
      const incoming = parsed.map((item) => normalizeTab({ ...item, video: null, name: item.name || t('fretboard.tab.imported') }));
      try { summary = await importTabs(incoming); } catch (error) { toast(error.message, { tone: 'danger' }); return; }
      const parts = [];
      if (summary.added) parts.push(t('fretboard.tab.importAdded', { count: summary.added }));
      if (summary.updated) parts.push(t('fretboard.tab.importUpdated', { count: summary.updated }));
      if (summary.skipped) parts.push(t('fretboard.tab.importSkipped', { count: summary.skipped, max: MAX_TABS }));
      toast(parts.join(' ') || t('fretboard.tab.importNothing'), summary.skipped ? { tone: 'danger' } : {});
      const first = tabs.find((item) => item.id === summary.ids[0]);
      if (first) openTab(first);
      else renderControls();
    } else if (answer === 'insert') {
      const incoming = parsed[0].sections.flatMap((part) => part.columns);
      change(() => {
        const pasted = incoming.slice(0, MAX_COLUMNS - columns().length);
        columns().splice(cursor + 1, 0, ...pasted);
        cursor += pasted.length;
      });
      toast(t('fretboard.tab.pasted', { count: incoming.length }));
    }
  }

  // What a scope shares: the whole tab, the current section or the selected columns, as a tab of its own.
  function sharedTab(scope) {
    const range = selection();
    const sections = scope === 'tab' ? tab.sections
      : scope === 'section' ? [section()]
        : [{ ...section(), columns: columns().slice(range.from, range.to + 1) }];
    return { ...tab, name: scope === 'tab' ? tab.name : `${tab.name ? `${tab.name} · ` : ''}${section().name}`, sections };
  }

  const tabSubtitle = (shared) => [
    TUNINGS[shared.tuning] && shared.tuning !== 'standard' ? t(`tools.tuning.${shared.tuning}`) : '',
    shared.rhythm ? `♩ = ${shared.bpm} · ${meterText(shared.meter)}` : '',
    shared.video?.title ? t('fretboard.tab.share.fromVideo', { title: shared.video.title }) : '',
  ].filter(Boolean).join(' · ');

  async function downloadImage(shared) {
    const blob = await tabPng({
      tab: shared, names: names(), title: shared.name || t('fretboard.tab.untitled'), subtitle: tabSubtitle(shared),
      footer: t('fretboard.image.footer'), container: $('#tab-sheet'),
    });
    download(blob, tabFileName([shared]).replace(/\.loop$/, '.png'));
  }

  async function shareDialog(scope = selection() ? 'selection' : 'tab') {
    const dialog = $('#tab-share-dialog');
    let chosen = scope;
    let shared = tab;
    const fill = () => {
      for (const button of $$('#tab-share-scope [data-scope]')) {
        button.setAttribute('aria-checked', String(button.dataset.scope === chosen));
        const unavailable = button.dataset.scope === 'selection' && !selection();
        button.disabled = unavailable;
        button.title = unavailable ? t('fretboard.tab.selectionHint') : '';
      }
      shared = sharedTab(chosen);
      const notes = shared.sections.reduce((total, part) => total + sectionNoteCount(part), 0);
      $('#tab-share-summary').textContent = [
        `"${shared.name || t('fretboard.tab.untitled')}"`, t('fretboard.tab.sectionCount', { count: shared.sections.length }), t('fretboard.tab.noteCount', { count: notes }),
        tab.video ? t('fretboard.tab.share.withVideo') : '',
      ].filter(Boolean).join(' · ');
      $('#tab-share-text').value = tabToAscii({ ...shared, name: chosen === 'tab' ? tab.name : '' }, { names: names(), sections: shared.sections, rhythm: $('#tab-share-rhythm').checked });
      // A code that would be too long says so and leaves the file for it.
      let code = '';
      let problem = '';
      try { code = encodeTabCode(shared, { sections: shared.sections }); } catch (error) { problem = error.code === 'too-long' ? '' : error.message; if (error.code === 'too-long') code = null; }
      $('#tab-share-code').value = code || problem;
      $('#tab-share-code').hidden = code === null;
      $('#tab-share-too-long').hidden = code !== null;
      $('#tab-share-copy').disabled = !code;
      $('#tab-share-status').textContent = '';
    };
    const status = (key) => { $('#tab-share-status').textContent = t(key); };
    const onScope = (event) => { const button = event.target.closest('[data-scope]'); if (button && !button.disabled) { chosen = button.dataset.scope; fill(); } };
    const onClick = async (event) => {
      if (event.target.closest('#tab-share-file')) {
        // Each scope is its own tab in the file, so the receiver never overwrites the whole one.
        const file = chosen === 'tab' ? shared : { ...shared, id: undefined };
        if (downloadTabs([normalizeTab(file)])) status('fretboard.tab.fileSaved');
        return;
      }
      if (event.target.closest('#tab-share-png')) {
        try { await downloadImage(normalizeTab({ ...shared, id: undefined })); status('fretboard.share.imageSaved'); } catch { status('fretboard.draw.imageFailed'); }
        return;
      }
      const which = event.target.closest('#tab-share-copy') ? '#tab-share-code' : event.target.closest('#tab-share-copy-text') ? '#tab-share-text' : null;
      if (!which) return;
      const ok = await writeClipboard($(which).value, $(which));
      status(ok ? (which === '#tab-share-code' ? 'fretboard.tab.codeCopied' : 'fretboard.tab.textCopied') : 'fretboard.tab.notCopied');
    };
    fill();
    $('#tab-share-scope').addEventListener('click', onScope);
    $('#tab-share-rhythm').addEventListener('change', fill);
    dialog.addEventListener('click', onClick);
    await ask(dialog);
    $('#tab-share-scope').removeEventListener('click', onScope);
    $('#tab-share-rhythm').removeEventListener('change', fill);
    dialog.removeEventListener('click', onClick);
  }

  // Transpose: every note up or down, in the tab, the section or the selection; the neck's key follows.
  async function transposeDialog() {
    const dialog = $('#tab-transpose-dialog');
    let steps = 0;
    let scope = selection() ? 'selection' : 'tab';
    const targets = () => {
      const range = selection();
      if (scope === 'tab') return tab.sections.map((part) => ({ part, from: 0, to: part.columns.length - 1 }));
      if (scope === 'section') return [{ part: section(), from: 0, to: columns().length - 1 }];
      return [{ part: section(), from: range.from, to: range.to }];
    };
    const preview = () => targets().reduce((total, { part, from, to }) => {
      const result = transposeColumns(part.columns.slice(from, to + 1), steps, tab.tuning);
      return { notes: total.notes + result.notes, moved: total.moved + result.moved, dropped: total.dropped + result.dropped };
    }, { notes: 0, moved: 0, dropped: 0 });
    const fill = () => {
      $('#tab-transpose-value').textContent = steps > 0 ? `+${steps}` : String(steps);
      for (const button of $$('#tab-transpose-scope [data-scope]')) {
        button.setAttribute('aria-checked', String(button.dataset.scope === scope));
        button.disabled = button.dataset.scope === 'selection' && !selection();
      }
      const result = preview();
      const from = spellScale(key, 'major').root;
      const to = spellScale(pitchClass(key + steps), 'major').root;
      $('#tab-transpose-preview').textContent = !steps ? t('fretboard.tab.transpose.none') : [
        t('fretboard.tab.transpose.summary', { steps: t('fretboard.tab.transpose.semitones', { count: Math.abs(steps) }), direction: t(steps > 0 ? 'fretboard.tab.transpose.upShort' : 'fretboard.tab.transpose.downShort'), from, to, notes: t('fretboard.tab.noteCount', { count: result.notes }) }),
        result.moved ? t('fretboard.tab.transpose.moved', { count: result.moved }) : '',
        result.dropped ? t('fretboard.tab.transpose.dropped', { count: result.dropped }) : '',
      ].filter(Boolean).join(' ');
      $('#tab-transpose-apply').disabled = !steps;
    };
    const onClick = (event) => {
      const step = event.target.closest('[data-transpose]');
      if (step) { steps = Math.max(-12, Math.min(12, steps + Number(step.dataset.transpose))); fill(); return; }
      const option = event.target.closest('#tab-transpose-scope [data-scope]');
      if (option && !option.disabled) { scope = option.dataset.scope; fill(); }
    };
    fill();
    dialog.addEventListener('click', onClick);
    const answer = await ask(dialog);
    dialog.removeEventListener('click', onClick);
    if (answer !== 'apply' || !steps) return;
    const result = preview();
    change(() => {
      for (const { part, from, to } of targets()) {
        const moved = transposeColumns(part.columns.slice(from, to + 1), steps, tab.tuning).columns;
        part.columns.splice(from, moved.length, ...moved);
      }
    }, { keepSelection: true });
    if (scope === 'tab') { key = pitchClass(key + steps); rememberPlace(); render(); }
    toast(t('fretboard.tab.transpose.done', { notes: t('fretboard.tab.noteCount', { count: result.notes }) }) + (result.dropped ? ` ${t('fretboard.tab.transpose.dropped', { count: result.dropped })}` : ''), result.dropped ? { tone: 'danger' } : {});
  }

  // Reading mode -------------------------------------------------------------------------------------
  const boardOf = () => $('#tab-sheet').closest('.board');
  function renderReading() {
    const board = boardOf();
    if (reading && active()) board.dataset.reading = 'true';
    else delete board.dataset.reading;
    board.style.setProperty('--tab-reading-cell', `${[24, 28, 32, 38, 46][readingSize]}px`);
    $('#tab-reading').setAttribute('aria-pressed', String(reading));
    $('#tab-reading span').textContent = t(reading ? 'fretboard.tab.reading.off' : 'fretboard.tab.reading.on');
    $('#tab-zoom-out').disabled = readingSize === 0;
    $('#tab-zoom-in').disabled = readingSize === 4;
    sheetCanvas.draw();
  }

  // Rendering ----------------------------------------------------------------------------------------
  const tokenOf = (value, string) => {
    const fret = value.n[string];
    if (fret === null) return '';
    if (fret === MUTED) return 'x';
    return value.tie ? `(${fret})` : `${value.t || ''}${fret}`;
  };
  // Measure lengths read in beats of the meter ("3 de 4 tempos").
  const beatsOf = (ticks, meter) => Math.round((ticks * meter.unit / 192) * 100) / 100;

  function renderSheet() {
    const sheet = $('#tab-sheet');
    const range = selection();
    // The rhythm always shows; a column written before durations existed reads as a quarter note.
    const rhythm = rhythmLayout(tab, section());
    const { meter } = sectionTempo(tab, section());
    const doc = sheet.ownerDocument;
    const beat = (item) => { const span = element('span', { className: 'tab-beat' }); if (item) span.append(rhythmGlyph(doc, item)); return span; };
    sheet.classList.toggle('has-rhythm', Boolean(rhythm));
    const rows = [...Array(STRING_COUNT).keys()].reverse(); // high string on top
    // The high E reads "e", as in written tabs.
    const label = [...names()];
    if (label[0] === label[STRING_COUNT - 1]) label[STRING_COUNT - 1] = label[STRING_COUNT - 1].toLowerCase();
    const head = element('div', { className: 'tab-col tab-names' });
    head.setAttribute('aria-hidden', 'true');
    head.append(...rows.map((string) => element('span', { className: 'tab-cell', textContent: label[string] })));
    const cells = columns().map((value, index) => {
      const button = element('button', { type: 'button', className: `tab-col${isBar(value) ? ' is-bar' : ''}${isRest(value) ? ' is-rest' : ''}` });
      button.dataset.index = String(index);
      if (index === cursor) button.dataset.current = 'true';
      if (playhead?.section === sectionIndex && playhead.index === index) button.dataset.playing = 'true';
      if (range && index >= range.from && index <= range.to) button.dataset.selected = 'true';
      if (!isBar(value)) button.append(...rows.map((string) => {
        const cell = element('span', { className: 'tab-cell', textContent: tokenOf(value, string) });
        if (index === cursor && string === row) cell.dataset.row = 'true';
        return cell;
      }));
      const item = rhythm?.[index];
      let spoken = isBar(value) ? t('fretboard.tab.bar') : isRest(value) ? t('fretboard.tab.rest')
        : rows.filter((string) => value.n[string] !== null).map((string) => `${label[string]} ${tokenOf(value, string)}`).join(', ');
      if (item && !item.bar) {
        button.dataset.d = item.d;
        button.append(beat(item));
        spoken += ` · ${t(`fretboard.tab.duration.${item.d}`)}${item.dot ? ` ${t('fretboard.tab.dottedShort')}` : ''}${item.tri ? ` ${t('fretboard.tab.tripletShort')}` : ''}`;
      }
      if (item?.measure) {
        button.dataset.measure = item.measure;
        button.title = t(`fretboard.tab.measure.${item.measure}`, { filled: beatsOf(item.filled, meter), expected: beatsOf(item.expected, meter) });
        spoken += ` · ${button.title}`;
      }
      button.setAttribute('aria-label', spoken);
      return button;
    });
    const end = element('button', { type: 'button', className: 'tab-col tab-end', title: t('fretboard.tab.endHint') });
    end.dataset.index = String(columns().length);
    end.append(...rows.map(() => element('span', { className: 'tab-cell' })));
    const start = element('button', { type: 'button', className: 'tab-col tab-start', title: t('fretboard.tab.startHint') });
    start.dataset.index = '-1';
    if (cursor === -1) start.dataset.current = 'true';
    start.append(...rows.map(() => element('span', { className: 'tab-cell' })));
    if (rhythm) for (const part of [head, start, end]) part.append(beat(null));
    // Redrawing removes the focused column; the keyboard stays on the sheet.
    const focused = sheet.contains(sheet.getRootNode().activeElement);
    sheet.replaceChildren(head, start, ...cells, end);
    if (focused) sheet.focus({ preventScroll: true });
    if (active()) sheet.querySelector('[data-current="true"]')?.scrollIntoView?.({ block: 'nearest', inline: 'nearest' });
    sheetCanvas.draw();
  }

  // One line under the sheet: where the cursor is, and what the next click or key does.
  function statusHint() {
    if (tech) return t(`${TECH_LABELS[tech]}Hint`);
    if (chordMode) return t('fretboard.tab.chordHint');
    if (selection()) return t('fretboard.tab.selectionKeys');
    return t('fretboard.tab.keysHint');
  }

  function renderControls() {
    // The name being typed stays as it is; another tab opened meanwhile shows its own.
    const nameField = $('#tab-name');
    if (nameField !== nameField.getRootNode().activeElement || nameField.dataset.tab !== tab.id) nameField.value = tab.name;
    nameField.dataset.tab = tab.id;
    $('#tab-sections').replaceChildren(...tab.sections.map((part, index) => {
      const button = element('button', { type: 'button', className: 'tab-section', textContent: part.name });
      button.dataset.tip = t('fretboard.tab.sectionHint');
      button.setAttribute('role', 'tab');
      button.setAttribute('aria-selected', String(index === sectionIndex));
      button.dataset.section = String(index);
      const count = sectionNoteCount(part);
      if (count) button.append(element('span', { className: 'count', textContent: String(count) }));
      return button;
    }));
    $('#tab-section-left').disabled = sectionIndex === 0;
    $('#tab-section-right').disabled = sectionIndex === tab.sections.length - 1;
    for (const button of $$('#tab-tech [data-tech]')) button.setAttribute('aria-checked', String(button.dataset.tech === tech));
    $('#tab-chord').setAttribute('aria-pressed', String(chordMode));
    const { bpm, meter } = sectionTempo(tab, section());
    $('#tab-tempo').textContent = `♩ ${bpm} · ${meterText(meter)}`;
    $('#tab-tempo').classList.toggle('is-own', Boolean(section().bpm || section().meter));
    for (const button of $$('#tab-duration [data-duration]')) button.setAttribute('aria-checked', String(button.dataset.duration === duration.d));
    $('#tab-dot').setAttribute('aria-pressed', String(duration.dot));
    $('#tab-triplet').setAttribute('aria-pressed', String(duration.tri));
    const here = columns()[cursor];
    $('#tab-tie').setAttribute('aria-pressed', String(Boolean(here?.tie)));
    $('#tab-undo').disabled = !undo.length;
    $('#tab-redo').disabled = !redo.length;
    $('#tab-undo-item').disabled = !undo.length;
    $('#tab-redo-item').disabled = !redo.length;
    $('#tab-key').replaceChildren(...Array.from({ length: 12 }, (_, pc) => element('option', { value: String(pc), textContent: spellScale(pc, background && background !== 'all' ? background : 'major').root })));
    $('#tab-key').value = String(key);
    $('#tab-key').hidden = !background || background === 'all';
    $('#tab-background').value = background;
    const notes = columns().filter((value) => !isBar(value)).length;
    const position = columns().slice(0, cursor + 1).filter((value) => !isBar(value)).length;
    $('#tab-position').textContent = t('fretboard.tab.position', { section: section().name, column: position, count: notes });
    $('#tab-counts').textContent = `${t('fretboard.tab.sectionCount', { count: tab.sections.length })} · ${t('fretboard.tab.noteCount', { count: noteCount(tab) })}`;
    $('#tab-hint').textContent = statusHint();
    $('#tabs-count').textContent = String(listed().length);
    showStatus(status);
    $('#tab-delete').disabled = cursor < 0 && !selection();
    $('#tab-neck-toggle').setAttribute('aria-expanded', String(neckOpen));
    boardOf().dataset.neck = neckOpen ? 'open' : 'closed';
    renderPlayControls();
    renderReading();
  }

  function renderView() {
    if (!active()) { delete boardOf().dataset.reading; delete boardOf().dataset.neck; return; }
    followCursor();
    renderControls();
    renderSheet();
  }

  // The neck shows the scale in the background, the current column and, faded, the one before it.
  function model() {
    const state = view();
    const range = { from: 0, to: state.frets };
    const strings = tuningStrings(tab.tuning);
    const dots = new Map();
    const put = (dot) => dots.set(`${dot.string}:${dot.fret}`, dot);
    if (background === 'all') {
      for (const cell of fretboardCells({ tuning: tab.tuning, range })) put({ string: cell.string, fret: cell.fret, kind: 'ghost', text: spellPitch(cell.pc, key, 'major') });
    } else if (background) {
      for (const cell of scalePositions({ rootPc: key, scaleId: background, tuning: tab.tuning, range })) put({ string: cell.string, fret: cell.fret, kind: cell.root ? 'root' : 'scale', dim: true, text: cell.name });
    }
    const name = (string, fret) => spellPitch(pitchClass(strings[string] + fret), key, background && background !== 'all' ? background : 'major');
    // While playing, the neck shows the column that sounds.
    const shown = playhead?.section === sectionIndex ? playhead.index : cursor;
    const previous = columns().slice(0, Math.max(0, shown)).reverse().find((item) => !isBar(item) && !isRest(item));
    for (const [list, kind] of [[previous, 'chord'], [columns()[shown], 'mark']]) {
      if (!list || isBar(list)) continue;
      list.n.forEach((fret, string) => {
        // Tab is read in frets: the written notes show their fret; the background shows note names.
        if (Number.isInteger(fret) && fret <= state.frets) put({ string, fret, kind, text: String(fret), dim: kind === 'chord', title: `${name(string, fret)} · ${t('fretboard.tab.fretTitle', { fret })}` });
      });
    }
    return { range, leftHanded: state.hand === 'left', highOnTop: state.high === 'top', stringNames: tuningNames(tab.tuning), interactive: true, dots: [...dots.values()], lines: [] };
  }

  // Events -------------------------------------------------------------------------------------------
  $('#tab-sheet').addEventListener('click', (event) => {
    const target = event.target.closest('[data-index]');
    if (!target) return;
    const index = Math.min(Number(target.dataset.index), columns().length - 1);
    if (event.shiftKey) anchor ??= cursor;
    else anchor = null;
    cursor = index;
    // The "+" at the end writes after the last column (a new chord, in chord mode).
    picked = !target.classList.contains('tab-end');
    chordOpen = false;
    const cell = event.target.closest('.tab-cell');
    if (cell && target.contains(cell)) row = STRING_COUNT - 1 - [...target.querySelectorAll('.tab-cell')].indexOf(cell);
    renderView();
    render();
  });
  $('#tab-sections').addEventListener('click', (event) => {
    const button = event.target.closest('[data-section]');
    if (!button) return;
    selectSection(Number(button.dataset.section));
  });
  $('#tab-sections').addEventListener('dblclick', (event) => { if (event.target.closest('[data-section]')) renameSection(); });
  $('#tab-tech').addEventListener('click', (event) => {
    const button = event.target.closest('[data-tech]');
    if (!button) return;
    if (button.dataset.tech === 'x') { writeNote(row, MUTED); return; }
    tech = tech === button.dataset.tech ? '' : button.dataset.tech;
    renderView();
  });
  $('#tab-name').addEventListener('input', (event) => {
    tab.name = event.target.value.slice(0, MAX_TAB_NAME);
    tab.updatedAt = Date.now();
    persist();
  });
  $('#tab-chord').addEventListener('click', () => { chordMode = !chordMode; chordOpen = false; renderView(); });
  $('#tab-bar').addEventListener('click', () => insert(barColumn()));
  $('#tab-rest').addEventListener('click', () => insert(restColumn()));
  $('#tab-duration').addEventListener('click', (event) => {
    const button = event.target.closest('[data-duration]');
    if (button) setDuration({ d: button.dataset.duration });
  });
  $('#tab-dot').addEventListener('click', () => setDuration({ dot: !duration.dot }));
  $('#tab-triplet').addEventListener('click', () => setDuration({ tri: !duration.tri }));
  $('#tab-tie').addEventListener('click', toggleTie);
  $('#tab-tempo').addEventListener('click', tempoDialog);
  $('#tab-play').addEventListener('click', togglePlay);
  $('#tab-transpose').addEventListener('click', transposeDialog);
  $('#tab-reading').addEventListener('click', () => { reading = !reading; rememberPlace(); renderReading(); render(); });
  $('#tab-reading-exit').addEventListener('click', () => { reading = false; rememberPlace(); renderReading(); render(); });
  $('#tab-neck-toggle').addEventListener('click', () => { neckOpen = !neckOpen; rememberPlace(); render(); });
  // Menus open under their button and close once an item is chosen.
  for (const menu of $$('.tab-menu')) {
    menu.addEventListener('beforetoggle', (event) => { if (event.newState === 'open') placePopover(menu, $(`[popovertarget="${menu.id}"]`)); });
    menu.addEventListener('toggle', (event) => { if (event.newState === 'open') placePopover(menu, $(`[popovertarget="${menu.id}"]`)); });
    menu.addEventListener('click', (event) => { if (event.target.closest('.tab-menu-item')) menu.hidePopover?.(); });
  }
  $('#tab-zoom-out').addEventListener('click', () => { readingSize = Math.max(0, readingSize - 1); rememberPlace(); renderReading(); });
  $('#tab-zoom-in').addEventListener('click', () => { readingSize = Math.min(4, readingSize + 1); rememberPlace(); renderReading(); });
  $('#tab-play-scope').addEventListener('click', (event) => {
    const button = event.target.closest('[data-play-scope]');
    if (!button || button.disabled) return;
    playScope = button.dataset.playScope;
    rememberPlace();
    renderPlayControls();
    restartPlaying();
  });
  $('#tab-loop').addEventListener('click', () => { loop = !loop; rememberPlace(); renderPlayControls(); restartPlaying(); });
  $('#tab-loop-check').addEventListener('change', (event) => { loop = event.target.checked; rememberPlace(); renderPlayControls(); restartPlaying(); });
  $('#tab-speed').addEventListener('change', (event) => { speed = Number(event.target.value); rememberPlace(); restartPlaying(); });
  $('#tab-timbre').addEventListener('click', (event) => {
    const button = event.target.closest('[data-timbre]');
    if (!button) return;
    timbre = button.dataset.timbre;
    player.setTimbre(timbre);
    rememberPlace();
    renderPlayControls();
    restartPlaying();
  });
  $('#tab-copy').addEventListener('click', copyColumns);
  $('#tab-paste').addEventListener('click', pasteColumns);
  $('#tab-undo').addEventListener('click', undoStep);
  $('#tab-undo-item').addEventListener('click', undoStep);
  $('#tab-redo-item').addEventListener('click', redoStep);
  $('#tab-redo').addEventListener('click', redoStep);
  $('#tab-delete').addEventListener('click', removeColumns);
  $('#tab-add-section').addEventListener('click', addSection);
  $('#tab-section-left').addEventListener('click', () => moveSection(-1));
  $('#tab-section-right').addEventListener('click', () => moveSection(1));
  $('#tab-section-rename').addEventListener('click', renameSection);
  $('#tab-section-copy').addEventListener('click', duplicateSection);
  $('#tab-section-delete').addEventListener('click', deleteSection);
  $('#tab-new').addEventListener('click', newTab);
  $('#tab-library').addEventListener('click', libraryDialog);
  $('#tab-import').addEventListener('click', importDialog);
  $('#tab-examples').addEventListener('click', examplesDialog);
  $('#tab-share').addEventListener('click', () => shareDialog());
  $('#tab-key').addEventListener('change', (event) => { key = Number(event.target.value); rememberPlace(); render(); });
  $('#tab-background').addEventListener('change', (event) => { background = event.target.value; rememberPlace(); render(); });

  // Keyboard on the sheet: arrows move, digits write frets, ↑/↓ choose the string.
  function keydown(event) {
    if (!active() || event.altKey) return;
    const inSheet = event.composedPath().some((node) => node?.id === 'tab-sheet');
    const typing = event.composedPath().some((node) => /^(INPUT|TEXTAREA|SELECT)$/.test(node?.tagName || ''));
    if (typing) return;
    const mod = event.ctrlKey || event.metaKey;
    if (mod && event.key.toLowerCase() === 'z') { event.preventDefault(); if (event.shiftKey) redoStep(); else undoStep(); return; }
    if (mod && event.key.toLowerCase() === 'y') { event.preventDefault(); redoStep(); return; }
    if (!inSheet) return;
    if (mod && event.key.toLowerCase() === 'c') { event.preventDefault(); copyColumns(); return; }
    if (mod && event.key.toLowerCase() === 'v') { event.preventDefault(); pasteColumns(); return; }
    if (mod) return;
    const handled = () => { event.preventDefault(); renderView(); render(); };
    switch (event.key) {
      case 'ArrowLeft': case 'ArrowRight': {
        const next = Math.max(-1, Math.min(columns().length - 1, cursor + (event.key === 'ArrowLeft' ? -1 : 1)));
        if (event.shiftKey) anchor ??= cursor; else anchor = null;
        cursor = next;
        picked = true;
        handled();
        return;
      }
      case 'ArrowUp': row = Math.min(STRING_COUNT - 1, row + 1); handled(); return;
      case 'ArrowDown': row = Math.max(0, row - 1); handled(); return;
      case 'Backspace': event.preventDefault(); removeColumns(); return;
      case 'Delete': event.preventDefault(); clearNote(); return;
      case ' ': event.preventDefault(); insert(restColumn()); return;
      case 'Enter': event.preventDefault(); togglePlay(); return;
      case 'Escape': if (player.playing()) { event.preventDefault(); player.stop(); } return;
      case '|': event.preventDefault(); insert(barColumn()); return;
      case 'x': case 'X': event.preventDefault(); writeNote(row, MUTED); return;
      default:
        if (/^\d$/.test(event.key)) { event.preventDefault(); typeDigit(event.key); return; }
        if (TECHNIQUES.includes(event.key)) { event.preventDefault(); tech = event.key; renderView(); return; }
        // Rhythm: − shorter, + longer, . dotted, t triplet, l tie.
        if (event.key === '-') { event.preventDefault(); stepDuration(1); }
        else if (event.key === '+' || event.key === '=') { event.preventDefault(); stepDuration(-1); }
        else if (event.key === '.') { event.preventDefault(); setDuration({ dot: !duration.dot }); }
        else if (event.key.toLowerCase() === 't') { event.preventDefault(); setDuration({ tri: !duration.tri }); }
        else if (event.key.toLowerCase() === 'l') { event.preventDefault(); toggleTie(); }
    }
  }

  return {
    // Opens a tab saved elsewhere (a transcription sent to the Tab mode).
    async show(id) {
      tabs = own(await store.list().catch(() => tabs));
      const target = tabs.find((item) => item.id === id);
      if (target) openTab(target);
    },
    cell: (target) => writeNote(target.string, target.fret),
    model,
    render: renderView,
    keydown,
    tuning: () => tab.tuning,
    setTuning(tuning) { change(() => { tab.tuning = tuning; }); },
    title: () => `${tab.name || t('fretboard.tab.untitled')} · ${section().name}`,
  };
}
