// Runs before the page renders: applies the cached theme, accent, tool visual and language to avoid a flash.
(() => {
  const root = document.documentElement;
  let prefs = null;
  try { prefs = JSON.parse(localStorage.getItem('lp-ui') || 'null'); } catch { prefs = null; }
  root.dataset.theme = ['auto', 'dark', 'light'].includes(prefs?.theme) ? prefs.theme : 'dark';
  root.dataset.accent = ['lime', 'blue', 'amber', 'rose', 'violet'].includes(prefs?.accent) ? prefs.accent : 'lime';
  root.dataset.toolVisual = ['classic', 'animated', 'strobe'].includes(prefs?.toolVisual) ? prefs.toolVisual : 'animated';
  if (['pt-BR', 'en', 'es'].includes(prefs?.lang)) root.lang = prefs.lang;
})();
