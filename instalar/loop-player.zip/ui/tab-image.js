// PNG image of a tab, in the current theme, for lessons, posts and video overlays: the title, a line
// of details, then each section's name and its staff (six lines, high string on top) wrapped to the
// width, with bar lines, techniques, tied notes in parentheses and, when the tab shows rhythm, stems,
// beams and rests under the strings. Drawn straight on a canvas, so it works in any window.
import { STRING_COUNT } from '../lib/theory.js';
import { MUTED, isBar, rhythmLayout } from '../lib/tabs.js';

const SCALE = 2;
const WIDTH = 1200;
const PAD = 36;
const LINE_GAP = 17;
const RHYTHM_HEIGHT = 30;
const SYSTEM_GAP = 26;
const NAME_WIDTH = 22;
const MIN_COLUMN = 26;

const token = (value, string) => {
  const fret = value.n[string];
  if (fret === null) return '';
  if (fret === MUTED) return 'x';
  return value.tie ? `(${fret})` : `${value.t || ''}${fret}`;
};

// Each column as wide as its longest token, a little wider for long notes when rhythm shows.
function columnWidth(context, value, item) {
  if (isBar(value)) return 14;
  const text = Math.max(0, ...Array.from({ length: STRING_COUNT }, (_, string) => context.measureText(token(value, string)).width));
  const long = item ? { w: 26, h: 14, q: 6 }[item.d] ?? 0 : 0;
  return Math.max(MIN_COLUMN, text + 12) + long;
}

// Beams run to the column's edges, where the neighbor's begin.
function drawRhythm(context, item, x, half, y, color) {
  context.save();
  context.strokeStyle = color;
  context.fillStyle = color;
  context.lineWidth = 1.5;
  const stemTop = y + 3;
  const stemBottom = y + 21;
  if (item.rest) {
    // A short zigzag stands for any rest, with its value written small beside it.
    context.beginPath();
    context.moveTo(x - 2, y + 4); context.lineTo(x + 2, y + 8); context.lineTo(x - 2, y + 12); context.lineTo(x + 2, y + 16);
    context.stroke();
    context.font = '600 9px system-ui, sans-serif';
    context.fillText(item.d.toUpperCase(), x + 5, y + 18);
  } else if (item.d === 'w') {
    context.beginPath();
    context.ellipse(x, y + 10, 4.5, 3, -0.35, 0, Math.PI * 2);
    context.stroke();
  } else {
    context.beginPath();
    context.moveTo(x, stemTop);
    context.lineTo(x, stemBottom);
    context.stroke();
    if (item.d === 'h') { context.beginPath(); context.ellipse(x, stemBottom + 1, 3.8, 2.6, -0.35, 0, Math.PI * 2); context.stroke(); }
    context.lineWidth = 3;
    for (let level = 0; level < item.flags; level++) {
      const beamY = stemBottom - level * 4;
      context.beginPath();
      if (level < item.beamLeft) { context.moveTo(x - half, beamY); context.lineTo(x, beamY); }
      if (level < item.beamRight) { context.moveTo(x, beamY); context.lineTo(x + half, beamY); }
      if (level >= item.beamLeft && level >= item.beamRight) {
        if (item.beamLeft || item.beamRight) { context.moveTo(x, beamY); context.lineTo(x + (item.beamRight ? 6 : -6), beamY); }
        else { context.lineWidth = 1.5; context.moveTo(x, beamY); context.quadraticCurveTo(x + 5, beamY - 3, x + 6, beamY - 9); }
      }
      context.stroke();
      context.lineWidth = 3;
    }
  }
  if (item.dot) { context.beginPath(); context.arc(x + 5, item.rest ? y + 12 : stemBottom - 2, 1.6, 0, Math.PI * 2); context.fill(); }
  if (item.triplet) { context.font = '700 9px system-ui, sans-serif'; context.textAlign = 'center'; context.fillText('3', x, y + 30); }
  context.restore();
}

/**
 * @param {{tab: object, sections?: object[], names: string[], title?: string, subtitle?: string, footer?: string,
 *   rhythm?: boolean, container?: HTMLElement}} options `names` are the open strings, low to high;
 *   `container` holds the theme's colors (it may be inside a shadow root).
 * @returns {Promise<Blob>}
 */
export async function tabPng({ tab, sections = tab.sections, names, title = '', subtitle = '', footer = '', rhythm = tab.rhythm, container = document.body }) {
  const page = getComputedStyle(container);
  const color = (name, fallback) => page.getPropertyValue(name).trim() || fallback;
  const font = page.fontFamily || 'system-ui, sans-serif';
  const mono = color('--lp-font-mono', 'ui-monospace, Menlo, monospace');
  const colors = {
    background: color('--lp-surface', '#161a14'), text: color('--lp-text', '#f2f5ee'), soft: color('--lp-text-2', '#b8bfb2'),
    faint: color('--lp-text-3', '#7d8577'), line: color('--lp-border-strong', '#3b4236'), accent: color('--lp-accent-text', '#c4f06a'),
  };
  const labels = [...names];
  if (labels[0] === labels[STRING_COUNT - 1]) labels[STRING_COUNT - 1] = labels[STRING_COUNT - 1].toLowerCase();
  const measure = document.createElement('canvas').getContext('2d');
  measure.font = `650 15px ${mono}`;

  // Lay out every section's columns into systems that fit the width.
  const staffHeight = LINE_GAP * (STRING_COUNT - 1);
  const systemHeight = staffHeight + (rhythm ? RHYTHM_HEIGHT : 8) + SYSTEM_GAP;
  const usable = WIDTH - PAD * 2 - NAME_WIDTH;
  const blocks = sections.map((section) => {
    const layout = rhythm ? rhythmLayout(tab, section) : null;
    const systems = [];
    let current = [];
    let used = 0;
    section.columns.forEach((value, index) => {
      const width = columnWidth(measure, value, layout?.[index]);
      if (used + width > usable && current.length) { systems.push(current); current = []; used = 0; }
      current.push({ value, item: layout?.[index], width });
      used += width;
    });
    if (current.length || !systems.length) systems.push(current);
    return { section, systems };
  });
  const header = title ? (subtitle ? 74 : 54) : 20;
  const body = blocks.reduce((total, block) => total + 26 + block.systems.length * systemHeight, 0);
  const height = header + body + (footer ? 34 : 14);

  const canvas = document.createElement('canvas');
  canvas.width = WIDTH * SCALE;
  canvas.height = Math.round(height * SCALE);
  const context = canvas.getContext('2d');
  context.scale(SCALE, SCALE);
  context.fillStyle = colors.background;
  context.fillRect(0, 0, WIDTH, height);
  if (title) {
    context.fillStyle = colors.text;
    context.font = `700 22px ${font}`;
    context.fillText(title, PAD, 42, WIDTH - PAD * 2);
    if (subtitle) {
      context.fillStyle = colors.soft;
      context.font = `500 13px ${font}`;
      context.fillText(subtitle, PAD, 63, WIDTH - PAD * 2);
    }
  }
  let y = header;
  for (const { section, systems } of blocks) {
    context.fillStyle = colors.accent;
    context.font = `700 13px ${font}`;
    context.fillText(section.name, PAD, y + 14);
    y += 26;
    for (const system of systems) {
      const top = y + 6;
      const right = PAD + NAME_WIDTH + Math.max(60, system.reduce((total, column) => total + column.width, 0));
      context.fillStyle = colors.faint;
      context.font = `600 12px ${mono}`;
      context.textAlign = 'left';
      context.textBaseline = 'middle';
      for (let row = 0; row < STRING_COUNT; row++) {
        const lineY = top + row * LINE_GAP;
        context.fillText(labels[STRING_COUNT - 1 - row], PAD, lineY);
        context.strokeStyle = colors.line;
        context.lineWidth = 1;
        context.beginPath();
        context.moveTo(PAD + NAME_WIDTH - 6, lineY);
        context.lineTo(right, lineY);
        context.stroke();
      }
      let x = PAD + NAME_WIDTH;
      for (const { value, item, width } of system) {
        const middle = x + width / 2;
        if (isBar(value)) {
          context.strokeStyle = item?.measure ? color('--lp-warning-text', '#f5b84b') : colors.soft;
          context.lineWidth = 2;
          context.beginPath();
          context.moveTo(middle, top);
          context.lineTo(middle, top + staffHeight);
          context.stroke();
        } else {
          context.font = `650 15px ${mono}`;
          context.textAlign = 'center';
          for (let row = 0; row < STRING_COUNT; row++) {
            const text = token(value, STRING_COUNT - 1 - row);
            if (!text) continue;
            const lineY = top + row * LINE_GAP;
            const textWidth = context.measureText(text).width;
            context.fillStyle = colors.background;
            context.fillRect(middle - textWidth / 2 - 2, lineY - 8, textWidth + 4, 16);
            context.fillStyle = colors.text;
            context.fillText(text, middle, lineY + 1);
          }
          if (item) drawRhythm(context, item, middle, width / 2, top + staffHeight + 6, colors.soft);
        }
        x += width;
      }
      context.textBaseline = 'alphabetic';
      context.textAlign = 'left';
      y += systemHeight;
    }
  }
  if (footer) {
    context.fillStyle = colors.faint;
    context.font = `600 11px ${font}`;
    context.textAlign = 'right';
    context.fillText(footer, WIDTH - PAD, height - 14);
  }
  return new Promise((resolve, reject) => canvas.toBlob((blob) => (blob ? resolve(blob) : reject(new Error('toBlob'))), 'image/png'));
}
