// Audio thread of the offscreen engine. Keeps the latest 4096 input samples, hands a window to the
// main thread every 60 ms for pitch analysis (YIN is too slow for the 128-frame render quantum) and
// renders the metronome and count-in clicks sample by sample.
import { MetronomeScheduler } from './lib/metronome.js';
import { WINDOW_SIZE, ANALYSIS_INTERVAL_MS, GATE_DEFAULT_DB, createOnsetDetector } from './lib/pitch.js';

class LoopPlayerAudio extends AudioWorkletProcessor {
  constructor() {
    super();
    this.metronome = new MetronomeScheduler(sampleRate);
    this.onsets = createOnsetDetector(sampleRate);
    this.ring = new Float32Array(WINDOW_SIZE);
    this.write = 0;
    this.filled = 0;
    this.interval = Math.round((sampleRate * ANALYSIS_INTERVAL_MS) / 1000);
    this.sinceWindow = 0;
    this.squares = 0;
    this.attack = false;
    this.capture = false;
    this.channel = 0;
    this.gateDB = GATE_DEFAULT_DB;
    this.port.onmessage = (event) => this.handle(event.data);
  }

  handle(message) {
    switch (message?.type) {
      case 'configure':
        if (message.reset || message.capture !== this.capture) this.resetInput();
        this.capture = message.capture === true;
        this.channel = message.channel === 2 ? 1 : 0;
        this.gateDB = Number.isFinite(message.gateDB) ? message.gateDB : GATE_DEFAULT_DB;
        if (message.metronome) this.metronome.configure(message.metronome);
        break;
      case 'count-in':
        this.metronome.configure({ accent: message.accent, volume: message.volume });
        this.port.postMessage({ type: 'count-in', ...this.metronome.startCountIn(message) });
        break;
      case 'count-in-cancel':
        this.metronome.cancelCountIn(currentFrame);
        break;
      default:
        break;
    }
  }

  resetInput() {
    this.write = 0;
    this.filled = 0;
    this.sinceWindow = 0;
    this.squares = 0;
    this.attack = false;
    this.onsets.reset();
  }

  process(inputs, outputs) {
    const output = outputs[0];
    for (const channel of output) channel.fill(0);
    const input = inputs[0];
    if (this.capture && input?.length) {
      const samples = input[Math.min(this.channel, input.length - 1)];
      if (this.onsets.update(samples, this.gateDB, currentFrame)) this.attack = true;
      for (let index = 0; index < samples.length; index++) {
        const sample = samples[index];
        this.ring[this.write] = sample;
        this.write = (this.write + 1) % WINDOW_SIZE;
        this.squares += sample * sample;
      }
      this.filled = Math.min(WINDOW_SIZE, this.filled + samples.length);
      this.sinceWindow += samples.length;
      if (this.sinceWindow >= this.interval && this.filled === WINDOW_SIZE) {
        const window = new Float32Array(WINDOW_SIZE);
        window.set(this.ring.subarray(this.write));
        window.set(this.ring.subarray(0, this.write), WINDOW_SIZE - this.write);
        this.port.postMessage({ type: 'window', samples: window, attack: this.attack, rms: Math.sqrt(this.squares / this.sinceWindow) }, [window.buffer]);
        this.sinceWindow = 0;
        this.squares = 0;
        this.attack = false;
      }
    }
    if (output.length) {
      for (const event of this.metronome.render(output, currentFrame, output[0].length)) this.port.postMessage({ type: 'beat', ...event });
    }
    return true;
  }
}

registerProcessor('loop-player-audio', LoopPlayerAudio);
