/* Floating practice controller, standalone tool windows and the fretboard. Injected on demand into the top frame. */
(() => {
  if (window.top !== window) return;
  const version = chrome.runtime.getManifest?.().version || 'development';
  const previous = globalThis.__loopPlayerOverlayInstalled;
  if (previous?.extensionId === chrome.runtime.id && previous.version === version) return;
  const marker = {extensionId: chrome.runtime.id, version};
  globalThis.__loopPlayerOverlayInstalled = marker;
  // A reloaded extension leaves its old controller orphaned on the page.
  for (const stale of document.querySelectorAll('loop-player-overlay, loop-player-tool')) stale.remove();

  let overlay = null;
  let tools = null;
  let pip = null;
  let watchdog = null;
  let stopWatching = null;
  let i18n = null;
  let overlayModule = null;
  let builtLocale = null;
  // Last state from the worker, replayed when a new language rebuilds the windows.
  let lastState = null;
  let lastWindows = null;
  const toolWindows = new Map();
  // The fretboard window loads its modules only when it is first opened.
  let fretboardWindow = null;
  let fretboardOpening = null;
  let fretboardWanted = false;
  const alive = () => Boolean(globalThis.chrome?.runtime?.id);
  const destroy = () => {
    clearInterval(watchdog);
    stopWatching?.();
    for (const toolWindow of toolWindows.values()) toolWindow.destroy();
    toolWindows.clear();
    fretboardWindow?.destroy();
    fretboardWindow = null;
    overlay?.destroy();
    overlay = null;
    tools?.destroy();
    tools = null;
    if (globalThis.__loopPlayerOverlayInstalled === marker) delete globalThis.__loopPlayerOverlayInstalled;
  };
  const send = async (message) => {
    if (!alive()) { destroy(); return null; }
    try { return await chrome.runtime.sendMessage(message); }
    catch (error) {
      if (!alive()) destroy();
      return {ok: false, error: error.message || i18n?.t('common.extensionNoResponse') || 'Extension did not respond.'};
    }
  };
  const css = (path) => fetch(chrome.runtime.getURL(path)).then((response) => response.text());
  let styles = '';
  let windowModule = null;

  const ready = Promise.all([
    import(chrome.runtime.getURL('ui/overlay-view.js')),
    import(chrome.runtime.getURL('ui/tool-window.js')),
    import(chrome.runtime.getURL('ui/tools-client.js')),
    import(chrome.runtime.getURL('ui/pip.js')),
    import(chrome.runtime.getURL('ui/appearance.js')),
    import(chrome.runtime.getURL('lib/i18n.js')),
    Promise.all(['ui/tokens.css', 'ui/kit.css', 'ui/overlay.css', 'ui/tools.css'].map(css)),
  ]).then(async ([module, toolWindowModule, clientModule, pipModule, appearance, i18nModule, sheets]) => {
    styles = sheets.join('\n');
    windowModule = toolWindowModule;
    overlayModule = module;
    i18n = i18nModule;
    // Theme and language are settled before any markup is built.
    const prefs = await appearance.loadUiPrefs();
    appearance.setAppearance(prefs);
    i18n.applyLocaleChoice(prefs.locale);
    // content.js shares this i18n module and may switch the language first, so compare against the
    // language the windows were built in rather than the module's previous value.
    builtLocale = i18n.getLocale();
    stopWatching = appearance.watchUiPrefs((next) => {
      appearance.setAppearance(next);
      if (i18n.applyLocaleChoice(next.locale) !== builtLocale) rebuild();
    });
    // One port to the worker serves the controller's tools area and every tool window.
    tools = clientModule.createToolsClient({connect: () => chrome.runtime.connect({name: 'lp-tools'}), send});
    // Chrome keeps one Picture-in-Picture window per page: the controller and the tools share it.
    pip = pipModule.createPipHost({css: styles});
    overlay = module.createOverlay({css: styles, send, tools, pip});
    watchdog = setInterval(() => { if (!alive()) destroy(); }, 3000);
    return overlay;
  });

  function updateToolWindows(windows) {
    lastWindows = windows;
    for (const tool of ['tuner', 'notes', 'metronome']) {
      const spec = windows?.[tool];
      if (spec?.open && !toolWindows.has(tool)) {
        toolWindows.set(tool, windowModule.createToolWindow({css: styles, tool, client: tools, send, pip, prefs: {position: spec.position, collapsed: spec.collapsed}}));
      } else if (!spec?.open && toolWindows.has(tool)) {
        toolWindows.get(tool).destroy();
        toolWindows.delete(tool);
      }
    }
  }

  async function updateFretboard(open) {
    fretboardWanted = open;
    if (!open) {
      fretboardWindow?.destroy();
      fretboardWindow = null;
      return;
    }
    if (fretboardWindow) return;
    fretboardOpening ??= (async () => {
      const [module, sheet] = await Promise.all([import(chrome.runtime.getURL('ui/fretboard-window.js')), css('ui/fretboard.css')]);
      const created = await module.createFretboardWindow({css: `${styles}\n${sheet}`, send, pip});
      // Closed again while it was loading.
      if (fretboardWanted && !fretboardWindow) fretboardWindow = created;
      else created.destroy();
    })().finally(() => { fretboardOpening = null; });
    await fretboardOpening;
  }

  // Markup is built once per window, so a new language recreates the controller and tool windows.
  function rebuild() {
    builtLocale = i18n.getLocale();
    for (const toolWindow of toolWindows.values()) toolWindow.destroy();
    toolWindows.clear();
    if (fretboardWindow) {
      fretboardWindow.destroy();
      fretboardWindow = null;
      updateFretboard(true).catch(() => {});
    }
    overlay?.destroy();
    overlay = overlayModule.createOverlay({css: styles, send, tools, pip});
    if (lastState) overlay.update(lastState);
    if (lastWindows) updateToolWindows(lastWindows);
  }

  const receive = (message, sender, respond) => {
    if (sender.id !== chrome.runtime.id || !message?.type?.startsWith('LPO_')) return;
    ready.then(() => {
      if (!overlay) throw new Error(i18n?.t('common.controllerUnavailable') || 'Controller unavailable.');
      if (message.type === 'LPO_STATE') {
        const update = {visible: message.visible === true, session: message.session || null, title: message.title || '', ...(message.prefs ? {prefs: message.prefs} : {}), ...(message.openTools ? {openTools: message.openTools} : {})};
        lastState = {...lastState, ...update};
        overlay.update(update);
      }
      if (message.type === 'LPO_TOOLS') updateToolWindows(message.windows);
      if (message.type === 'LPO_FRETBOARD') return updateFretboard(message.open === true).then(() => ({ok: true}));
      return {ok: true};
    }).then(respond).catch((error) => respond({ok: false, error: error.message}));
    return true;
  };
  chrome.runtime.onMessage.addListener(receive);
  ready.catch(() => {
    if (globalThis.__loopPlayerOverlayInstalled === marker) delete globalThis.__loopPlayerOverlayInstalled;
    chrome.runtime.onMessage.removeListener?.(receive);
  });
})();
