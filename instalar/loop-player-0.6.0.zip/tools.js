// Extension tool window (pages that refuse the extension) and microphone permission page.
import { createToolsPanel } from './ui/tools-view.js';
import { createToolsClient } from './ui/tools-client.js';
import { hydrateIcons, icon } from './ui/icons.js';
import { escapeHTML } from './ui/html.js';
import { TOOL_IDS, TOOL_LABELS } from './lib/tools.js';
import { t, applyLocaleChoice, localizeDom, getLocale } from './lib/i18n.js';
import { loadUiPrefs, watchUiPrefs, applyAppearance, writeCache } from './ui/appearance.js';

const $ = (selector) => document.querySelector(selector);
const params = new URLSearchParams(location.search);
const send = (message) => chrome.runtime.sendMessage(message);
let toastTimer;
const uiPrefs = await loadUiPrefs();
applyAppearance(document.documentElement, uiPrefs);
applyLocaleChoice(uiPrefs.locale);
writeCache(uiPrefs, getLocale());
localizeDom(document);
watchUiPrefs((next) => {
  const previousLocale = getLocale();
  applyAppearance(document.documentElement, next);
  if (applyLocaleChoice(next.locale) !== previousLocale) location.reload();
});
hydrateIcons(document);

function toast(message) {
  clearTimeout(toastTimer);
  $('#toast').textContent = message;
  $('#toast').dataset.tone = 'danger';
  $('#toast').hidden = false;
  toastTimer = setTimeout(() => { $('#toast').hidden = true; }, 6000);
}

function toolPage(tool) {
  document.title = `${TOOL_LABELS[tool]} · Loop Player`;
  $('#tool-page').hidden = false;
  $('#tool-title').textContent = TOOL_LABELS[tool];
  $('#tool-icon').innerHTML = icon(tool, { size: 15 });
  const client = createToolsClient({ connect: () => chrome.runtime.connect({ name: 'lp-tools' }), send });
  const panel = createToolsPanel({ client, mode: 'single', tool, onError: toast });
  $('#tool-panel').append(panel.element);
  panel.setActive(true);
}

async function setupPage() {
  document.title = `${t('tools.setup.microphone')} · Loop Player`;
  $('#setup-page').hidden = false;
  let stream = null;
  let context = null;
  let frame = null;
  let prefs = (await send({ type: 'GET_TOOLS' }).catch(() => null))?.prefs?.input || { deviceId: '', channel: 1 };

  function status(tone, text) {
    $('#setup-status').hidden = !text;
    $('#setup-status').dataset.tone = tone;
    $('#setup-status').innerHTML = text ? `${icon(tone === 'live' ? 'check' : 'alert')}<span>${escapeHTML(text)}</span>` : '';
  }

  function stop() {
    cancelAnimationFrame(frame);
    for (const track of stream?.getTracks() || []) track.stop();
    stream = null;
    context?.close().catch(() => {});
    context = null;
  }

  async function fillDevices() {
    const devices = (await navigator.mediaDevices.enumerateDevices()).filter((device) => device.kind === 'audioinput' && device.deviceId && !['default', 'communications'].includes(device.deviceId));
    const select = $('#setup-device');
    select.replaceChildren(new Option(t('tools.input.systemDefault'), ''), ...devices.map((device, index) => new Option(device.label || t('tools.input.numbered', { number: index + 1 }), device.deviceId)));
    select.value = devices.some((device) => device.deviceId === prefs.deviceId) ? prefs.deviceId : '';
    $('#setup-channel').value = String(prefs.channel === 2 ? 2 : 1);
  }

  // A level meter on the chosen channel confirms the guitar reaches the extension.
  function meter(channel) {
    context = new AudioContext();
    const source = context.createMediaStreamSource(stream);
    const splitter = context.createChannelSplitter(2);
    const analyser = context.createAnalyser();
    analyser.fftSize = 1024;
    source.connect(splitter);
    splitter.connect(analyser, channel === 2 && source.channelCount > 1 ? 1 : 0);
    const samples = new Float32Array(analyser.fftSize);
    const opened = performance.now();
    let heard = false;
    const paint = () => {
      analyser.getFloatTimeDomainData(samples);
      let peak = 0;
      for (const sample of samples) peak = Math.max(peak, Math.abs(sample));
      const decibels = peak > 0 ? Math.max(-60, 20 * Math.log10(peak)) : -60;
      heard ||= peak > 0;
      $('#setup-level').style.width = `${((decibels + 60) / 60) * 100}%`;
      // Digital silence for seconds means the input opened but delivers nothing.
      $('#setup-level-label').textContent = decibels > -50 ? t('tools.setup.signal', { level: decibels.toFixed(0) })
        : !heard && performance.now() - opened > 5000 ? t('tools.setup.noSignal')
          : t('tools.setup.levelHint');
      frame = requestAnimationFrame(paint);
    };
    paint();
  }

  async function open() {
    stop();
    const deviceId = $('#setup-device').options.length ? $('#setup-device').value : prefs.deviceId;
    const channel = Number($('#setup-channel').value) === 2 ? 2 : 1;
    try {
      stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: false, noiseSuppression: false, autoGainControl: false, channelCount: { ideal: 2 }, ...(deviceId ? { deviceId: { exact: deviceId } } : {}) } });
    } catch (error) {
      stop();
      $('#setup-input').hidden = true;
      if (error.name === 'NotAllowedError' || error.name === 'SecurityError') {
        status('danger', t('tools.setup.blocked'));
        $('#setup-settings').hidden = false;
      } else if (error.name === 'NotFoundError' || error.name === 'OverconstrainedError') {
        status('danger', t('tools.setup.noDevice'));
      } else {
        status('danger', t('tools.setup.openFailed', { error: error.message }));
      }
      $('#setup-allow').hidden = false;
      return;
    }
    const track = stream.getAudioTracks()[0];
    status('live', t('tools.setup.allowed', { input: track?.label || t('tools.setup.defaultInput') }));
    $('#setup-allow').hidden = true;
    $('#setup-settings').hidden = true;
    $('#setup-input').hidden = false;
    await fillDevices();
    if (channel === 2 && (track?.getSettings?.().channelCount || 1) < 2) status('warn', t('tools.setup.mono'));
    meter(channel);
    // The offscreen engine retries a capture that failed for lack of permission.
    send({ type: 'TOOLS_RETRY' }).catch(() => {});
  }

  async function choose() {
    const select = $('#setup-device');
    prefs = { deviceId: select.value, label: select.value ? select.selectedOptions[0]?.textContent || '' : '', channel: Number($('#setup-channel').value) === 2 ? 2 : 1 };
    const response = await send({ type: 'TOOLS_PREFS', patch: { input: prefs } }).catch((error) => ({ ok: false, error: error.message }));
    if (!response?.ok) toast(response?.error || t('tools.setup.saveFailed'));
    await open();
  }

  $('#setup-channel').value = String(prefs.channel === 2 ? 2 : 1);
  $('#setup-allow').addEventListener('click', open);
  $('#setup-device').addEventListener('change', choose);
  $('#setup-channel').addEventListener('change', choose);
  $('#setup-settings').addEventListener('click', () => chrome.tabs.create({ url: `chrome://settings/content/siteDetails?site=${encodeURIComponent(location.origin)}` }));
  $('#setup-close').addEventListener('click', async () => {
    stop();
    const tab = await chrome.tabs.getCurrent();
    if (tab?.id) chrome.tabs.remove(tab.id); else window.close();
  });
  addEventListener('pagehide', stop);

  // Opening this page is the request: show the Chrome prompt right away.
  let state = 'prompt';
  try { state = (await navigator.permissions.query({ name: 'microphone' })).state; } catch { /* Ask anyway. */ }
  if (state === 'denied') {
    status('danger', t('tools.setup.denied'));
    $('#setup-settings').hidden = false;
  } else {
    await open();
  }
}

if (params.has('setup')) setupPage();
else toolPage(TOOL_IDS.includes(params.get('tool')) ? params.get('tool') : 'tuner');
