// Standalone floating window for one tool (Tuner, Notes or Metronome), usable without a practice
// session. Same frame as the practice controller: drag, remembered position, minimize and
// Picture-in-Picture. Runs in a closed shadow root on the page.
import { registerHost, paintWindow } from './appearance.js';
import { createToolsPanel } from './tools-view.js';
import { TOOL_LABELS } from '../lib/tools.js';
import { t } from '../lib/i18n.js';
import { icon } from './icons.js';
import { setHTML, escapeHTML } from './html.js';

const MARGIN = 16;
export const TOOL_HOST_TAG = 'loop-player-tool';
const clamp = (value, minimum, maximum) => Math.min(Math.max(value, minimum), maximum);

function markup(tool) {
  const label = escapeHTML(TOOL_LABELS[tool]);
  const tx = (key, params) => escapeHTML(t(key, params));
  return `
  <div class="lpo lpw" data-collapsed="false" data-pip="false" role="dialog" aria-label="${label} · Loop Player">
    <div class="lpo-head" data-drag>
      <span class="lpo-grip" aria-hidden="true">${icon('grip', { size: 14 })}</span>
      <span class="lpo-logo" aria-hidden="true">${icon(tool, { size: 15 })}</span>
      <div class="lpo-heading"><strong class="lpo-title">${label}</strong></div>
      <div class="lpo-head-actions">
        <button class="icon-btn" data-action="pip" data-ref="pip" aria-label="${tx('tools.window.popOut')}" title="${tx('tools.window.popOutTitle')}">${icon('pip', { size: 16 })}</button>
        <button class="icon-btn" data-action="collapse" aria-label="${tx('tools.window.minimize')}" title="${tx('tools.window.minimize')}">${icon('chevronDown', { size: 16 })}</button>
        <button class="icon-btn" data-action="close" aria-label="${tx('tools.window.close', { tool: TOOL_LABELS[tool] })}" title="${tx('tools.window.closeTitle')}">${icon('x', { size: 16 })}</button>
      </div>
    </div>
    <div class="lpo-body" data-ref="body"></div>
    <div class="lpo-mini" data-drag>
      <span class="lpo-logo" aria-hidden="true">${icon(tool, { size: 14 })}</span>
      <span class="lpw-mini-text" data-ref="summary" aria-live="polite">—</span>
      ${tool === 'metronome' ? `<button class="play-btn" data-action="metronome" data-ref="miniPlay" aria-label="${tx('tools.metronome.start')}">${icon('play', { size: 16 })}</button>` : ''}
      <button class="icon-btn" data-action="expand" aria-label="${tx('tools.window.expand', { tool: TOOL_LABELS[tool] })}" title="${tx('tools.window.expandTitle')}">${icon('chevronUp', { size: 16 })}</button>
    </div>
    <div class="lpo-toast" data-ref="toast" role="status" hidden></div>
  </div>`;
}

/**
 * @param {{css: string, tool: string, client: object, send: (message: object) => Promise<any>,
 *   prefs?: {position?: {fx: number, fy: number}, collapsed?: boolean}, documentRef?: Document, pip?: object}} options
 * `pip` is the page's shared Picture-in-Picture host (ui/pip.js); without it the window detaches alone.
 */
export function createToolWindow({ css, tool, client, send, prefs = {}, documentRef = document, pip = null }) {
  const host = documentRef.createElement(TOOL_HOST_TAG);
  host.setAttribute('data-loop-player-tool', tool);
  const unregisterHost = registerHost(host);
  const shadow = host.attachShadow({ mode: 'closed' });
  setHTML(shadow, markup(tool));
  const root = shadow.querySelector('.lpo');
  const refs = Object.fromEntries([...shadow.querySelectorAll('[data-ref]')].map((element) => [element.dataset.ref, element]));
  root.tabIndex = -1;

  let position = { fx: clamp(Number(prefs.position?.fx ?? 1), 0, 1), fy: clamp(Number(prefs.position?.fy ?? 0), 0, 1) };
  let drag = null;
  let pipWindow = null;
  let toastTimer = null;
  let running = false;
  let destroyed = false;
  root.dataset.collapsed = String(prefs.collapsed === true);

  const view = () => host.ownerDocument.defaultView;

  function adoptStyles() {
    const sheet = new (view().CSSStyleSheet)();
    sheet.replaceSync(css);
    shadow.adoptedStyleSheets = [sheet];
  }

  function hostStyle(properties) {
    for (const [name, value] of Object.entries(properties)) host.style.setProperty(name, value, 'important');
  }

  function place(x, y) {
    if (pipWindow) return;
    const rect = root.getBoundingClientRect();
    const width = documentRef.documentElement.clientWidth || view().innerWidth;
    const height = view().innerHeight;
    const maxX = Math.max(MARGIN, width - rect.width - MARGIN);
    const maxY = Math.max(MARGIN, height - rect.height - MARGIN);
    const left = clamp(x ?? MARGIN + position.fx * (maxX - MARGIN), MARGIN, maxX);
    const top = clamp(y ?? MARGIN + position.fy * (maxY - MARGIN), MARGIN, maxY);
    if (x !== undefined) position = { fx: maxX > MARGIN ? (left - MARGIN) / (maxX - MARGIN) : 0, fy: maxY > MARGIN ? (top - MARGIN) / (maxY - MARGIN) : 0 };
    hostStyle({ left: `${Math.round(left)}px`, top: `${Math.round(top)}px` });
  }

  function savePrefs() {
    send({ type: 'TOOLS_WINDOW', tool, prefs: { position, collapsed: root.dataset.collapsed === 'true' } });
  }

  function flash(message) {
    clearTimeout(toastTimer);
    refs.toast.textContent = message;
    refs.toast.hidden = false;
    toastTimer = setTimeout(() => { refs.toast.hidden = true; }, 5000);
  }

  function renderSummary(summary) {
    refs.summary.textContent = summary.text;
    refs.summary.dataset.tone = summary.tuned ? 'tuned' : summary.text === '—' || summary.live === false ? 'dim' : '';
    if (refs.miniPlay) {
      running = summary.running;
      const name = running ? 'stop' : 'play';
      if (refs.miniPlay.dataset.icon !== name) { setHTML(refs.miniPlay, icon(name, { size: 16 })); refs.miniPlay.dataset.icon = name; }
      refs.miniPlay.setAttribute('aria-label', t(running ? 'tools.metronome.stop' : 'tools.metronome.start'));
    }
  }

  // Minimized, the pill keeps showing the live value, so the tool keeps listening.
  const panel = createToolsPanel({ client, mode: 'single', tool, documentRef, onSummary: renderSummary, onError: flash });
  refs.body.append(panel.element);

  function setCollapsed(collapsed) {
    root.dataset.collapsed = String(collapsed);
    place();
    root.focus({ preventScroll: true });
    savePrefs();
  }

  function onKeydown(event) {
    // Keys typed in a tool window never reach the page or its player shortcuts.
    event.stopPropagation();
    if (event.isTrusted && tool === 'metronome' && event.key.toLowerCase() === 't' && !event.repeat && !event.altKey && !event.ctrlKey && !event.metaKey && root.dataset.collapsed === 'true') {
      event.preventDefault();
      panel.tap();
    }
  }

  function returnToPage() {
    pipWindow = null;
    root.dataset.pip = 'false';
    if (destroyed) return;
    documentRef.documentElement.append(host);
    host.style.removeProperty('width');
    hostStyle({ position: 'fixed' });
    adoptStyles();
    setHTML(refs.pip, icon('pip', { size: 16 }));
    refs.pip.title = t('tools.window.popOutTitle');
    refs.pip.setAttribute('aria-label', t('tools.window.popOut'));
    place();
    panel.setActive(true);
  }

  // Leaves only this tool's tab when the window is shared with the controller or other tools.
  function exitPip() {
    if (!pipWindow) return;
    if (pip) pip.leave(tool);
    else pipWindow.close();
  }

  async function togglePip() {
    if (pipWindow) { exitPip(); return; }
    const size = { width: 300, height: Math.max(300, Math.round(root.getBoundingClientRect().height) + 8) };
    let slot;
    try {
      if (pip) {
        ({ window: pipWindow, slot } = await pip.enter({ id: tool, label: TOOL_LABELS[tool], icon: tool, size, onLeave: returnToPage }));
      } else {
        const pictureInPicture = view().documentPictureInPicture;
        if (!pictureInPicture?.requestWindow) throw new Error(t('tools.window.pipUnsupported'));
        pipWindow = await pictureInPicture.requestWindow(size);
        pipWindow.document.title = `${TOOL_LABELS[tool]} · Loop Player`;
        paintWindow(pipWindow);
        pipWindow.document.body.style.setProperty('margin', '0');
        slot = pipWindow.document.body;
        pipWindow.addEventListener('pagehide', returnToPage, { once: true });
      }
    } catch (error) {
      pipWindow = null;
      flash(error.message);
      return;
    }
    root.dataset.collapsed = 'false';
    root.dataset.pip = 'true';
    slot.append(host);
    hostStyle({ position: 'static', display: 'block', left: 'auto', top: 'auto', width: '100%' });
    adoptStyles();
    setHTML(refs.pip, icon('pipExit', { size: 16 }));
    refs.pip.title = t('tools.window.popIn');
    refs.pip.setAttribute('aria-label', t('tools.window.popIn'));
    pipWindow.document.addEventListener('keydown', onKeydown);
    panel.setActive(true);
  }


  root.addEventListener('keydown', onKeydown);
  for (const type of ['keyup', 'keypress']) root.addEventListener(type, (event) => event.stopPropagation());

  root.addEventListener('click', (event) => {
    if (!event.isTrusted) return;
    const button = event.target.closest('button');
    if (!button || button.disabled || !button.dataset.action) return;
    switch (button.dataset.action) {
      case 'close':
        exitPip();
        hostStyle({ display: 'none' });
        send({ type: 'TOOLS_WINDOW', tool, close: true });
        break;
      case 'collapse': setCollapsed(true); break;
      case 'expand': setCollapsed(false); break;
      case 'pip': togglePip(); break;
      case 'metronome': send({ type: 'TOOLS_METRONOME', running: !running }); break;
      default: break;
    }
  });

  root.addEventListener('pointerdown', (event) => {
    const handle = event.target.closest('[data-drag]');
    if (!handle || pipWindow || event.button !== 0 || event.target.closest('button, input, select')) return;
    const rect = host.getBoundingClientRect();
    drag = { id: event.pointerId, dx: event.clientX - rect.left, dy: event.clientY - rect.top };
    handle.setPointerCapture(event.pointerId);
    root.dataset.dragging = 'true';
    event.preventDefault();
  });
  root.addEventListener('pointermove', (event) => {
    if (drag?.id === event.pointerId) place(event.clientX - drag.dx, event.clientY - drag.dy);
  });
  const endDrag = (event) => {
    if (drag?.id !== event.pointerId) return;
    drag = null;
    root.dataset.dragging = 'false';
    savePrefs();
  };
  root.addEventListener('pointerup', endDrag);
  root.addEventListener('pointercancel', endDrag);

  const pageView = documentRef.defaultView;
  const onResize = () => place();
  pageView.addEventListener('resize', onResize);
  const onFullscreen = () => {
    if (pipWindow) return;
    const target = documentRef.fullscreenElement;
    const parent = target && target.localName !== 'iframe' ? target : documentRef.documentElement;
    if (host.parentNode !== parent) { parent.append(host); adoptStyles(); }
    place();
  };
  documentRef.addEventListener('fullscreenchange', onFullscreen);

  adoptStyles();
  hostStyle({ position: 'fixed', 'z-index': '2147483647', left: '0px', top: '0px', margin: '0', display: 'block' });
  documentRef.documentElement.append(host);
  place();
  panel.setActive(true);

  return {
    host,
    tool,
    destroy() {
      unregisterHost();
      destroyed = true;
      clearTimeout(toastTimer);
      panel.destroy();
      exitPip();
      pageView.removeEventListener('resize', onResize);
      documentRef.removeEventListener('fullscreenchange', onFullscreen);
      host.remove();
    },
  };
}
