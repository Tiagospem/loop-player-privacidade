// Round joystick pad for fine framing, shared by the panel and the floating controller.
// Holding the knob off-centre pans the focal point every animation frame; on release the knob
// springs back and the final view is handed over to be saved. Styles live in ui/kit.css (.stick).
import { panView, stickDeflection } from '../lib/framing.js';

const PREVIEW_INTERVAL = 33; // ms: about 30 live updates per second reach the player
const HEARTBEAT = 1000; // ms: a held but still knob keeps the live framing from expiring
const KEYS = { ArrowLeft: { x: -1, y: 0 }, ArrowRight: { x: 1, y: 0 }, ArrowUp: { x: 0, y: -1 }, ArrowDown: { x: 0, y: 1 } };

/**
 * @param {{
 *   pad: HTMLElement, knob: HTMLElement,
 *   start: () => ({view: object, mirror: boolean} | null),
 *   change: (view: object, session: object) => void,
 *   preview: (view: object, session: object) => void,
 *   finish: (view: object, session: object) => void,
 *   nudge: (direction: {x: number, y: number}, multiplier: number) => void,
 * }} options `session` is whatever start() returned for this drag.
 */
export function attachJoystick({ pad, knob, start, change, preview, finish, nudge }) {
  let drag = null;
  // The pad may move into a Picture-in-Picture window; always use its current window.
  const win = () => pad.ownerDocument.defaultView;

  function aim(event) {
    const rect = pad.getBoundingClientRect();
    const travel = Math.max(1, (rect.width - knob.offsetWidth) / 2 - 2);
    drag.deflection = stickDeflection(event.clientX - (rect.left + rect.width / 2), event.clientY - (rect.top + rect.height / 2), travel);
    knob.style.setProperty('transform', `translate(${(drag.deflection.x * travel).toFixed(1)}px, ${(drag.deflection.y * travel).toFixed(1)}px)`);
  }

  function send(now, force = false) {
    const key = `${drag.view.x}|${drag.view.y}`;
    if (force || (key !== drag.sentKey && now - drag.sentAt >= PREVIEW_INTERVAL) || now - drag.sentAt >= HEARTBEAT) {
      drag.sentAt = now;
      drag.sentKey = key;
      preview(drag.view, drag.session);
    }
  }

  function step(now) {
    if (!drag) return;
    const seconds = Math.max(0, (now - drag.time) / 1000);
    drag.time = now;
    const next = panView(drag.view, drag.deflection, seconds, drag.session.mirror);
    if (next && (next.x !== drag.view.x || next.y !== drag.view.y)) {
      drag.view = next;
      change(next, drag.session);
    }
    send(now);
    drag.frame = win().requestAnimationFrame(step);
  }

  pad.addEventListener('pointerdown', (event) => {
    if (drag || event.button !== 0 || event.target.closest('button') || pad.getAttribute('aria-disabled') === 'true') return;
    const session = start();
    if (!session?.view) return;
    event.preventDefault();
    pad.focus({ preventScroll: true });
    // Capture keeps the drag alive when the pointer leaves the pad.
    pad.setPointerCapture(event.pointerId);
    drag = { id: event.pointerId, session, view: session.view, deflection: { x: 0, y: 0 }, time: win().performance.now(), sentAt: -Infinity, sentKey: '', frame: 0 };
    pad.dataset.active = 'true';
    aim(event);
    drag.frame = win().requestAnimationFrame(step);
  });
  pad.addEventListener('pointermove', (event) => {
    if (drag?.id === event.pointerId) aim(event);
  });
  const end = (event) => {
    if (drag?.id !== event.pointerId) return;
    const { view, session, frame } = drag;
    win().cancelAnimationFrame(frame);
    drag = null;
    pad.dataset.active = 'false';
    knob.style.removeProperty('transform');
    preview(view, session);
    finish(view, session);
  };
  pad.addEventListener('pointerup', end);
  pad.addEventListener('pointercancel', end);
  pad.addEventListener('lostpointercapture', end);

  // Arrows move the framing only while the pad has focus; elsewhere they keep seeking.
  pad.addEventListener('keydown', (event) => {
    const direction = KEYS[event.key];
    if (!direction || event.altKey || event.ctrlKey || event.metaKey) return;
    event.preventDefault();
    event.stopPropagation();
    if (pad.getAttribute('aria-disabled') !== 'true') nudge(direction, event.shiftKey ? 4 : 1);
  });

  return {
    get active() { return drag !== null; },
  };
}
