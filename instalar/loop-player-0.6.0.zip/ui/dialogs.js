// Dialog helper shared by the panel modules.

// Resolves with the value of the clicked button ("cancel" on Esc). A late `close` event from an earlier
// dialog cannot answer this one.
export function ask(dialog) {
  dialog.showModal();
  return new Promise((resolve) => {
    const finish = (value) => {
      dialog.removeEventListener('click', onClick);
      dialog.removeEventListener('cancel', onCancel);
      if (dialog.open) dialog.close(value);
      resolve(value);
    };
    const onClick = (event) => {
      const button = event.target.closest('button[value]');
      if (!button || button.disabled) return;
      event.preventDefault();
      finish(button.value);
    };
    const onCancel = () => finish('cancel');
    dialog.addEventListener('click', onClick);
    dialog.addEventListener('cancel', onCancel);
  });
}
