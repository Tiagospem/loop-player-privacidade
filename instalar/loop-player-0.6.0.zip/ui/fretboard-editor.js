// Draw mode of the fretboard: mark notes with a color and a label, join them with lines, save the
// drawing by name and share it with other Loop Player users by code or `.loop` file (never a URL).
// The worker is the only writer of saved diagrams; the drawing being edited is a draft kept by this page.
// Saving, the saved list, importing and sharing each open their own dialog.
import { INTERVAL_SHORT, SCALE_GROUPS, MAX_FRET, degreeLabels, pitchClass, scaleIntervals, scalePositions, spellPitch, spellScale, tuningNames, tuningStrings } from '../lib/theory.js';
import {
  DIAGRAM_COLORS, MARK_LABELS, MAX_DIAGRAMS, MAX_LINES, cellKey, createDiagramFile, decodeDiagramCode, diagramFileName, encodeDiagramCode,
  hasContent, markText, mergeDiagrams, normalizeDiagram, parseDiagramFile, sanitizeDiagrams, saveDiagram, transposeDiagram,
} from '../lib/diagrams.js';
import { MAX_FILE_BYTES } from '../lib/share.js';
import { t, getLocale } from '../lib/i18n.js';
import { fretboardPng } from './fretboard-image.js';
import { ask } from './dialogs.js';
import { icon } from './icons.js';

const DIAGRAMS_KEY = 'loopPlayer.diagrams.v1';
const DRAFT_KEY = 'loopPlayer.fretboardDraft.v1';
const TOOLS = ['mark', 'line', 'erase'];
const HISTORY_LIMIT = 100;
const FINGERS = ['1', '2', '3', '4'];

const contentOf = (diagram) => JSON.stringify([diagram.name, diagram.root, diagram.scale, diagram.tuning, diagram.range, diagram.marks, diagram.lines]);
const sameStyle = (a, b) => a.color === b.color && a.label === b.label && a.text === b.text;
const fold = (text) => text.normalize('NFD').replace(/\p{M}/gu, '').toLowerCase();
const element = (tag, properties = {}) => Object.assign(document.createElement(tag), properties);

function download(blob, name) {
  const url = URL.createObjectURL(blob);
  const link = element('a', { href: url, download: name });
  document.body.append(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}

// The clipboard belongs to the window that has focus (the page or the Picture-in-Picture window).
// Older permission states still allow copying the selected text of a click.
async function writeClipboard(text, field) {
  const view = field.ownerDocument.defaultView;
  try { await view.navigator.clipboard.writeText(text); return true; } catch {
    field.focus();
    field.select();
    try { return field.ownerDocument.execCommand('copy'); } catch { return false; }
  }
}

// Saved diagrams live in the worker; the static preview (no extension) keeps them in this browser.
function diagramStore(isExtension) {
  if (isExtension) {
    const send = async (message) => {
      const response = await chrome.runtime.sendMessage(message);
      if (!response?.ok) throw new Error(response?.error || t('common.extensionNoResponse'));
      return response;
    };
    return {
      list: async () => sanitizeDiagrams((await send({ type: 'GET_DIAGRAMS' })).diagrams),
      save: (diagram) => send({ type: 'SAVE_DIAGRAM', diagram }),
      remove: (id) => send({ type: 'DELETE_DIAGRAM', id }),
      import: (diagrams) => send({ type: 'IMPORT_DIAGRAMS', diagrams }),
      watch: (callback) => chrome.storage.onChanged.addListener((changes, area) => {
        if (area === 'local' && changes[DIAGRAMS_KEY]) callback(sanitizeDiagrams(changes[DIAGRAMS_KEY].newValue));
      }),
    };
  }
  const read = () => { try { return sanitizeDiagrams(JSON.parse(localStorage.getItem(DIAGRAMS_KEY) || '[]')); } catch { return []; } };
  const write = (diagrams) => { localStorage.setItem(DIAGRAMS_KEY, JSON.stringify(diagrams)); return diagrams; };
  return {
    list: async () => read(),
    save: async (raw) => { const { diagram, diagrams } = saveDiagram(read(), raw); return { diagram, diagrams: write(diagrams) }; },
    remove: async (id) => ({ diagrams: write(read().filter((item) => item.id !== id)) }),
    import: async (incoming) => { const { diagrams, ...summary } = mergeDiagrams(read(), incoming); return { summary, diagrams: write(diagrams) }; },
    watch: () => {},
  };
}

async function loadDraft(isExtension) {
  try {
    if (isExtension) return (await chrome.storage.local.get(DRAFT_KEY))[DRAFT_KEY];
    return JSON.parse(localStorage.getItem(DRAFT_KEY) || 'null');
  } catch { return null; }
}

/**
 * @param {object} page
 * @param {() => object} page.view Current page view: {hand, high, labels}.
 * @param {() => void} page.render Redraws the whole page.
 * @param {(message: string, options?: {tone?: string, action?: {label: string, run: () => void}}) => void} page.toast
 * @param {boolean} page.isExtension
 * @param {() => boolean} page.active Whether the draw mode is on screen.
 * @param {(selector: string) => Element | null} page.$ Finds an element in the page or in the Picture-in-Picture window.
 * @param {(selector: string) => Element[]} page.$$
 * @param {() => Element | null} page.activeElement Focused element of the window that shows the board.
 * @param {() => HTMLElement} page.imageHost Where the PNG is drawn, so it gets the board's styles.
 */
export async function createEditor({ view, render, toast, isExtension, active, $, $$, activeElement, imageHost }) {
  const store = diagramStore(isExtension);
  const draft = await loadDraft(isExtension);
  let diagram = normalizeDiagram(draft?.diagram);
  // Content of the saved copy the draft started from (null for a drawing never saved).
  let baseline = typeof draft?.baseline === 'string' ? draft.baseline : null;
  let tool = TOOLS.includes(draft?.tool) ? draft.tool : 'mark';
  let color = Number.isInteger(draft?.color) && draft.color >= 0 && draft.color < DIAGRAM_COLORS.length ? draft.color : 0;
  let label = MARK_LABELS.includes(draft?.label) ? draft.label : 'note';
  let text = markText(draft?.text || '');
  let pending = null;
  let past = [];
  let future = [];
  let diagrams = [];
  let search = '';
  let deleted = null;
  let draftTimer;

  const saved = () => diagrams.find((item) => item.id === diagram.id);
  const isDirty = () => baseline === null ? hasContent(diagram) : contentOf(diagram) !== baseline;

  function persistDraft() {
    clearTimeout(draftTimer);
    draftTimer = setTimeout(() => {
      const value = { diagram, baseline, tool, color, label, text };
      try {
        if (isExtension) chrome.storage.local.set({ [DRAFT_KEY]: value });
        else localStorage.setItem(DRAFT_KEY, JSON.stringify(value));
      } catch { /* The draft is a convenience. */ }
    }, 250);
  }

  function change(patch) {
    past = [...past.slice(-(HISTORY_LIMIT - 1)), diagram];
    future = [];
    diagram = normalizeDiagram({ ...diagram, ...patch });
    persistDraft();
    render();
  }

  function undo() {
    if (!past.length) return;
    future = [diagram, ...future];
    diagram = past.at(-1);
    past = past.slice(0, -1);
    pending = null;
    persistDraft();
    render();
  }

  function redo() {
    if (!future.length) return;
    past = [...past, diagram];
    diagram = future[0];
    future = future.slice(1);
    persistDraft();
    render();
  }

  // Opens another drawing in the editor (a saved one, a new one or one made in Explore).
  function open(next, { savedCopy = null } = {}) {
    diagram = normalizeDiagram(next);
    baseline = savedCopy ? contentOf(normalizeDiagram(savedCopy)) : null;
    past = [];
    future = [];
    pending = null;
    persistDraft();
    render();
  }

  // Unsaved work is never dropped silently.
  async function confirmLeave() {
    if (!isDirty()) return true;
    const answer = await ask($('#discard-dialog'));
    if (answer === 'save') return baseline === null ? saveDialog() : save();
    return answer === 'discard';
  }

  // Labels -------------------------------------------------------------------------------------------
  const pcAt = (cell) => pitchClass(tuningStrings(diagram.tuning)[cell.string] + cell.fret);
  const keyScale = () => diagram.scale || 'major';

  function degreeOf(pc) {
    if (diagram.scale) {
      const index = scaleIntervals(diagram.scale).findIndex((interval) => pitchClass(diagram.root + interval) === pc);
      if (index >= 0) return degreeLabels(diagram.scale)[index];
    }
    return INTERVAL_SHORT[pitchClass(pc - diagram.root)];
  }

  function markLabel(mark) {
    if (mark.label === 'note') return spellPitch(pcAt(mark), diagram.root, keyScale());
    if (mark.label === 'degree') return degreeOf(pcAt(mark));
    return mark.label === 'text' ? mark.text : '';
  }

  const keyName = (item = diagram) => spellScale(item.root, item.scale || 'major').root;
  const stringNumber = (string) => 6 - string;

  // Neck model ---------------------------------------------------------------------------------------
  function dots() {
    const marked = new Set(diagram.marks.map(cellKey));
    const ghosts = diagram.scale
      ? scalePositions({ rootPc: diagram.root, scaleId: diagram.scale, tuning: diagram.tuning, range: diagram.range })
        .filter((cell) => !marked.has(cellKey(cell)))
        .map((cell) => ({ string: cell.string, fret: cell.fret, kind: 'ghost', text: view().labels === 'degrees' ? cell.label : cell.name }))
      : [];
    return [...ghosts, ...diagram.marks.map((mark) => ({
      string: mark.string, fret: mark.fret, kind: 'mark', color: DIAGRAM_COLORS[mark.color], text: markLabel(mark),
      title: t('fretboard.noteTitle', { note: spellPitch(pcAt(mark), diagram.root, keyScale()), label: degreeOf(pcAt(mark)), string: stringNumber(mark.string), fret: mark.fret }),
    }))];
  }

  const inRange = (cell) => cell.fret >= diagram.range.from && cell.fret <= diagram.range.to;
  const lines = () => diagram.lines.filter((line) => inRange(line.a) && inRange(line.b)).map((line) => ({ ...line, color: DIAGRAM_COLORS[line.color] }));

  function model() {
    return {
      range: diagram.range, leftHanded: view().hand === 'left', highOnTop: view().high === 'top', stringNames: tuningNames(diagram.tuning),
      interactive: true, dots: dots(), lines: lines(), pending,
    };
  }

  // Editing ------------------------------------------------------------------------------------------
  function cell(target) {
    const key = cellKey(target);
    if (tool === 'mark') {
      const mark = { string: target.string, fret: target.fret, color, label, text: label === 'text' ? markText(text) : '' };
      if (mark.label === 'text' && !mark.text) mark.label = 'none';
      const existing = diagram.marks.find((item) => cellKey(item) === key);
      const others = diagram.marks.filter((item) => cellKey(item) !== key);
      change({ marks: existing && sameStyle(existing, mark) ? others : [...others, mark] });
    } else if (tool === 'line') {
      if (!pending) { pending = target; render(); return; }
      const start = pending;
      pending = null;
      if (cellKey(start) === key) { render(); return; }
      const same = (line) => [cellKey(line.a), cellKey(line.b)].sort().join() === [cellKey(start), key].sort().join();
      const existing = diagram.lines.find(same);
      if (!existing && diagram.lines.length >= MAX_LINES) { toast(t('fretboard.draw.lineLimit', { max: MAX_LINES })); render(); return; }
      const others = diagram.lines.filter((line) => !same(line));
      change({ lines: existing && existing.color === color ? others : [...others, { a: start, b: target, color }] });
    } else {
      const marks = diagram.marks.filter((item) => cellKey(item) !== key);
      const kept = diagram.lines.filter((line) => cellKey(line.a) !== key && cellKey(line.b) !== key);
      if (marks.length !== diagram.marks.length || kept.length !== diagram.lines.length) change({ marks, lines: kept });
    }
  }

  // Changing the key moves the drawing with it, by the shortest way (up to a fifth up or a tritone down).
  function setKey(pc) {
    const step = ((pc - diagram.root + 18) % 12) - 6;
    if (!step) return;
    const result = transposeDiagram(diagram, step);
    change({ root: result.diagram.root, range: result.diagram.range, marks: result.diagram.marks, lines: result.diagram.lines });
    if (result.wrapped) toast(t('fretboard.draw.wrapped'));
  }

  // Saving -------------------------------------------------------------------------------------------
  async function save({ copy = false } = {}) {
    if (!hasContent(diagram)) { toast(t('fretboard.draw.needsMarks'), { tone: 'danger' }); return false; }
    try {
      const { id, ...content } = diagram;
      const response = await store.save(copy ? content : { ...content, id });
      diagrams = sanitizeDiagrams(response.diagrams);
      diagram = normalizeDiagram(response.diagram);
      baseline = contentOf(diagram);
      persistDraft();
      render();
      toast(t('fretboard.draw.saved'));
      return true;
    } catch (error) {
      toast(t('fretboard.draw.saveFailed', { error: error.message }), { tone: 'danger' });
      return false;
    }
  }

  // Asks for the name (and offers a copy when the diagram is already saved), then saves.
  async function saveDialog() {
    if (!hasContent(diagram)) { toast(t('fretboard.draw.needsMarks'), { tone: 'danger' }); return false; }
    const input = $('#save-name');
    input.value = baseline === null && diagram.name === t('fretboard.draw.untitled') ? '' : diagram.name;
    $('#save-copy').hidden = baseline === null;
    const onKey = (event) => { if (event.key === 'Enter') { event.preventDefault(); $('#save-confirm').click(); } };
    input.addEventListener('keydown', onKey);
    setTimeout(() => { input.focus(); input.select(); }, 0);
    const answer = await ask($('#save-dialog'));
    input.removeEventListener('keydown', onKey);
    if (answer !== 'save' && answer !== 'copy') return false;
    const name = normalizeDiagram({ name: input.value }).name;
    if (name !== diagram.name) change({ name });
    return save({ copy: answer === 'copy' });
  }

  async function remove(id) {
    const removed = diagrams.find((item) => item.id === id);
    if (!removed) return;
    try {
      diagrams = sanitizeDiagrams((await store.remove(id)).diagrams);
      if (diagram.id === id) baseline = null;
      deleted = removed;
      persistDraft();
      render();
    } catch (error) {
      toast(error.message, { tone: 'danger' });
    }
  }

  async function restoreDeleted() {
    const removed = deleted;
    if (!removed) return;
    deleted = null;
    diagrams = sanitizeDiagrams((await store.import([removed])).diagrams);
    if (diagram.id === removed.id && contentOf(diagram) === contentOf(removed)) baseline = contentOf(removed);
    render();
  }

  // The saved list: open or delete; deleting can be undone right there.
  async function libraryDialog() {
    search = '';
    deleted = null;
    $('#diagrams-search').value = '';
    renderList();
    let chosen = null;
    const onClick = (event) => { chosen = event.target.closest('[data-open]')?.dataset.open ?? chosen; };
    $('#diagrams-list').addEventListener('click', onClick);
    const answer = await ask($('#library-dialog'));
    $('#diagrams-list').removeEventListener('click', onClick);
    deleted = null;
    if (answer !== 'open' || !chosen) return;
    const target = diagrams.find((item) => item.id === chosen);
    if (!target || (target.id === diagram.id && !isDirty())) return;
    if (await confirmLeave()) open(target, { savedCopy: target });
  }

  // Sharing ------------------------------------------------------------------------------------------
  function downloadDiagrams(list) {
    const shareable = list.filter(hasContent);
    if (!shareable.length) { toast(t('fretboard.code.nothingToShare'), { tone: 'danger' }); return false; }
    const file = createDiagramFile(shareable, { appVersion: globalThis.chrome?.runtime?.getManifest?.().version || '' });
    download(new Blob([JSON.stringify(file, null, 2)], { type: 'application/json' }), diagramFileName(shareable));
    return true;
  }

  async function downloadImage() {
    const subtitle = diagram.scale ? t('fretboard.scaleName', { root: keyName(), scale: t(`fretboard.scales.${diagram.scale}`) }) : '';
    const blob = await fretboardPng({ model: { ...model(), pending: null }, title: diagram.name, subtitle, footer: t('fretboard.image.footer'), container: imageHost() });
    download(blob, diagramFileName([diagram]).replace(/\.loop$/, '.png'));
  }

  async function shareDialog() {
    let code;
    try { code = encodeDiagramCode(diagram); } catch (error) { toast(error.message, { tone: 'danger' }); return; }
    $('#share-code').value = code;
    $('#share-status').textContent = '';
    await ask($('#share-dialog'));
  }

  const shareStatus = (message) => { $('#share-status').textContent = message; };

  // Import: a pasted code or a chosen file is checked and previewed; nothing is saved before confirming.
  async function importDialog() {
    const code = $('#import-code');
    const preview = $('#import-preview');
    const error = $('#import-error');
    const confirm = $('#import-confirm');
    let incoming = [];
    code.value = '';
    $('#import-file').value = '';
    $('#import-file-name').textContent = '';
    const show = (list, ignored = 0, problem = '') => {
      incoming = list;
      confirm.disabled = !list.length;
      error.hidden = !problem;
      error.textContent = problem;
      preview.hidden = !list.length;
      preview.replaceChildren();
      if (!list.length) return;
      const items = element('ul');
      items.append(...list.slice(0, 8).map((item) => {
        const row = element('li');
        row.append(element('strong', { textContent: item.name }), document.createTextNode(` · ${t('fretboard.draw.marks', { count: item.marks.length })}`));
        return row;
      }));
      if (list.length > 8) items.append(element('li', { textContent: '…' }));
      preview.append(element('p', { textContent: t('fretboard.import.preview', { count: list.length }) }), items);
      if (ignored) preview.append(element('p', { className: 'hint', textContent: t('fretboard.import.ignored', { count: ignored }) }));
    };
    show([]);
    const onInput = () => {
      if (!code.value.trim()) { show([]); return; }
      $('#import-file-name').textContent = '';
      try { show([decodeDiagramCode(code.value).diagram]); } catch (problem) { show([], 0, problem.message); }
    };
    const onPick = () => $('#import-file').click();
    const onFile = async () => {
      const file = $('#import-file').files?.[0];
      if (!file) return;
      code.value = '';
      $('#import-file-name').textContent = file.name;
      try {
        if (file.size > MAX_FILE_BYTES) throw new Error(t('share.file.tooLarge'));
        const parsed = parseDiagramFile(await file.text());
        show(parsed.diagrams, parsed.ignored);
      } catch (problem) {
        show([], 0, problem.message);
      }
    };
    code.addEventListener('input', onInput);
    $('#import-pick').addEventListener('click', onPick);
    $('#import-file').addEventListener('change', onFile);
    setTimeout(() => code.focus(), 0);
    const answer = await ask($('#import-dialog'));
    code.removeEventListener('input', onInput);
    $('#import-pick').removeEventListener('click', onPick);
    $('#import-file').removeEventListener('change', onFile);
    if (answer !== 'import' || !incoming.length) return;
    try {
      const { summary, diagrams: list } = await store.import(incoming);
      diagrams = sanitizeDiagrams(list);
      const parts = [];
      if (summary.added) parts.push(t('fretboard.import.added', { count: summary.added }));
      if (summary.updated) parts.push(t('fretboard.import.updated', { count: summary.updated }));
      if (summary.skipped) parts.push(t('fretboard.import.skipped', { count: summary.skipped, max: MAX_DIAGRAMS }));
      toast(parts.join(' ') || t('fretboard.import.nothing'));
      const first = diagrams.find((item) => item.id === summary.ids?.[0]);
      if (first && await confirmLeave()) open(first, { savedCopy: first });
      else render();
    } catch (problem) {
      toast(problem.message, { tone: 'danger' });
    }
  }

  // Controls -----------------------------------------------------------------------------------------
  const colorButtons = DIAGRAM_COLORS.map((value, index) => {
    const button = element('button', { type: 'button', className: 'swatch', title: t(`fretboard.draw.colors.${index}`) });
    button.setAttribute('role', 'radio');
    button.setAttribute('aria-label', t(`fretboard.draw.colors.${index}`));
    button.dataset.color = String(index);
    button.style.setProperty('--swatch', value);
    return button;
  });
  $('#draw-colors').append(...colorButtons);
  $('#draw-fingers').append(...FINGERS.map((finger) => {
    const button = element('button', { type: 'button', className: 'chip', textContent: finger, title: t('fretboard.draw.finger', { finger }) });
    button.dataset.finger = finger;
    return button;
  }));
  $('#draw-scale').append(
    element('option', { value: '', textContent: t('fretboard.draw.backgroundNone') }),
    ...SCALE_GROUPS.map((group) => {
      const optgroup = element('optgroup', { label: t(`fretboard.group.${group.id}`) });
      optgroup.append(...group.scales.map((id) => element('option', { value: id, textContent: t(`fretboard.scales.${id}`) })));
      return optgroup;
    }),
  );
  $('#draw-from').append(...Array.from({ length: MAX_FRET - 3 }, (_, fret) => element('option', { value: String(fret), textContent: String(fret) })));
  $('#draw-to').append(...Array.from({ length: MAX_FRET - 4 }, (_, index) => element('option', { value: String(index + 5), textContent: String(index + 5) })));

  const pick = (selector, attribute, callback) => $(selector).addEventListener('click', (event) => {
    const button = event.target.closest(`[${attribute}]`);
    if (button) callback(button.getAttribute(attribute));
  });
  const setStyle = (patch) => {
    tool = patch.tool ?? tool;
    color = patch.color ?? color;
    label = patch.label ?? label;
    text = patch.text ?? text;
    pending = null;
    persistDraft();
    render();
  };
  pick('#draw-tool', 'data-tool', (next) => setStyle({ tool: next }));
  // Picking a color or a label goes back to marking.
  pick('#draw-colors', 'data-color', (next) => setStyle({ color: Number(next), tool: tool === 'erase' ? 'mark' : tool }));
  pick('#draw-label', 'data-label', (next) => {
    setStyle({ label: next, tool: 'mark' });
    if (next === 'text') $('#draw-text').focus();
  });
  pick('#draw-fingers', 'data-finger', (finger) => {
    $('#draw-text').value = finger;
    setStyle({ text: finger, tool: 'mark' });
  });
  $('#draw-text').addEventListener('input', (event) => { text = markText(event.target.value); persistDraft(); renderControls(); });
  $('#draw-key').addEventListener('change', (event) => setKey(Number(event.target.value)));
  $('#draw-scale').addEventListener('change', (event) => change({ scale: event.target.value }));
  $('#draw-from').addEventListener('change', (event) => {
    const from = Number(event.target.value);
    change({ range: { from, to: Math.max(diagram.range.to, from + 4) } });
  });
  $('#draw-to').addEventListener('change', (event) => {
    const to = Number(event.target.value);
    change({ range: { from: Math.min(diagram.range.from, to - 4), to } });
  });
  $('#draw-undo').addEventListener('click', undo);
  $('#draw-redo').addEventListener('click', redo);
  $('#draw-clear').addEventListener('click', () => {
    if (!hasContent(diagram)) return;
    change({ marks: [], lines: [] });
    toast(t('fretboard.draw.cleared'), { action: { label: t('fretboard.draw.undoAction'), run: undo } });
  });

  $('#diagram-save').addEventListener('click', () => saveDialog());
  $('#diagram-library').addEventListener('click', libraryDialog);
  $('#diagram-import').addEventListener('click', importDialog);
  $('#diagram-share').addEventListener('click', shareDialog);
  $('#diagram-new').addEventListener('click', async () => {
    if (!await confirmLeave()) return;
    open({ root: diagram.root, scale: diagram.scale, tuning: diagram.tuning, range: diagram.range });
  });
  $('#share-copy').addEventListener('click', async () => {
    const field = $('#share-code');
    shareStatus(t(await writeClipboard(field.value, field) ? 'fretboard.draw.codeCopied' : 'fretboard.draw.codeNotCopied'));
  });
  $('#share-file').addEventListener('click', () => { if (downloadDiagrams([diagram])) shareStatus(t('fretboard.share.fileSaved')); });
  $('#share-png').addEventListener('click', () => downloadImage().then(() => shareStatus(t('fretboard.share.imageSaved')), () => shareStatus(t('fretboard.draw.imageFailed'))));
  $('#diagrams-export').addEventListener('click', () => downloadDiagrams(diagrams));
  $('#diagrams-search').addEventListener('input', (event) => { search = event.target.value; renderList(); });
  $('#diagrams-list').addEventListener('click', (event) => {
    const removeButton = event.target.closest('[data-delete]');
    if (removeButton) remove(removeButton.dataset.delete);
    else if (event.target.closest('[data-restore]')) restoreDeleted();
  });

  // Shortcuts, from the page or the Picture-in-Picture window.
  function keydown(event) {
    if (!active()) return;
    const typing = event.target.closest?.('input, textarea, select, dialog');
    const command = event.metaKey || event.ctrlKey;
    if (command && event.key.toLowerCase() === 's') {
      event.preventDefault();
      if (!event.target.closest?.('dialog')) (baseline === null ? saveDialog() : save());
      return;
    }
    if (typing) return;
    if (command && event.key.toLowerCase() === 'z') { event.preventDefault(); if (event.shiftKey) redo(); else undo(); }
    else if (command && event.key.toLowerCase() === 'y') { event.preventDefault(); redo(); }
    else if (event.key === 'Escape' && pending) { pending = null; render(); }
  }

  // Rendering ----------------------------------------------------------------------------------------
  function renderStatus() {
    const status = $('#diagram-status');
    const state = baseline === null ? 'new' : isDirty() ? 'dirty' : 'saved';
    status.textContent = t(`fretboard.draw.status.${state}`);
    status.dataset.tone = state === 'saved' ? 'live' : state === 'dirty' ? 'warn' : '';
    $('#diagram-title').textContent = diagram.name;
    $('#diagram-counts').textContent = `${t('fretboard.draw.marks', { count: diagram.marks.length })} · ${t('fretboard.draw.lines', { count: diagram.lines.length })}`;
    $('#diagrams-count').textContent = String(diagrams.length);
  }

  function renderList() {
    const date = new Intl.DateTimeFormat(getLocale(), { dateStyle: 'short' });
    const query = fold(search.trim());
    const visible = query ? diagrams.filter((item) => fold(item.name).includes(query)) : diagrams;
    $('#diagrams-search-row').hidden = diagrams.length < 6;
    $('#diagrams-empty').hidden = diagrams.length > 0 || Boolean(deleted);
    $('#diagrams-no-results').hidden = !diagrams.length || visible.length > 0;
    $('#diagrams-export').disabled = !diagrams.length;
    const rows = visible.map((item) => {
      const row = element('li', { className: 'diagram-item' });
      if (item.id === diagram.id) row.setAttribute('aria-current', 'true');
      const openButton = element('button', { type: 'button', value: 'open', className: 'diagram-open', title: t('fretboard.draw.open', { name: item.name }) });
      openButton.dataset.open = item.id;
      openButton.append(
        element('strong', { textContent: item.name }),
        element('span', { textContent: t('fretboard.draw.meta', { key: item.scale ? t('fretboard.scaleName', { root: keyName(item), scale: t(`fretboard.scales.${item.scale}`) }) : keyName(item), marks: t('fretboard.draw.marks', { count: item.marks.length }), date: date.format(item.updatedAt) }) }),
      );
      const removeButton = element('button', { type: 'button', className: 'icon-btn icon-btn-sm icon-btn-danger', title: t('fretboard.draw.delete', { name: item.name }) });
      removeButton.setAttribute('aria-label', t('fretboard.draw.delete', { name: item.name }));
      removeButton.dataset.delete = item.id;
      removeButton.insertAdjacentHTML('afterbegin', icon('trash', { size: 14 }));
      row.append(openButton, removeButton);
      return row;
    });
    if (deleted) {
      const notice = element('li', { className: 'diagram-deleted' });
      const undoButton = element('button', { type: 'button', className: 'btn btn-ghost btn-sm', textContent: t('fretboard.draw.undoAction') });
      undoButton.dataset.restore = '';
      notice.append(element('span', { textContent: t('fretboard.draw.deleted', { name: deleted.name }) }), undoButton);
      rows.unshift(notice);
    }
    $('#diagrams-list').replaceChildren(...rows);
  }

  function renderControls() {
    for (const button of $$('#draw-tool [data-tool]')) button.setAttribute('aria-checked', String(button.dataset.tool === tool));
    for (const button of colorButtons) button.setAttribute('aria-checked', String(Number(button.dataset.color) === color));
    for (const button of $$('#draw-label [data-label]')) button.setAttribute('aria-checked', String(button.dataset.label === label));
    $('#draw-text-row').hidden = label !== 'text';
    if (activeElement() !== $('#draw-text')) $('#draw-text').value = text;
    for (const button of $$('#draw-fingers [data-finger]')) button.setAttribute('aria-pressed', String(button.dataset.finger === text));
    $('#draw-key').replaceChildren(...Array.from({ length: 12 }, (_, pc) => element('option', { value: String(pc), textContent: spellScale(pc, keyScale()).root })));
    $('#draw-key').value = String(diagram.root);
    $('#draw-scale').value = diagram.scale;
    $('#draw-from').value = String(diagram.range.from);
    $('#draw-to').value = String(diagram.range.to);
    $('#draw-undo').disabled = !past.length;
    $('#draw-redo').disabled = !future.length;
    $('#draw-clear').disabled = !hasContent(diagram);
    const hint = $('#draw-hint');
    hint.hidden = false;
    hint.textContent = t(`fretboard.draw.hint.${tool === 'line' && pending ? 'lineStart' : tool}`);
  }

  diagrams = await store.list().catch(() => []);
  // A diagram deleted elsewhere keeps its drawing here, now unsaved.
  if (baseline !== null && !diagrams.some((item) => item.id === diagram.id)) baseline = null;
  store.watch((list) => {
    diagrams = list;
    if (baseline !== null && !saved()) baseline = null;
    if (active()) render();
  });

  return {
    model,
    cell,
    keydown,
    title: () => diagram.name,
    open: async (next) => { if (await confirmLeave()) { open(next); return true; } return false; },
    tuning: () => diagram.tuning,
    setTuning: (value) => change({ tuning: value }),
    render() {
      if (!active()) { $('#draw-hint').hidden = true; return; }
      renderControls();
      renderStatus();
      if ($('#library-dialog').open) renderList();
    },
  };
}
