// Backup and data safety in Ajustes: the automatic backup folder, export and import of a backup file,
// restore points and the trash. The folder is picked, re-authorized and read in an extension tab,
// because Chrome closes the toolbar popup when a file chooser or a permission prompt opens.
import { backupFileName, compareLibraries, mergeLibrary, parseBackup } from '../lib/backup.js';
import { folderPermission, listFolderBackups, loadFolderHandle, readFolderBackup, saveFolderHandle } from '../lib/backup-writer.js';
import { MAX_FILE_BYTES } from '../lib/share.js';
import { ask } from './dialogs.js';
import { t, getLocale } from '../lib/i18n.js';

const $ = (selector) => document.querySelector(selector);
const count = (key, value) => t(key, { count: value });
const DAY_MS = 24 * 60 * 60 * 1000;
const REASONS = { 'import-backup': 'backup.reason.importBackup', 'import-loops': 'backup.reason.importLoops', restore: 'backup.reason.restore' };

export function ago(timestamp, now = Date.now()) {
  const minutes = Math.floor(Math.max(0, now - timestamp) / 60000);
  if (minutes < 1) return t('backup.ago.now');
  if (minutes < 60) return t('backup.ago.minutes', { count: minutes });
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return t('backup.ago.hours', { count: hours });
  return count('backup.ago.days', Math.floor(hours / 24));
}
const when = (timestamp) => new Date(timestamp).toLocaleString(getLocale(), { dateStyle: 'short', timeStyle: 'short' });
const formatDay = (day) => new Date(`${day}T12:00:00`).toLocaleDateString(getLocale(), { dateStyle: 'short' });

// Title, explanation and actions for each state the worker reports.
export function folderView(status, now = Date.now()) {
  const name = status.name ? `“${status.name}”` : t('backup.folder.chosen');
  const last = status.lastBackupAt ? t('backup.status.lastSentence', { ago: ago(status.lastBackupAt, now) }) : t('backup.status.never');
  switch (status.state) {
    case 'ok': return { title: t('backup.status.okTitle', { ago: ago(status.lastBackupAt, now) }), detail: t('backup.status.okDetail', { name }), actions: ['choose', 'restore', 'forget'] };
    case 'needs-permission': return { title: t('backup.status.permissionTitle'), detail: t('backup.status.permissionDetail', { name, last }), actions: ['authorize', 'choose', 'forget'] };
    case 'unavailable': return { title: t('backup.status.unavailableTitle'), detail: t('backup.status.unavailableDetail', { name, last }), actions: ['retry', 'choose', 'forget'] };
    case 'error': return { title: t('backup.status.errorTitle'), detail: `${status.error || t('backup.status.unknownError')} ${last}`, actions: ['retry', 'choose', 'forget'] };
    default: return { title: t('backup.status.offTitle'), detail: t('backup.status.offDetail'), actions: ['choose'] };
  }
}

function element(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

function row(title, detail, button) {
  const item = element('div', 'mini-row');
  const copy = element('span', 'mini-copy');
  copy.append(element('strong', '', title), element('small', '', detail));
  item.append(copy, button);
  return item;
}

/**
 * @param {object} app
 * @param {() => object} app.context Current panel state (library, backupFolder, trashCount, restorePoints).
 * @param {(patch: object) => void} app.update Applies a partial state and re-renders the panel.
 * @param {(file: File) => Promise<void>} app.importLoops Receives a shared-loops file picked here.
 */
export function setupBackup({ context, request, toast, confirmAction, update, importLoops, isExtension, isWorkspace }) {
  const pickInTab = isExtension && !isWorkspace;
  let renderKey = '';

  function openInTab() {
    chrome.tabs.create({ url: chrome.runtime.getURL('app.html?view=settings#backup') });
    window.close();
  }

  const undoAction = (point, message) => point ? { label: t('backup.undo'), run: () => undoRestorePoint(point.id, message) } : null;

  async function undoRestorePoint(id, message) {
    const response = await request({ type: 'UNDO_RESTORE_POINT', id });
    if (!response) return;
    update({ library: response.library, trashCount: response.trashCount, pageShortcuts: response.pageShortcuts, overlay: response.overlay, restorePoints: response.restorePoints });
    toast(message);
  }

  // Export and import of a backup file.
  async function exportFile() {
    const response = await request({ type: 'EXPORT_BACKUP' });
    if (!response) return;
    const url = URL.createObjectURL(new Blob([`${JSON.stringify(response.backup, null, 2)}\n`], { type: 'application/json' }));
    Object.assign(document.createElement('a'), { href: url, download: backupFileName() }).click();
    setTimeout(() => URL.revokeObjectURL(url), 60000);
    toast(count('backup.export.done', response.backup.library.length));
  }

  // One importer for both kinds of Loop Player file: shared loops go to the sharing confirmation.
  async function importFile(file) {
    if (!file) return;
    let text;
    let backup;
    try {
      if (file.size > MAX_FILE_BYTES) throw new Error(t('share.file.tooLarge'));
      text = await file.text();
      backup = parseBackup(text);
    } catch (error) {
      if (error.kind === 'loops') await importLoops(file);
      else toast(error.message, true);
      return;
    }
    const preview = mergeLibrary(context().library, backup.library);
    const changes = [
      preview.added && count('backup.import.added', preview.added),
      preview.updated && count('backup.import.merged', preview.updated),
      preview.unchanged && count('backup.import.unchanged', preview.unchanged),
    ].filter(Boolean);
    const details = [
      `${changes.join(', ') || t('backup.import.none')}.`,
      preview.skipped ? count('backup.import.skipped', preview.skipped) : '',
      backup.ignored ? count('backup.import.ignored', backup.ignored) : '',
      t('backup.import.note'),
    ].filter(Boolean).join(' ');
    if (!await confirmAction(t('backup.import.title'), details, { label: t('backup.import.confirm'), danger: false })) return;
    const response = await request({ type: 'IMPORT_BACKUP', backup: text });
    if (!response) return;
    update({ library: response.library, pageShortcuts: response.pageShortcuts, overlay: response.overlay });
    const { added, updated } = response.summary;
    toast(added || updated ? t('backup.import.done', { added: count('backup.import.added', added), merged: count('backup.import.mergedShort', updated) }) : t('backup.import.upToDate'), false, added || updated ? undoAction(response.restorePoint, t('backup.import.undone')) : null);
  }

  // The automatic backup folder.
  async function chooseFolder() {
    if (pickInTab) return openInTab();
    if (!isExtension || typeof globalThis.showDirectoryPicker !== 'function') { toast(t('backup.folder.previewOnly'), true); return; }
    let directory;
    try {
      directory = await globalThis.showDirectoryPicker({ id: 'loop-player-backup', mode: 'readwrite', startIn: 'documents' });
    } catch (error) {
      if (error?.name !== 'AbortError') toast(t('backup.folder.blocked'), true);
      return;
    }
    await saveFolderHandle(directory);
    await runNow(t('backup.folder.savedIn', { name: directory.name }), 'BACKUP_FOLDER_CHANGED');
  }

  async function runNow(message, type = 'BACKUP_FOLDER_RUN') {
    const response = await request({ type });
    if (!response) return;
    update({ backupFolder: response.backupFolder });
    if (response.backupFolder.state === 'ok') toast(message);
    else toast(folderView(response.backupFolder).title, true);
  }

  async function authorize() {
    if (pickInTab) return openInTab();
    const directory = await loadFolderHandle().catch(() => null);
    if (!directory) return chooseFolder();
    const state = await folderPermission(directory, { request: true }).catch(() => 'denied');
    if (state !== 'granted') { toast(t('backup.folder.permissionDenied'), true); return; }
    await runNow(t('backup.folder.permissionRenewed'));
  }

  async function forget() {
    const { name } = context().backupFolder || {};
    if (!await confirmAction(t('backup.forget.title'), name ? t('backup.forget.detailNamed', { name }) : t('backup.forget.detail'), { label: t('backup.forget.confirm'), danger: false })) return;
    const response = await request({ type: 'BACKUP_FOLDER_FORGET' });
    if (response) update({ backupFolder: response.backupFolder });
  }

  function versionOption(version, checked) {
    const label = element('label', 'restore-version');
    const input = Object.assign(document.createElement('input'), { type: 'radio', name: 'restore-version', value: version.name, checked });
    const copy = element('span', 'mini-copy');
    copy.append(element('strong', '', version.current ? t('backup.restore.current') : t('backup.restore.copyOf', { day: formatDay(version.day) })), element('small', '', t('backup.restore.savedAt', { when: when(version.lastModified) })));
    label.append(input, copy);
    return label;
  }

  function restoreSummary(backup) {
    const diff = compareLibraries(context().library, backup.library);
    const parts = [
      diff.added && count('backup.restore.returns', diff.added),
      diff.changed && count('backup.restore.reverts', diff.changed),
      diff.removed && count('backup.restore.toTrash', diff.removed),
      diff.unchanged && count('backup.import.unchanged', diff.unchanged),
    ].filter(Boolean);
    return t('backup.restore.summary', { videos: count('backup.videos', backup.library.length), changes: parts.join(', ') || t('backup.restore.nothing') });
  }

  async function restore() {
    if (pickInTab) return openInTab();
    const directory = await loadFolderHandle().catch(() => null);
    if (!directory) { toast(t('backup.restore.noFolder'), true); return; }
    if (await folderPermission(directory, { request: true }).catch(() => 'denied') !== 'granted') { toast(t('backup.restore.noPermission'), true); return; }
    let versions;
    try { versions = await listFolderBackups(directory); } catch (error) { toast(t('backup.restore.openFailed', { error: error.message }), true); return; }
    if (!versions.length) { toast(t('backup.restore.empty'), true); return; }

    const list = $('#restore-versions');
    const confirm = $('#restore-confirm');
    const summary = $('#restore-summary');
    let selected = '';
    let chosen = null;
    const preview = async (name) => {
      selected = name;
      chosen = null;
      confirm.disabled = true;
      summary.textContent = t('backup.restore.reading');
      try {
        const text = await readFolderBackup(directory, name);
        const backup = parseBackup(text);
        if (selected !== name) return;
        chosen = text;
        summary.textContent = restoreSummary(backup);
        confirm.disabled = false;
      } catch (error) {
        if (selected === name) summary.textContent = t('backup.restore.invalid', { error: error.message });
      }
    };
    list.replaceChildren(...versions.map((version, index) => versionOption(version, index === 0)));
    list.onchange = (event) => preview(event.target.value);
    preview(versions[0].name);
    if (await ask($('#restore-dialog')) !== 'confirm' || !chosen) return;
    const response = await request({ type: 'RESTORE_BACKUP', backup: chosen });
    if (!response) return;
    update({ library: response.library, trashCount: response.trashCount, pageShortcuts: response.pageShortcuts, overlay: response.overlay });
    toast(response.removed ? count('backup.restore.doneTrash', response.removed) : t('backup.restore.done'), false, undoAction(response.restorePoint, t('backup.restore.undone')));
  }

  // The trash.
  function renderTrash(items, now = Date.now()) {
    $('#trash-list').replaceChildren(...(items.length ? items.map((item) => {
      const button = element('button', 'btn btn-ghost btn-sm', t('backup.trash.restore'));
      button.dataset.trashRestore = item.videoId;
      const left = Math.max(1, Math.ceil((item.expiresAt - now) / DAY_MS));
      return row(item.title, t('backup.trash.detail', { ago: ago(item.deletedAt, now), sections: count('backup.sections', item.fragments), days: count('backup.days', left) }), button);
    }) : [element('p', 'hint', t('backup.trash.empty'))]));
    $('#trash-empty').hidden = !items.length;
  }

  async function showTrash() {
    const response = await request({ type: 'GET_TRASH' }, true);
    if (response) renderTrash(response.trash);
  }

  async function restoreFromTrash(videoId) {
    const response = await request({ type: 'RESTORE_FROM_TRASH', videoId });
    if (!response) return;
    update({ library: response.library, trashCount: response.trashCount });
    toast(t('backup.trash.restored'));
    if (!$('#settings-view').hidden) showTrash();
  }

  async function emptyTrash() {
    const total = context().trashCount || 0;
    if (!await confirmAction(t('backup.trash.emptyTitle'), t('backup.trash.emptyDetail', { count: total }), { label: t('backup.trash.emptyConfirm') })) return;
    const response = await request({ type: 'EMPTY_TRASH' });
    if (!response) return;
    update({ trashCount: 0 });
    renderTrash([]);
  }

  // Status, restore points and trash count follow the worker's state.
  function render() {
    const { backupFolder = { state: 'none' }, restorePoints = [], trashCount = 0 } = context();
    const now = Date.now();
    const key = JSON.stringify([backupFolder, restorePoints, trashCount, Math.floor(now / 30000)]);
    if (key === renderKey) return;
    renderKey = key;
    const view = folderView(backupFolder, now);
    const attention = ['needs-permission', 'unavailable', 'error'].includes(backupFolder.state);
    $('#settings-button').dataset.alert = String(attention);
    const label = attention ? t('backup.settingsAlert', { settings: t('app.header.settings'), state: view.title.toLowerCase() }) : t('app.header.settings');
    $('#settings-button').title = label;
    $('#settings-button').setAttribute('aria-label', label);
    $('#backup-status').dataset.state = backupFolder.state;
    $('#backup-status-title').textContent = view.title;
    $('#backup-status-detail').textContent = view.detail;
    $('#backup-choose').textContent = backupFolder.state === 'none' ? t('backup.folder.choose') : t('backup.folder.change');
    for (const action of ['authorize', 'retry', 'restore', 'forget']) $(`#backup-${action}`).hidden = !view.actions.includes(action);

    $('#restore-points').hidden = !restorePoints.length;
    $('#restore-point-list').replaceChildren(...restorePoints.map((point) => {
      const button = element('button', 'btn btn-ghost btn-sm', t('backup.points.back'));
      button.dataset.restorePoint = point.id;
      return row(t(REASONS[point.reason] || 'backup.reason.generic'), `${when(point.createdAt)} · ${count('backup.videos', point.videos)}`, button);
    }));
  }

  $('#export-backup').addEventListener('click', exportFile);
  $('#import-backup').addEventListener('click', () => (pickInTab ? openInTab() : $('#backup-file').click()));
  $('#backup-file').addEventListener('change', (event) => {
    const [file] = event.target.files;
    event.target.value = '';
    importFile(file);
  });
  $('#backup-choose').addEventListener('click', chooseFolder);
  $('#backup-authorize').addEventListener('click', authorize);
  $('#backup-retry').addEventListener('click', () => runNow(t('backup.folder.saved')));
  $('#backup-restore').addEventListener('click', restore);
  $('#backup-forget').addEventListener('click', forget);
  $('#trash-empty').addEventListener('click', emptyTrash);
  $('#settings-view').addEventListener('click', async (event) => {
    const button = event.target.closest('button');
    if (button?.dataset.trashRestore) await restoreFromTrash(button.dataset.trashRestore);
    if (button?.dataset.restorePoint) {
      const point = (context().restorePoints || []).find((item) => item.id === button.dataset.restorePoint);
      if (!point || !await confirmAction(t('backup.points.title'), t('backup.points.detail', { when: when(point.createdAt) }), { label: t('backup.points.back') })) return;
      await undoRestorePoint(point.id, t('backup.points.done'));
    }
  });

  return {
    importFile,
    render,
    showTrash,
    /** Offered in the toast right after a deletion. */
    undoDelete: (videoId) => ({ label: t('backup.undo'), run: () => restoreFromTrash(videoId) }),
    /** Brings the backup section into view when the popup sent the person here. */
    start() {
      if (location.hash !== '#backup') return;
      $('#backup-section').scrollIntoView({ block: 'start' });
      $('#backup-choose').focus({ preventScroll: true });
    },
  };
}
