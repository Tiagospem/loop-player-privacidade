// PNG image of a fretboard diagram, in the current theme, for lessons, posts and video overlays.
// The neck is drawn off screen, its computed styles are copied onto the SVG (an SVG image cannot read
// the page's CSS) and the result is painted on a canvas with the diagram's name.
import { createFretboard } from './fretboard.js';

const STYLE_PROPERTIES = ['fill', 'stroke', 'stroke-width', 'stroke-dasharray', 'stroke-linecap', 'opacity', 'font-family', 'font-size', 'font-weight'];
const PAD = 28;
const SCALE = 2;

function inlineStyles(source, target) {
  const sources = [source, ...source.querySelectorAll('*')];
  const targets = [target, ...target.querySelectorAll('*')];
  sources.forEach((element, index) => {
    const computed = getComputedStyle(element);
    targets[index].setAttribute('style', STYLE_PROPERTIES.map((name) => `${name}:${computed.getPropertyValue(name)}`).join(';'));
  });
}

/**
 * @param {{model: object, title?: string, subtitle?: string, footer?: string, container?: HTMLElement}} options `model` is a
 *   neck model for ui/fretboard.js; `container` holds the board's styles (it may be inside a shadow root).
 * @returns {Promise<Blob>}
 */
export async function fretboardPng({ model, title = '', subtitle = '', footer = '', container = document.body }) {
  const host = document.createElement('div');
  host.style.setProperty('position', 'fixed');
  host.style.setProperty('left', '-10000px');
  host.style.setProperty('top', '0');
  host.style.setProperty('width', '1400px');
  container.append(host);
  try {
    const board = createFretboard({ label: title });
    host.append(board.element);
    board.render({ ...model, interactive: false, pending: null });
    const { width, height } = board.geometry;
    const clone = board.element.cloneNode(true);
    inlineStyles(board.element, clone);
    clone.setAttribute('xmlns', 'http://www.w3.org/2000/svg');
    clone.setAttribute('width', String(width));
    clone.setAttribute('height', String(height));
    const image = new Image();
    image.src = `data:image/svg+xml;charset=utf-8,${encodeURIComponent(new XMLSerializer().serializeToString(clone))}`;
    await image.decode();

    const page = getComputedStyle(container);
    const color = (name, fallback) => page.getPropertyValue(name).trim() || fallback;
    const font = page.fontFamily || 'system-ui, sans-serif';
    const header = title ? (subtitle ? 64 : 46) : 12;
    const footerHeight = footer ? 30 : 12;
    const canvas = document.createElement('canvas');
    canvas.width = Math.round((width + PAD * 2) * SCALE);
    canvas.height = Math.round((height + header + footerHeight + 12) * SCALE);
    const context = canvas.getContext('2d');
    context.scale(SCALE, SCALE);
    context.fillStyle = color('--lp-surface', '#161a14');
    context.fillRect(0, 0, width + PAD * 2, height + header + footerHeight + 12);
    context.textBaseline = 'alphabetic';
    if (title) {
      context.fillStyle = color('--lp-text', '#f2f5ee');
      context.font = `700 20px ${font}`;
      context.fillText(title, PAD, 36, width);
      if (subtitle) {
        context.fillStyle = color('--lp-text-2', '#b8bfb2');
        context.font = `500 13px ${font}`;
        context.fillText(subtitle, PAD, 56, width);
      }
    }
    context.drawImage(image, PAD, header, width, height);
    if (footer) {
      context.fillStyle = color('--lp-text-3', '#7d8577');
      context.font = `600 11px ${font}`;
      context.textAlign = 'right';
      context.fillText(footer, width + PAD, header + height + 24);
    }
    return await new Promise((resolve, reject) => canvas.toBlob((blob) => (blob ? resolve(blob) : reject(new Error('toBlob'))), 'image/png'));
  } finally {
    host.remove();
  }
}
