// Tuner, Notes and Metronome panel. Rendered in the practice controller and in standalone tool
// windows (closed shadow roots on the page) and in the extension's own tool window.
import { TUNING_IDS, A4_MIN, A4_MAX, tuningStrings } from '../lib/pitch.js';
import { createTapTempo, BPM_MIN, BPM_MAX, BEATS_MIN, BEATS_MAX } from '../lib/metronome.js';
import { TOOL_IDS, TOOL_LABELS, engineNotice } from '../lib/tools.js';
import { t } from '../lib/i18n.js';
import { icon } from './icons.js';
import { setHTML, escapeHTML } from './html.js';

// Catalog keys, resolved when the panel is drawn.
const SENSITIVITY = [[-60, 'tools.input.sensitivityHigh'], [-50, 'tools.input.sensitivityMedium'], [-40, 'tools.input.sensitivityLow']];
const COUNT_IN = [['off', 'tools.metronome.countInOff'], ['start', 'tools.metronome.countInStart'], ['loop', 'tools.metronome.countInLoop']];
const TUNED_CENTS = 3;
// About 4 s of windows at the level floor. Usually the guitar is just quiet, so this is a hint
// next to the level meter, not a warning.
const SILENT_WINDOWS = 70;
const HISTORY_SLOTS = 8;
const clamp = (value, minimum, maximum) => Math.min(Math.max(value, minimum), maximum);
// Translated text placed inside markup.
const tx = (key, params) => escapeHTML(t(key, params));
const signed = (value, digits = 1) => {
  const shown = Math.abs(value).toFixed(digits);
  return Number(shown) === 0 ? shown : `${value < 0 ? '−' : '+'}${shown}`;
};
export const bpmText = (bpm) => {
  const rounded = Math.round(bpm * 10) / 10;
  return Math.abs(rounded - Math.round(rounded)) < 0.05 ? String(Math.round(rounded)) : rounded.toFixed(1);
};

function markup(mode, tab) {
  const step = (name, value, label) => `<button data-tool-step="${name}" data-value="${value}" aria-label="${tx(label)}">${icon(value < 0 ? 'minus' : 'plus', { size: 13 })}</button>`;
  const silence = tx('tools.input.silence');
  return `
  <div class="lpt" data-mode="${mode}" data-tab="${tab}">
    ${mode === 'tabs' ? `<div class="lpt-tabs" role="tablist" aria-label="${tx('tools.panel.label')}">${TOOL_IDS.map((tool) => `<button class="lpt-tab" role="tab" data-tool-tab="${tool}" aria-selected="${tool === tab}">${icon(tool, { size: 14 })}<span>${escapeHTML(TOOL_LABELS[tool])}</span></button>`).join('')}</div>` : ''}
    <div class="lpt-notice notice" data-ref="notice" role="status" hidden>${icon('alert')}<div><span data-ref="noticeText"></span><button class="btn btn-secondary btn-sm" data-tool-action="notice" data-ref="noticeAction"></button></div></div>

    <div class="lpt-pane" data-pane="tuner" role="tabpanel" aria-label="${tx('tools.tuner.title')}">
      <div class="lpt-readout" data-ref="tunerReadout" data-state="idle">
        <div class="lpt-note" aria-live="polite"><b data-ref="tunerNote">—</b><sub data-ref="tunerOctave"></sub></div>
        <div class="lpt-readout-side"><strong data-ref="tunerHint">${tx('tools.tuner.playOpenString')}</strong><span class="mono" data-ref="tunerHz"></span></div>
      </div>
      <div class="lpt-gauge" data-ref="gauge" data-state="idle" aria-hidden="true"><div class="lpt-gauge-zone"></div><div class="lpt-gauge-ticks"></div><div class="lpt-gauge-needle"></div></div>
      <div class="lpt-gauge-labels" aria-hidden="true"><span>−50</span><b class="mono" data-ref="tunerCents">0 ct</b><span>+50</span></div>
      <div class="lpt-strings" data-ref="strings" role="list" aria-label="${tx('tools.tuner.strings')}"></div>
      <div class="lpt-row">
        <select class="lpt-select" data-pref="tuning" aria-label="${tx('tools.tuner.tuning')}">${TUNING_IDS.map((id) => `<option value="${id}">${tx(`tools.tuning.${id}`)}</option>`).join('')}</select>
        <div class="stepper lpt-a4" role="group" aria-label="${tx('tools.tuner.reference')}">${step('a4', -1, 'tools.tuner.referenceDown')}<span class="stepper-value" data-ref="a4" title="${tx('tools.tuner.referenceTitle')}">440 Hz</span>${step('a4', 1, 'tools.tuner.referenceUp')}</div>
      </div>
    </div>

    <div class="lpt-pane" data-pane="notes" role="tabpanel" aria-label="${tx('tools.notes.title')}">
      <div class="lpt-big" data-ref="notesBig" data-live="false" aria-live="polite"><b data-ref="notesNote">—</b><sub data-ref="notesOctave"></sub><span class="mono" data-ref="notesCents"></span></div>
      <div class="lpt-history-head"><span class="lpt-label">${tx('tools.notes.recent')}</span><button class="text-btn" data-tool-action="clear-notes">${tx('tools.notes.clear')}</button></div>
      <ol class="lpt-history" data-ref="history" aria-label="${tx('tools.notes.recentPlayed')}"></ol>
      <p class="lpt-history-hint" data-ref="historyHint">${tx('tools.notes.hint')}</p>
    </div>

    <div class="lpt-pane" data-pane="metronome" role="tabpanel" aria-label="${tx('tools.metronome.title')}">
      <div class="lpt-beats" data-ref="beats" aria-hidden="true"></div>
      <div class="lpt-tempo">
        <button class="play-btn lpt-start" data-tool-action="metronome" data-ref="start" aria-label="${tx('tools.metronome.start')}" title="${tx('tools.metronome.startStop')}">${icon('play', { size: 20 })}</button>
        <div class="stepper lpt-bpm" role="group" aria-label="${tx('tools.metronome.tempo')}">${step('bpm', -1, 'tools.metronome.bpmDown')}<label><input class="mono" data-ref="bpm" inputmode="decimal" autocomplete="off" spellcheck="false" aria-label="${tx('tools.metronome.bpm')}"><small>BPM</small></label>${step('bpm', 1, 'tools.metronome.bpmUp')}</div>
        <button class="btn btn-secondary btn-sm lpt-tap" data-tool-action="tap" title="${tx('tools.metronome.tapTitle')}">${tx('tools.metronome.tap')}</button>
      </div>
      <p class="lpt-source" data-ref="source" hidden></p>
      <div class="lpt-row">
        <div class="lpt-field"><span class="lpt-label">${tx('tools.metronome.timeSignature')}</span><div class="stepper" role="group" aria-label="${tx('tools.metronome.beatsPerBar')}">${step('beats', -1, 'tools.metronome.beatsDown')}<span class="stepper-value mono" data-ref="beatsValue">4</span>${step('beats', 1, 'tools.metronome.beatsUp')}</div></div>
        <label class="lpt-switch"><span class="lpt-label">${tx('tools.metronome.accent')}</span><input class="switch" type="checkbox" role="switch" data-pref="accent"></label>
      </div>
      <label class="lpt-volume"><span class="lpt-label">${tx('tools.metronome.volume')}</span><input type="range" min="0" max="1" step="0.05" data-pref="volume" aria-label="${tx('tools.metronome.volumeLabel')}"></label>
      <div class="lpt-video" data-ref="video" hidden>
        <label class="lpt-switch"><span><strong>${tx('tools.metronome.follow')}</strong><small data-ref="followHint">${tx('tools.metronome.followHint')}</small></span><input class="switch" type="checkbox" role="switch" data-pref="follow"></label>
        <div class="lpt-field"><span class="lpt-label">${tx('tools.metronome.countIn')}</span><div class="lpt-seg" role="radiogroup" aria-label="${tx('tools.metronome.countIn')}">${COUNT_IN.map(([value, label]) => `<button role="radio" data-count-in="${value}" aria-checked="false">${tx(label)}</button>`).join('')}</div></div>
      </div>
    </div>

    <div class="lpt-input" data-ref="inputBar">
      <span class="lpt-meter" aria-hidden="true"><i data-ref="meter"></i></span>
      <span class="lpt-silence" data-ref="silence" tabindex="0" role="img" aria-label="${silence}" data-hint="${silence}" hidden>${icon('micOff', { size: 14 })}</span>
      <span class="lpt-input-label" data-ref="inputLabel">${tx('tools.input.default')}</span>
      <button class="icon-btn icon-btn-sm" data-tool-action="settings" data-ref="settingsButton" aria-expanded="false" aria-label="${tx('tools.input.settings')}" title="${tx('tools.input.settingsTitle')}">${icon('settings', { size: 14 })}</button>
    </div>
    <p class="lpt-tip" data-ref="tip">${tx('tools.input.tip')}</p>
    <div class="lpt-settings" data-ref="settings" hidden>
      <label class="lpt-field"><span class="lpt-label">${tx('tools.input.label')}</span><select class="lpt-select" data-pref="device" data-ref="device" aria-label="${tx('tools.input.audioInput')}"></select></label>
      <div class="lpt-row">
        <label class="lpt-field"><span class="lpt-label">${tx('tools.input.channel')}</span><select class="lpt-select" data-pref="channel" aria-label="${tx('tools.input.interfaceChannel')}"><option value="1">${tx('tools.input.channel1')}</option><option value="2">${tx('tools.input.channel2')}</option></select></label>
        <label class="lpt-field"><span class="lpt-label">${tx('tools.input.sensitivity')}</span><select class="lpt-select" data-pref="gate" aria-label="${tx('tools.input.sensitivity')}">${SENSITIVITY.map(([value, label]) => `<option value="${value}">${tx(label)}</option>`).join('')}</select></label>
      </div>
      <p class="lpt-tip">${tx('tools.input.interfaceTip')}</p>
    </div>
  </div>`;
}

/**
 * @param {{client: object, mode?: 'tabs'|'single', tool?: string, documentRef?: Document,
 *   onTabChange?: (tool: string) => void, onSummary?: (summary: object) => void, onError?: (message: string) => void}} options
 */
export function createToolsPanel({ client, mode = 'tabs', tool = 'tuner', documentRef = document, onTabChange = () => {}, onSummary = () => {}, onError = () => {} }) {
  let tab = TOOL_IDS.includes(tool) ? tool : 'tuner';
  const element = documentRef.createElement('div');
  element.className = 'lpt-host';
  setHTML(element, markup(mode, tab));
  const root = element.firstElementChild;
  const refs = Object.fromEntries([...element.querySelectorAll('[data-ref]')].map((node) => [node.dataset.ref, node]));
  const prefInputs = Object.fromEntries([...element.querySelectorAll('[data-pref]')].map((node) => [node.dataset.pref, node]));

  let active = false;
  let reading = null;
  let draft = {};
  let draftTimer = null;
  let volumeTimer = null;
  let stringsKey = '';
  let devicesKey = '';
  let historyKey = null;
  let beatsKey = '';
  let flashTimer = null;
  let silentWindows = 0;
  const beatTimers = new Set();
  const tapper = createTapTempo();
  let tapTimer = null;

  const state = () => client.state;
  const capturing = () => state()?.engine?.status === 'capturing';
  const videoMode = () => Boolean(state()?.prefs?.metronome.follow && state()?.session?.ready);

  async function run(message) {
    let response;
    try { response = await client.send(message); } catch (error) { response = { ok: false, error: error.message }; }
    if (response?.ok === false && response.error) onError(response.error);
    return response;
  }

  const setPrefs = (patch) => run({ type: 'TOOLS_PREFS', patch });

  function summary() {
    if (tab === 'metronome') {
      const metronome = state()?.metronome;
      return { tool: tab, text: metronome ? `${bpmText(draft.bpm ?? metronome.bpm)} BPM` : '— BPM', running: Boolean(metronome?.running) };
    }
    if (tab === 'notes') {
      const note = reading?.notes?.current || reading?.notes?.history?.at(-1);
      return { tool: tab, text: note ? `${note.note}${note.octave}` : '—', live: Boolean(reading?.notes?.current) };
    }
    const tuner = reading?.tuner;
    return { tool: tab, text: tuner?.detected ? `${tuner.note}${tuner.octave} ${signed(tuner.cents, 0)}` : '—', tuned: Boolean(tuner?.detected && Math.abs(tuner.cents) <= TUNED_CENTS) };
  }

  function renderNotice() {
    const engine = state()?.engine;
    const notice = tab !== 'metronome' && active ? engineNotice(engine) : null;
    refs.notice.hidden = !notice;
    if (!notice) return;
    refs.notice.dataset.tone = notice.tone;
    refs.noticeText.textContent = notice.text;
    refs.noticeAction.hidden = !notice.action;
    refs.noticeAction.textContent = notice.label;
    refs.noticeAction.dataset.notice = notice.action || '';
  }

  function renderInput() {
    const current = state();
    if (!current) return;
    const { engine, prefs } = current;
    const label = engine.status === 'capturing' ? t('tools.input.status', { input: engine.input.label || t('tools.input.default'), channel: engine.input.channel })
      : engine.status === 'starting' ? t('tools.input.opening')
        : engine.status === 'error' ? t('tools.input.unavailable')
          : t('tools.input.status', { input: prefs.input.label || t('tools.input.default'), channel: prefs.input.channel });
    refs.inputLabel.textContent = label;
    refs.inputLabel.title = label;
    refs.inputBar.dataset.status = engine.status;
    const devices = engine.devices || [];
    const key = JSON.stringify([devices, prefs.input.deviceId, prefs.input.label]);
    if (key !== devicesKey) {
      devicesKey = key;
      // [value, name kept in the preferences, text shown]. The engine sends no label before the
      // microphone permission; the fallback name is numbered here, in the interface language.
      const options = [['', '', t('tools.input.systemDefault')], ...devices.map((device, index) => {
        const name = device.label || t('tools.input.numbered', { number: index + 1 });
        return [device.deviceId, name, name];
      })];
      if (prefs.input.deviceId && !devices.some((device) => device.deviceId === prefs.input.deviceId)) {
        const name = prefs.input.label || t('tools.input.chosen');
        options.push([prefs.input.deviceId, name, t('tools.input.disconnected', { input: name })]);
      }
      setHTML(refs.device, options.map(([value, name, text]) => `<option value="${escapeHTML(value)}" data-label="${escapeHTML(name)}">${escapeHTML(text)}</option>`).join(''));
    }
    if (documentRef.activeElement !== refs.device) refs.device.value = prefs.input.deviceId;
    prefInputs.channel.value = String(prefs.input.channel);
    prefInputs.gate.value = String(SENSITIVITY.reduce((best, [value]) => (Math.abs(value - prefs.tuner.gateDB) < Math.abs(best - prefs.tuner.gateDB) ? value : best), -50));
  }

  function renderTunerSettings() {
    const prefs = state()?.prefs;
    if (!prefs) return;
    const a4 = draft.a4 ?? prefs.tuner.a4;
    prefInputs.tuning.value = prefs.tuner.tuning;
    refs.a4.textContent = `${a4} Hz`;
    element.querySelector('[data-tool-step="a4"][data-value="-1"]').disabled = a4 <= A4_MIN;
    element.querySelector('[data-tool-step="a4"][data-value="1"]').disabled = a4 >= A4_MAX;
    const key = `${prefs.tuner.tuning}:${a4}`;
    if (key === stringsKey) return;
    stringsKey = key;
    setHTML(refs.strings, tuningStrings(prefs.tuner.tuning, a4).map((string) => `<span class="lpt-string" role="listitem" data-string="${string.number}" title="${tx('tools.tuner.stringNumber', { number: string.number })} · ${string.note}${string.octave} · ${string.frequency.toFixed(2)} Hz"><b>${string.note}</b><small>${string.number}</small></span>`).join(''));
  }

  function renderMetronome() {
    const current = state();
    if (!current) return;
    const { metronome, prefs, tempo, session } = current;
    const bpm = draft.bpm ?? metronome.bpm;
    const beats = draft.beats ?? metronome.beats;
    if (documentRef.activeElement !== refs.bpm) refs.bpm.value = bpmText(bpm);
    refs.beatsValue.textContent = String(beats);
    element.querySelector('[data-tool-step="beats"][data-value="-1"]').disabled = beats <= BEATS_MIN;
    element.querySelector('[data-tool-step="beats"][data-value="1"]').disabled = beats >= BEATS_MAX;
    const running = metronome.running;
    const iconName = running ? 'stop' : 'play';
    if (refs.start.dataset.icon !== iconName) { setHTML(refs.start, icon(iconName, { size: 20 })); refs.start.dataset.icon = iconName; }
    refs.start.setAttribute('aria-label', t(running ? 'tools.metronome.stop' : 'tools.metronome.start'));
    refs.start.setAttribute('aria-pressed', String(running));
    prefInputs.accent.checked = prefs.metronome.accent;
    if (documentRef.activeElement !== prefInputs.volume) prefInputs.volume.value = String(prefs.metronome.volume);
    prefInputs.follow.checked = prefs.metronome.follow;

    let source = '';
    if (metronome.source === 'video') source = t('tools.metronome.videoTempo', { bpm: bpmText(tempo.bpm), speed: Math.round(tempo.speed * 100) });
    else if (videoMode()) source = t('tools.metronome.tapPrompt');
    if (session?.ready && tempo?.countIn !== 'off' && !tempo?.bpm) source = `${source} ${t('tools.metronome.countInVideoTempo')}`.trim();
    refs.source.hidden = !source;
    refs.source.textContent = source;
    refs.video.hidden = !session?.ready;
    refs.followHint.textContent = tempo ? t('tools.metronome.followHintSpeed', { speed: Math.round(tempo.speed * 100) }) : t('tools.metronome.followHint');
    for (const button of element.querySelectorAll('[data-count-in]')) button.setAttribute('aria-checked', String((tempo?.countIn || 'off') === button.dataset.countIn));

    const nextBeatsKey = `${beats}:${prefs.metronome.accent}`;
    if (nextBeatsKey !== beatsKey) {
      beatsKey = nextBeatsKey;
      setHTML(refs.beats, Array.from({ length: beats }, (_, index) => `<i${index === 0 && prefs.metronome.accent && beats > 1 ? ' data-accent' : ''}></i>`).join(''));
    }
    root.dataset.running = String(running);
  }

  function renderState() {
    if (!state()) return;
    renderNotice();
    renderInput();
    renderTunerSettings();
    renderMetronome();
    if (!capturing()) renderReading(null);
    onSummary(summary());
  }

  function renderReading(next) {
    reading = next;
    const silent = Boolean(next && next.level <= -59.9);
    const wasSilent = silentWindows >= SILENT_WINDOWS;
    silentWindows = silent ? silentWindows + 1 : 0;
    if (wasSilent !== silentWindows >= SILENT_WINDOWS) refs.silence.hidden = !(silentWindows >= SILENT_WINDOWS);
    const level = next ? clamp((next.level + 60) / 60, 0, 1) : 0;
    refs.meter.style.setProperty('width', `${(level * 100).toFixed(1)}%`);

    const tuner = next?.tuner;
    const engine = state()?.engine;
    if (tuner?.detected) {
      const cents = tuner.cents;
      const tuned = Math.abs(cents) <= TUNED_CENTS;
      const tone = tuned ? 'tuned' : cents < 0 ? 'flat' : 'sharp';
      refs.tunerNote.textContent = tuner.note;
      refs.tunerOctave.textContent = String(tuner.octave);
      refs.tunerHint.textContent = t(tuned ? 'tools.tuner.inTune' : cents < 0 ? 'tools.tuner.tighten' : 'tools.tuner.loosen');
      refs.tunerHz.textContent = `${tuner.frequency.toFixed(2)} Hz${tuner.stringNumber ? ` · ${t('tools.tuner.stringNumber', { number: tuner.stringNumber })}` : ''}`;
      refs.tunerCents.textContent = `${signed(cents)} ct`;
      refs.gauge.style.setProperty('--c', clamp(cents, -50, 50).toFixed(2));
      refs.gauge.dataset.state = tone;
      refs.tunerReadout.dataset.state = tone;
    } else {
      refs.tunerNote.textContent = '—';
      refs.tunerOctave.textContent = '';
      refs.tunerHint.textContent = t(engine?.status === 'starting' ? 'tools.input.opening' : engine?.status === 'error' ? 'tools.tuner.noInput' : 'tools.tuner.playOpenString');
      refs.tunerHz.textContent = '';
      refs.tunerCents.textContent = '0 ct';
      refs.gauge.style.setProperty('--c', '0');
      refs.gauge.dataset.state = 'idle';
      refs.tunerReadout.dataset.state = 'idle';
    }
    for (const string of refs.strings.children) {
      const match = Boolean(tuner?.detected && Number(string.dataset.string) === tuner.stringNumber);
      string.toggleAttribute('data-active', match);
      string.toggleAttribute('data-tuned', match && Math.abs(tuner.cents) <= TUNED_CENTS);
    }

    const current = next?.notes?.current;
    const history = next?.notes?.history || [];
    const shown = current || history.at(-1);
    refs.notesBig.dataset.live = String(Boolean(current));
    refs.notesNote.textContent = shown ? shown.note : '—';
    refs.notesOctave.textContent = shown ? String(shown.octave) : '';
    refs.notesCents.textContent = current ? `${signed(current.cents, 0)} ct` : '';
    const key = history.map((note) => note.id).join(',');
    if (key !== historyKey) {
      historyKey = key;
      // A fixed 4 × 2 grid: empty slots keep the layout even while it fills up.
      setHTML(refs.history, Array.from({ length: HISTORY_SLOTS }, (_, index) => {
        const note = history[index];
        if (!note) return '<li class="lpt-history-slot" aria-hidden="true"></li>';
        return `<li${index === history.length - 1 ? ' data-latest' : ''}><b>${note.note}</b><sub>${note.octave}</sub></li>`;
      }).join(''));
      refs.historyHint.hidden = history.length > 0;
    }
    if (next) onSummary(summary());
  }

  function renderBeat(beat) {
    // Flash when the click is heard, not when the message arrives.
    const delay = clamp(beat.at - Date.now(), 0, 1000);
    const timer = setTimeout(() => {
      beatTimers.delete(timer);
      const dot = refs.beats.children[beat.beat - 1];
      for (const other of refs.beats.children) other.removeAttribute('data-on');
      dot?.setAttribute('data-on', '');
      refs.beats.dataset.countIn = String(beat.countIn);
      clearTimeout(flashTimer);
      flashTimer = setTimeout(() => dot?.removeAttribute('data-on'), 140);
    }, delay);
    beatTimers.add(timer);
  }

  function setTab(next) {
    if (!TOOL_IDS.includes(next) || next === tab) return;
    tab = next;
    root.dataset.tab = tab;
    for (const button of element.querySelectorAll('[data-tool-tab]')) button.setAttribute('aria-selected', String(button.dataset.toolTab === tab));
    renderNotice();
    client.refresh();
    onTabChange(tab);
    onSummary(summary());
  }

  // Steppers update at once and send one change after the clicks settle.
  function stepDraft(kind, value) {
    draft[kind] = value;
    renderTunerSettings();
    renderMetronome();
    onSummary(summary());
    clearTimeout(draftTimer);
    draftTimer = setTimeout(flushDraft, 350);
  }

  async function flushDraft() {
    const sent = { ...draft };
    const current = state();
    if (!current) return;
    if (sent.a4 !== undefined) await setPrefs({ tuner: { a4: sent.a4 } });
    if (sent.bpm !== undefined) await setTempo(sent.bpm);
    if (sent.beats !== undefined) {
      if (current.metronome.source === 'video') await run({ type: 'TOOLS_TEMPO', beats: sent.beats });
      else await setPrefs({ metronome: { beats: sent.beats } });
    }
    for (const [kind, value] of Object.entries(sent)) if (draft[kind] === value) delete draft[kind];
    renderState();
  }

  // The number shown is the tempo heard; following the video, it is stored at 100% speed.
  function setTempo(bpm) {
    const current = state();
    if (videoMode()) return run({ type: 'TOOLS_TEMPO', effective: bpm, ...(current.tempo?.bpm ? {} : { beats: current.metronome.beats }) });
    return setPrefs({ metronome: { bpm: clamp(bpm, BPM_MIN, BPM_MAX) } });
  }

  function tap() {
    const bpm = tapper.tap(performance.now());
    if (bpm === null) return;
    draft.bpm = bpm;
    renderMetronome();
    clearTimeout(tapTimer);
    tapTimer = setTimeout(flushDraft, 600);
  }

  function commitBpm() {
    const value = Number(String(refs.bpm.value).replace(',', '.'));
    if (!Number.isFinite(value) || value <= 0) { renderMetronome(); return; }
    stepDraft('bpm', clamp(Math.round(value * 10) / 10, BPM_MIN, BPM_MAX));
  }

  element.addEventListener('click', (event) => {
    const button = event.target.closest('button');
    if (!button || button.disabled || !element.contains(button)) return;
    const data = button.dataset;
    if (data.toolTab) setTab(data.toolTab);
    if (data.countIn) run({ type: 'TOOLS_TEMPO', countIn: data.countIn });
    if (data.toolStep) {
      const current = state();
      if (!current) return;
      const delta = Number(data.value);
      if (data.toolStep === 'a4') stepDraft('a4', clamp((draft.a4 ?? current.prefs.tuner.a4) + delta, A4_MIN, A4_MAX));
      if (data.toolStep === 'bpm') stepDraft('bpm', clamp(Math.round(draft.bpm ?? current.metronome.bpm) + delta, BPM_MIN, BPM_MAX));
      if (data.toolStep === 'beats') stepDraft('beats', clamp((draft.beats ?? current.metronome.beats) + delta, BEATS_MIN, BEATS_MAX));
    }
    switch (data.toolAction) {
      case 'notice':
        if (data.notice === 'setup') run({ type: 'TOOLS_OPEN_SETUP' });
        if (data.notice === 'retry') run({ type: 'TOOLS_RETRY' });
        break;
      case 'clear-notes': run({ type: 'TOOLS_CLEAR_NOTES' }); renderReading({ ...(reading || { level: -60 }), notes: { current: null, history: [] } }); break;
      case 'metronome': run({ type: 'TOOLS_METRONOME', running: !state()?.metronome.running }); break;
      case 'tap': tap(); break;
      case 'settings': {
        refs.settings.hidden = !refs.settings.hidden;
        refs.settingsButton.setAttribute('aria-expanded', String(!refs.settings.hidden));
        break;
      }
      default: break;
    }
  });

  element.addEventListener('change', (event) => {
    const input = event.target;
    switch (input.dataset?.pref) {
      case 'tuning': setPrefs({ tuner: { tuning: input.value } }); break;
      case 'gate': setPrefs({ tuner: { gateDB: Number(input.value) } }); break;
      case 'channel': setPrefs({ input: { channel: Number(input.value) } }); break;
      case 'device': setPrefs({ input: { deviceId: input.value, label: input.value ? input.selectedOptions[0]?.dataset.label || '' : '' } }); break;
      case 'accent': setPrefs({ metronome: { accent: input.checked } }); break;
      case 'follow': setPrefs({ metronome: { follow: input.checked } }); break;
      default: break;
    }
    if (input === refs.bpm) commitBpm();
  });

  prefInputs.volume.addEventListener('input', () => {
    clearTimeout(volumeTimer);
    volumeTimer = setTimeout(() => setPrefs({ metronome: { volume: Number(prefInputs.volume.value) } }), 150);
  });

  // Keys typed in the tools never reach the page, the player or the practice shortcuts.
  element.addEventListener('keydown', (event) => {
    event.stopPropagation();
    if (event.target === refs.bpm) {
      if (event.key === 'Enter') refs.bpm.blur();
      if (event.key === 'Escape') { draft = {}; renderMetronome(); refs.bpm.blur(); }
      return;
    }
    if (tab === 'metronome' && event.key.toLowerCase() === 't' && !event.repeat && !event.altKey && !event.ctrlKey && !event.metaKey && !/^(INPUT|SELECT|TEXTAREA)$/.test(event.target.tagName)) {
      event.preventDefault();
      tap();
    }
  });
  for (const type of ['keyup', 'keypress']) element.addEventListener(type, (event) => event.stopPropagation());

  // A hidden tab stops listening; detached in Picture-in-Picture, the panel stays visible.
  const visible = () => element.ownerDocument?.visibilityState !== 'hidden';
  const onVisibility = () => client.refresh();
  documentRef.addEventListener('visibilitychange', onVisibility);
  const panel = {
    views: () => (active && visible() ? [tab] : []),
    receive(message) {
      if (message?.type === 'state') renderState();
      else if (message?.type === 'reading') renderReading(message);
      else if (message?.type === 'beat') renderBeat(message);
    },
  };
  renderReading(null);
  client.attach(panel);

  return {
    element,
    get tab() { return tab; },
    summary,
    setTab,
    setActive(next) {
      if (active !== Boolean(next)) {
        active = Boolean(next);
        if (!active) renderReading(null);
        renderNotice();
      }
      // Also called when the panel moves between the page and Picture-in-Picture.
      client.refresh();
    },
    tap,
    destroy() {
      clearTimeout(draftTimer);
      clearTimeout(volumeTimer);
      clearTimeout(tapTimer);
      clearTimeout(flashTimer);
      for (const timer of beatTimers) clearTimeout(timer);
      documentRef.removeEventListener('visibilitychange', onVisibility);
      client.detach(panel);
      element.remove();
    },
  };
}
