// Sharing loops in the panel: copy a code from Prática; in the Biblioteca, import a pasted code or a
// `.loop` file (picker or drag and drop) and export a `.loop` file. Codes pasted in "Já tem o link?"
// arrive here too. Shared content is untrusted: it is shown only through textContent and reaches the
// library only after the person confirms what will change.
import { formatLoopTime, MAX_LIBRARY_ENTRIES, MAX_LOOP_FRAGMENTS } from '../lib/core.js';
import { t, videoTitle } from '../lib/i18n.js';
import { MAX_FILE_BYTES, containsDiagramCode, containsShareCode, createLoopFile, decodeShareCode, encodeShareCode, loopFileName, mergeSharedConfiguration, parseLoopFile } from '../lib/share.js';
import { ask } from './dialogs.js';

const $ = (selector) => document.querySelector(selector);
const thumbUrl = (videoId) => `https://i.ytimg.com/vi/${videoId}/mqdefault.jpg`;
const formatGap = (seconds) => `${Number.isInteger(seconds) ? seconds : seconds.toFixed(1)} s`;

function element(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

function thumbnail(videoId) {
  const image = element('img', 'thumb');
  Object.assign(image, { src: thumbUrl(videoId), alt: '', loading: 'lazy', referrerPolicy: 'no-referrer' });
  return image;
}

async function writeClipboard(text) {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    // Older permission states still allow a copy from the selected text of a click.
    const field = Object.assign(document.createElement('textarea'), { value: text, readOnly: true });
    field.style.cssText = 'position:fixed;opacity:0;pointer-events:none';
    document.body.append(field);
    field.select();
    try { return document.execCommand('copy'); } catch { return false; } finally { field.remove(); }
  }
}

// A data URL keeps the download alive even if a save dialog closes the toolbar popup.
function fileUrl(text) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(new Blob([text], { type: 'application/json' }));
  });
}

/**
 * @param {object} app
 * @param {() => {library: object[], session: object | null}} app.context
 * @param {(message: object) => Promise<object | null>} app.request Sends to the worker and shows its errors.
 * @param {(message: string, error?: boolean, action?: {label: string, run: () => void}) => void} app.toast
 * @param {(library: object[], session?: object | null) => void} app.update Applies an import result.
 * @param {(view: string) => void} app.setView
 * @param {(file: File) => Promise<void>} [app.importBackup] Receives a library backup picked or dropped here.
 */
export function setupSharing({ context, request, toast, update, setView, isExtension, isWorkspace, appVersion, importBackup }) {
  const shareMenu = $('#share-menu');
  const shareButton = $('#share-loop');
  const shareOutput = $('#share-output');
  const importPanel = $('#import-panel');
  const importButton = $('#import-loop');
  const fileInput = $('#loop-file');

  // Chrome closes the toolbar popup when a file chooser opens, so files are picked in the library tab.
  const pickInTab = isExtension && !isWorkspace;
  if (pickInTab) {
    $('#import-file').title = t('share.panel.pickInTabTitle');
    $('#import-file-hint').textContent = t('share.panel.pickInTabHint');
  }

  function setShareMenu(open) {
    shareMenu.hidden = !open;
    shareButton.setAttribute('aria-expanded', String(open));
    if (!open) shareOutput.hidden = true;
  }

  async function copyCode(scope) {
    const session = context().session;
    if (!session) return;
    let code;
    try { code = encodeShareCode(session, { scope }); } catch (error) { toast(error.message, true); return; }
    if (await writeClipboard(code)) {
      setShareMenu(false);
      toast(t('share.copy.done'));
      return;
    }
    // Without clipboard access, the code stays selected for ⌘C or Ctrl+C.
    setShareMenu(true);
    shareOutput.value = code;
    shareOutput.hidden = false;
    shareOutput.focus();
    shareOutput.select();
    toast(t('share.copy.manual'));
  }

  shareButton.addEventListener('click', () => {
    const configuration = context().session?.configuration;
    if (!configuration) return;
    if (configuration.fragments.length <= 1) { copyCode('all'); return; }
    shareMenu.querySelector('[data-share-scope="active"]').textContent = t('share.menu.active', { number: configuration.activeFragmentIndex + 1 });
    $('#share-all').textContent = t('share.menu.all', { count: configuration.fragments.length });
    setShareMenu(shareMenu.hidden);
  });
  shareMenu.addEventListener('click', (event) => {
    const button = event.target.closest('[data-share-scope]');
    if (button) copyCode(button.dataset.shareScope);
  });

  // Saved videos copy their code in one click, without practicing or leaving the list.
  document.addEventListener('click', async (event) => {
    const button = event.target.closest('button[data-copy-code]');
    const entry = button && context().library.find((item) => item.videoId === button.dataset.copyCode);
    if (!entry) return;
    const code = encodeShareCode(entry);
    if (await writeClipboard(code)) toast(t('share.copy.done'));
    else window.prompt(t('share.copy.prompt'), code);
  });

  function videoItem(video, title, plan) {
    const { configuration } = video;
    const item = element('li', 'share-item');
    const copy = element('div', 'share-item-copy');
    const meta = [
      plan.saved ? t('share.import.inLibrary', { count: plan.saved.fragments.length }) : t('share.import.newInLibrary'),
      t('share.import.receives', { count: configuration.fragments.length }),
      `${Math.round(configuration.speed * 100)}%`,
      configuration.gapSeconds ? t('share.import.gap', { gap: formatGap(configuration.gapSeconds) }) : '',
    ].filter(Boolean);
    copy.append(
      element('strong', 'share-item-title', title),
      element('span', 'share-item-meta', meta.join(' · ')),
    );
    const fragments = element('ol', 'share-fragments');
    for (const fragment of configuration.fragments) {
      const row = element('li', '', `${formatLoopTime(fragment.start)} → ${formatLoopTime(fragment.end)}`);
      if (fragment.view) row.append(` · ${t('share.import.zoom', { zoom: fragment.view.zoom })}`);
      if (fragment.name) row.append(' ', element('span', 'share-fragment-name', fragment.name));
      fragments.append(row);
    }
    copy.append(fragments);
    item.append(thumbnail(video.videoId), copy);
    return item;
  }

  /** Shows what will change and imports only after the person chooses add or replace. */
  async function confirmImport(videos, { ignored = 0 } = {}) {
    const { library, session } = context();
    const savedConfiguration = (videoId) => library.find((entry) => entry.videoId === videoId)?.configuration
      ?? (session?.videoId === videoId ? session.configuration : null);
    const plans = videos.map((video) => {
      const saved = savedConfiguration(video.videoId);
      return { video, saved, add: mergeSharedConfiguration(saved, video.configuration, 'add') };
    });
    const known = plans.filter((plan) => plan.saved);
    const fresh = plans.length - known.length;
    const room = Math.max(0, MAX_LIBRARY_ENTRIES - library.length);

    $('#import-title').textContent = videos.length === 1 ? t('share.import.titleOne') : t('share.import.titleMany', { count: videos.length });
    const counts = fresh && known.length ? t('share.import.summaryMixed', { count: fresh, known: known.length })
      : fresh ? t('share.import.summaryFresh', { count: fresh }) : t('share.import.summaryKnown', { count: known.length });
    $('#import-summary').textContent = videos.length === 1
      ? known.length ? t('share.import.knownOne', { max: MAX_LOOP_FRAGMENTS }) : t('share.import.freshOne')
      : [counts, fresh && t('share.import.freshSource')].filter(Boolean).join(' ');
    $('#import-list').replaceChildren(...plans.map((plan) => {
      const entry = library.find((item) => item.videoId === plan.video.videoId);
      return videoItem(plan.video, videoTitle(entry?.title || plan.video.title, plan.video.videoId), plan);
    }));

    const ignoredFragments = videos.reduce((total, video) => total + (video.ignoredFragments || 0), 0);
    const skipped = known.reduce((total, plan) => total + plan.add.skipped, 0);
    const nothingToAdd = fresh === 0 && known.every((plan) => plan.add.added === 0);
    const notes = [
      ignored && t('share.import.ignoredItems', { count: ignored }),
      ignoredFragments && t('share.import.ignoredSections', { count: ignoredFragments, max: MAX_LOOP_FRAGMENTS }),
      skipped && !nothingToAdd && t('share.import.skippedSections', { count: skipped, max: MAX_LOOP_FRAGMENTS }),
      nothingToAdd && t('share.import.nothingToAdd', { max: MAX_LOOP_FRAGMENTS }),
      fresh > room && t('share.import.libraryFull', { count: fresh - room, max: MAX_LIBRARY_ENTRIES }),
    ].filter(Boolean);
    $('#import-note').textContent = notes.join(' ');
    $('#import-note').hidden = !notes.length;

    const add = $('#import-add');
    add.textContent = known.length ? t('share.import.add') : t('share.import.save');
    add.disabled = nothingToAdd || (!known.length && !room);
    $('#import-replace').hidden = !known.length;

    const mode = await ask($('#import-dialog'));
    if (mode !== 'add' && mode !== 'replace') return false;
    const response = await request({ type: 'IMPORT_LOOPS', mode, videos: videos.map(({ videoId, title, configuration }) => ({ videoId, title, configuration })) });
    if (!response) return false;
    update(response.library, response.session);
    const { added, updated, skipped: full } = response.summary;
    const left = full ? t('share.toast.libraryFull', { count: full }) : '';
    const imported = () => t('share.toast.imported', {
      added: t('share.toast.newVideos', { count: added }),
      updated: t('share.toast.updatedVideos', { count: updated }),
    });
    const message = videos.length > 1 ? [imported(), left]
      : added ? [t('share.toast.saved')] : updated ? [mode === 'replace' ? t('share.toast.replaced') : t('share.toast.added')] : [t('share.toast.nothing'), left];
    // The worker saved a restore point before importing.
    const undo = (added || updated) && response.restorePoint ? { label: t('share.toast.undoImport'), run: () => undoImport(response.restorePoint.id) } : null;
    toast(message.filter(Boolean).join(' '), !added && !updated, undo);
    setView(session && videos.some((video) => video.videoId === session.videoId) ? 'practice' : 'library');
    return true;
  }

  async function undoImport(id) {
    const response = await request({ type: 'UNDO_RESTORE_POINT', id });
    if (!response) return;
    update(response.library);
    toast(t('backup.import.undone'));
  }

  /** Imports a code found in pasted text. Returns whether something was imported. */
  async function importText(text) {
    let shared;
    try { shared = decodeShareCode(text); } catch (error) { toast(error.message, true); return false; }
    return confirmImport([{ videoId: shared.videoId, configuration: shared.configuration, ignoredFragments: shared.ignoredFragments }]);
  }

  // One importer for every Loop Player file. A library backup shares the envelope (kind "backup").
  async function importFile(file) {
    if (!file) return;
    let parsed;
    try {
      if (file.size > MAX_FILE_BYTES) throw new Error(t('share.file.tooLarge'));
      parsed = parseLoopFile(await file.text());
    } catch (error) {
      if (error.kind === 'backup' && importBackup) await importBackup(file);
      else toast(error.message, true);
      return;
    }
    await confirmImport(parsed.videos, { ignored: parsed.ignored });
  }

  function setImportPanel(open) {
    importPanel.hidden = !open;
    importButton.setAttribute('aria-expanded', String(open));
  }

  importButton.addEventListener('click', () => {
    setImportPanel(importPanel.hidden);
    if (!importPanel.hidden) $('#import-code').focus();
  });
  importPanel.addEventListener('submit', async (event) => {
    event.preventDefault();
    if (await importText($('#import-code').value)) { $('#import-code').value = ''; setImportPanel(false); }
  });
  $('#import-file').addEventListener('click', () => {
    if (!pickInTab) { fileInput.click(); return; }
    chrome.tabs.create({ url: chrome.runtime.getURL('app.html?view=library&import=file') });
    window.close();
  });
  fileInput.addEventListener('change', () => {
    const [file] = fileInput.files;
    fileInput.value = '';
    importFile(file);
  });

  // Dropping a file anywhere in the panel imports it instead of opening it in the tab.
  const carriesFiles = (event) => [...(event.dataTransfer?.types || [])].includes('Files');
  document.addEventListener('dragover', (event) => {
    if (!carriesFiles(event)) return;
    event.preventDefault();
    event.dataTransfer.dropEffect = 'copy';
    document.body.dataset.dropping = 'true';
  });
  document.addEventListener('dragleave', (event) => { if (!event.relatedTarget) delete document.body.dataset.dropping; });
  document.addEventListener('drop', (event) => {
    if (!carriesFiles(event)) return;
    event.preventDefault();
    delete document.body.dataset.dropping;
    importFile(event.dataTransfer.files[0]);
  });

  async function exportLoops(preselected) {
    const { library } = context();
    if (!library.length) { toast(t('share.export.empty'), true); return; }
    const chosen = new Set(library.some((entry) => entry.videoId === preselected) ? [preselected] : library.length === 1 ? [library[0].videoId] : []);
    const list = $('#export-list');
    const all = $('#export-all');
    const confirm = $('#export-confirm');
    list.replaceChildren(...library.map((entry) => {
      const label = element('label', 'share-item export-item');
      const box = Object.assign(element('input'), { type: 'checkbox', value: entry.videoId, checked: chosen.has(entry.videoId) });
      const copy = element('span', 'share-item-copy');
      copy.append(element('strong', 'share-item-title', videoTitle(entry.title, entry.videoId)), element('span', 'share-item-meta', `${t('share.export.sections', { count: entry.configuration.fragments.length })} · ${Math.round(entry.configuration.speed * 100)}%`));
      label.append(box, thumbnail(entry.videoId), copy);
      return label;
    }));
    const boxes = [...list.querySelectorAll('input')];
    const sync = () => {
      const count = boxes.filter((box) => box.checked).length;
      all.checked = count === boxes.length;
      all.indeterminate = count > 0 && count < boxes.length;
      confirm.disabled = !count;
      confirm.textContent = count ? t('share.export.buttonCount', { count }) : t('share.export.button');
    };
    const onAll = () => { for (const box of boxes) box.checked = all.checked; sync(); };
    list.addEventListener('change', sync);
    all.addEventListener('change', onAll);
    sync();
    const choice = await ask($('#export-dialog'));
    list.removeEventListener('change', sync);
    all.removeEventListener('change', onAll);
    if (choice !== 'export') return;
    const selected = new Set(boxes.filter((box) => box.checked).map((box) => box.value));
    const file = createLoopFile(context().library.filter((entry) => selected.has(entry.videoId)), { appVersion });
    const name = loopFileName(file.videos);
    Object.assign(document.createElement('a'), { href: await fileUrl(`${JSON.stringify(file, null, 2)}\n`), download: name }).click();
    toast(t('share.export.done', { name, count: file.videos.length }));
  }

  $('#export-loops').addEventListener('click', () => exportLoops(context().session?.videoId));

  return {
    // A diagram code pasted here gets a pointer to the fretboard instead of a link error.
    isCode: (text) => containsShareCode(text) || containsDiagramCode(text),
    importText,
    importFile,
    /** Continues opening a file started in the toolbar popup, once the library has loaded. */
    start() {
      if (new URLSearchParams(location.search).get('import') !== 'file') return;
      setView('library');
      setImportPanel(true);
      $('#import-file').focus();
      toast(t('share.panel.chooseFile'));
    },
  };
}
