// Floating practice controller UI. Runs inside the lesson page (content script) or the demo page.
import { registerHost, paintWindow } from './appearance.js';
import { formatLoopTime, parseLoopTime, normalizeConfiguration, normalizeView, adjustView, focusIndex, focusOnScreen, FOCUS_POINTS, MAX_LOOP_FRAGMENTS, MIN_SPEED, MAX_SPEED, QUIET_SPEED, MAX_ZOOM } from '../lib/core.js';
import { nudgeView } from '../lib/framing.js';
import { icon } from './icons.js';
import { attachJoystick } from './joystick.js';
import { setHTML, escapeHTML } from './html.js';
import { createToolsPanel } from './tools-view.js';
import { t, videoTitle } from '../lib/i18n.js';

const MARGIN = 16;
const HOST_TAG = 'loop-player-overlay';
const KEY_COMMANDS = { ' ': 'toggle-play', a: 'capture-a', b: 'capture-b', l: 'toggle-loop', r: 'restart' };
// Stage mode asks for a small detached window and takes over any window too small for the full controller.
const STAGE_WINDOW = { width: 300, height: 220 };
const COMPACT_WINDOW = { width: 300, height: 260 };
// Message keys of the focus points in lib/core.js, by screen position.
const FOCUS_KEYS = { '0,0': 'topLeft', '0.5,0': 'top', '1,0': 'topRight', '0,0.5': 'left', '0.5,0.5': 'center', '1,0.5': 'right', '0,1': 'bottomLeft', '0.5,1': 'bottom', '1,1': 'bottomRight' };
const clamp = (value, minimum, maximum) => Math.min(Math.max(value, minimum), maximum);

function markup() {
  // Translated text is escaped like any other value placed in markup.
  const text = (key, params) => escapeHTML(t(key, params));
  const focusLabel = (point) => t(`overlay.focus.${FOCUS_KEYS[`${point.x},${point.y}`]}`);
  return `
  <div class="lpo" data-collapsed="false" data-pip="false" data-stage="false" role="dialog" aria-label="Loop Player">
    <div class="lpo-head" data-drag>
      <span class="lpo-grip" aria-hidden="true">${icon('grip', { size: 14 })}</span>
      <span class="lpo-logo" aria-hidden="true">${icon('logo', { size: 15 })}</span>
      <div class="lpo-heading"><span class="lpo-status" data-ref="status" data-tip=""></span><strong class="lpo-title" data-ref="title" data-tip="" data-tip-overflow>Loop Player</strong></div>
      <div class="lpo-head-actions">
        <button class="icon-btn" data-action="stage" data-ref="stageToggle" aria-pressed="false" aria-label="${text('overlay.head.stage')}" data-tip="${text('overlay.head.stage')}">${icon('stage', { size: 16 })}</button>
        <button class="icon-btn" data-action="pip" data-ref="pip" aria-label="${text('overlay.head.popOut')}" data-tip="${text('overlay.head.popOut')}">${icon('pip', { size: 16 })}</button>
        <button class="icon-btn" data-action="collapse" aria-label="${text('overlay.head.minimize')}" data-tip="${text('overlay.head.minimize')}">${icon('chevronDown', { size: 16 })}</button>
        <button class="icon-btn" data-action="close" aria-label="${text('overlay.head.close')}" data-tip="${text('overlay.head.closeTip')}">${icon('x', { size: 16 })}</button>
      </div>
    </div>
    <div class="lpo-body">
      <div class="lpo-message" data-ref="message" hidden><span data-ref="messageText"></span><button class="btn btn-secondary btn-sm" data-action="reconnect" data-ref="reconnect">${icon('refresh', { size: 14 })}${text('overlay.status.reconnect')}</button></div>
      <div data-ref="controls">
        <div class="lpo-loopbar" data-ref="loopbar" data-tip="${text('overlay.transport.loopbar')}"><div class="lpo-loopbar-fill"></div><div class="lpo-loopbar-head"></div></div>
        <div class="lpo-times">
          <span class="lpo-now mono" data-ref="now">00:00.00</span>
          <span class="lpo-reps"><b data-ref="reps">0</b> <span data-ref="repsLabel">${escapeHTML(t('overlay.transport.reps', { count: 0 }))}</span></span>
          <span class="lpo-len mono" data-ref="length">10.00 s</span>
        </div>
        <div class="lpo-transport">
          <button class="icon-btn" data-cmd="restart" aria-label="${text('overlay.transport.restart')}" data-tip="${text('overlay.transport.restartTip')}" data-key="R">${icon('restart', { size: 18 })}</button>
          <button class="text-btn" data-cmd="seek" data-value="-1" aria-label="${text('overlay.transport.back')}" title="−1 s (←)">−1s</button>
          <button class="play-btn" data-cmd="toggle-play" data-ref="play" aria-label="${text('overlay.transport.play')}" title="${text('overlay.transport.playPause')}">${icon('play', { size: 22 })}</button>
          <button class="text-btn" data-cmd="seek" data-value="1" aria-label="${text('overlay.transport.forward')}" title="+1 s (→)">+1s</button>
          <button class="icon-btn" data-cmd="toggle-loop" data-ref="loop" aria-pressed="true" aria-label="${text('overlay.transport.loop')}" data-tip="${text('overlay.transport.loop')}" data-key="L">${icon('repeat', { size: 18 })}</button>
        </div>
        <div class="lpo-gap" data-ref="gap" hidden></div>
        <div class="lpo-observe" data-ref="observe" data-open="false">
          <button class="lpo-observe-toggle" data-action="observe" data-ref="observeToggle" aria-expanded="false" aria-controls="lpo-observe-tools">
            ${icon('eye', { size: 14 })}<span>${text('overlay.observe.title')}</span><span class="lpo-observe-summary" data-ref="observeSummary"></span>${icon('chevronDown', { size: 14, className: 'lpo-chevron' })}
          </button>
          <div class="lpo-observe-tools" id="lpo-observe-tools" data-ref="observeTools" hidden>
            <div class="lpo-observe-row">
              <div class="lpo-frames">
                <button class="icon-btn" data-cmd="frame-step" data-value="-1" data-ref="frameBack" aria-label="${text('overlay.observe.frameBack')}" data-tip="${text('overlay.observe.frameBack')}" data-key=",">${icon('frameBack', { size: 17 })}</button>
                <button class="icon-btn" data-cmd="frame-step" data-value="1" data-ref="frameForward" aria-label="${text('overlay.observe.frameForward')}" data-tip="${text('overlay.observe.frameForward')}" data-key=".">${icon('frameForward', { size: 17 })}</button>
              </div>
              <div class="stepper lpo-zoom" role="group" aria-label="${text('overlay.observe.zoom')}">
                <button data-zoom="-0.5" data-ref="zoomOut" aria-label="${text('overlay.observe.zoomOut')}">${icon('minus', { size: 13 })}</button>
                <button class="stepper-value" data-ref="zoom" data-zoom-reset data-tip="${text('overlay.observe.zoomReset')}">1×</button>
                <button data-zoom="0.5" data-ref="zoomIn" aria-label="${text('overlay.observe.zoomIn')}">${icon('plus', { size: 13 })}</button>
              </div>
              <div class="focus-grid" data-ref="focusGrid" role="group" aria-label="${text('overlay.observe.focusGroup')}">${FOCUS_POINTS.map((point, index) => `<button data-focus="${index}" aria-pressed="false" aria-label="${text('overlay.observe.focusOn', { point: focusLabel(point) })}" data-tip="${text('overlay.observe.focusOn', { point: focusLabel(point) })}"></button>`).join('')}<span class="focus-dot" data-ref="focusDot" hidden></span></div>
              <button class="icon-btn" data-action="mirror" data-ref="mirror" aria-pressed="false" aria-label="${text('overlay.observe.mirror')}" data-tip="${text('overlay.observe.mirror')}">${icon('mirror', { size: 17 })}</button>
            </div>
            <div class="lpo-framing">
              <div class="stick" data-ref="stick" tabindex="0" role="group" aria-label="${text('overlay.framing.label')}" title="${text('overlay.framing.help')}">
                ${[['0,-1', 'chevronUp', 'moveUp'], ['1,0', 'chevronRight', 'moveRight'], ['0,1', 'chevronDown', 'moveDown'], ['-1,0', 'chevronLeft', 'moveLeft']].map(([pan, name, label]) => `<button class="stick-arrow" data-pan="${pan}" tabindex="-1" aria-label="${text(`overlay.framing.${label}`)}">${icon(name, { size: 12 })}</button>`).join('')}
                <span class="stick-knob" data-ref="knob"></span>
              </div>
              <div class="lpo-framing-copy"><strong>${text('overlay.framing.title')}</strong><span data-ref="stickHint"></span></div>
              <button class="icon-btn" data-action="center-view" data-ref="centerView" aria-label="${text('overlay.framing.center')}" data-tip="${text('overlay.framing.centerTip')}">${icon('target', { size: 16 })}</button>
            </div>
          </div>
        </div>
        <div class="lpo-section">
          <div class="lpo-ab">
            ${['start', 'end'].map((point) => `
            <div class="lpo-point">
              <span class="lpo-letter">${point === 'start' ? 'A' : 'B'}</span>
              <input class="lpo-time-input mono" data-point="${point}" aria-label="${text(`overlay.points.${point}`)}" spellcheck="false" autocomplete="off">
              <button class="text-btn" data-nudge="${point}" data-value="-0.1" aria-label="${point === 'start' ? 'A' : 'B'} −0.1 s" title="−0.1 s">−.1</button>
              <button class="text-btn" data-nudge="${point}" data-value="0.1" aria-label="${point === 'start' ? 'A' : 'B'} +0.1 s" title="+0.1 s">+.1</button>
              <button class="btn btn-secondary" data-cmd="${point === 'start' ? 'capture-a' : 'capture-b'}" title="${text('overlay.points.setTip', { point: point === 'start' ? 'A' : 'B' })}">${text('overlay.points.set')}</button>
            </div>`).join('')}
          </div>
          <div class="lpo-row"><div class="lpo-parts" data-ref="parts" role="group" aria-label="${text('overlay.parts.label')}"></div><button class="icon-btn lpo-share-toggle" data-action="share" data-ref="shareToggle" aria-expanded="false" aria-label="${text('overlay.share.label')}" data-tip="${text('overlay.share.tip')}">${icon('share', { size: 15 })}</button></div>
          <div class="lpo-share" data-ref="share" hidden>
            <span class="lpo-share-label">${text('overlay.share.copyFrom')}</span>
            <div class="lpo-share-choices"><button class="btn btn-secondary" data-share="active" data-ref="shareActive">${text('overlay.share.active')}</button><button class="btn btn-secondary" data-share="all" data-ref="shareAll">${text('overlay.share.all')}</button></div>
            <input class="lpo-share-code mono" data-ref="shareCode" readonly aria-label="${text('overlay.share.code')}" hidden>
          </div>
          <div class="lpo-tempo">
            <div class="lpo-field"><span>${text('overlay.tempo.speed')}</span><div class="stepper">
              <button data-step="speed" data-value="-0.05" aria-label="${text('overlay.tempo.speedDown')}">${icon('minus', { size: 13 })}</button>
              <button class="stepper-value" data-ref="speed" data-reset="speed" data-tip="${text('overlay.tempo.speedReset')}">100%</button>
              <button data-step="speed" data-value="0.05" aria-label="${text('overlay.tempo.speedUp')}">${icon('plus', { size: 13 })}</button>
            </div></div>
            <div class="lpo-field"><span>${text('overlay.tempo.gap')}</span><div class="stepper">
              <button data-step="gap" data-value="-0.5" aria-label="${text('overlay.tempo.gapDown')}">${icon('minus', { size: 13 })}</button>
              <button class="stepper-value" data-ref="gapValue" data-reset="gap" data-tip="${text('overlay.tempo.gapReset')}">0 s</button>
              <button data-step="gap" data-value="0.5" aria-label="${text('overlay.tempo.gapUp')}">${icon('plus', { size: 13 })}</button>
            </div></div>
          </div>
          <div class="lpo-hint" data-ref="speedHint" hidden>${text('overlay.tempo.quietHint')}</div>
        </div>
      </div>
      <div class="lpo-tools" data-ref="toolsSection" hidden>
        <button class="lpo-tools-toggle" data-action="tools" data-ref="toolsToggle" aria-expanded="false">${icon('wave', { size: 15 })}<span>${text('overlay.tools.title')}</span><span class="lpo-tools-summary" data-ref="toolsSummary"></span>${icon('chevronDown', { size: 14, className: 'lpo-tools-chevron' })}</button>
        <div class="lpo-tools-body" data-ref="toolsBody" hidden></div>
      </div>
    </div>
    <div class="lpo-mini" data-drag>
      <button class="play-btn" data-cmd="toggle-play" data-ref="miniPlay" aria-label="${text('overlay.transport.play')}">${icon('play', { size: 18 })}</button>
      <span class="lpo-now mono" data-ref="miniNow">00:00.00</span>
      <span class="lpo-reps"><b data-ref="miniReps">0</b>×</span>
      <button class="icon-btn" data-cmd="toggle-loop" data-ref="miniLoop" aria-pressed="true" aria-label="${text('overlay.transport.loop')}" data-tip="${text('overlay.transport.loop')}" data-key="L">${icon('repeat', { size: 16 })}</button>
      <button class="icon-btn" data-action="expand" aria-label="${text('overlay.head.expand')}" data-tip="${text('overlay.head.expandTip')}">${icon('chevronUp', { size: 16 })}</button>
    </div>
    <div class="lpo-stage" data-ref="stagePanel" data-tone="">
      <div class="lpo-stage-top">
        <span class="lpo-stage-state" data-ref="stageState" data-tip="${text('overlay.stage.state')}">${text('overlay.status.paused')}</span>
        <span class="lpo-stage-now mono" data-ref="stageNow">00:00.00</span>
        <span class="lpo-stage-part" data-ref="stagePartBox" data-tip="${text('overlay.stage.part')}"><small>${text('overlay.stage.partLabel')}</small><b data-ref="stagePart">1</b>/<span data-ref="stageParts">1</span></span>
        <button class="icon-btn" data-action="stage" data-ref="stageExit" aria-label="${text('overlay.stage.exit')}" data-tip="${text('overlay.stage.exitTip')}">${icon('settings', { size: 16 })}</button>
        <button class="icon-btn" data-action="pip" aria-label="${text('overlay.head.backToPage')}" data-tip="${text('overlay.stage.backToPageTip')}">${icon('pipExit', { size: 16 })}</button>
      </div>
      <div class="lpo-stage-note" data-ref="stageNote" hidden><span data-ref="stageNoteText"></span><button class="btn btn-secondary btn-sm" data-action="reconnect" data-ref="stageReconnect">${icon('refresh', { size: 14 })}${text('overlay.status.reconnect')}</button></div>
      <div class="lpo-stage-pad" data-ref="stagePad">
        <button class="lpo-stage-btn lpo-stage-restart" data-cmd="restart" data-ref="stageRestart" aria-label="${text('overlay.transport.restart')}" data-tip="${text('overlay.transport.restartTip')}" data-key="R">${icon('restart', { size: 32 })}<span class="lpo-stage-badge" aria-hidden="true">A</span></button>
        <button class="lpo-stage-btn lpo-stage-play" data-cmd="toggle-play" data-ref="stagePlay" aria-label="${text('overlay.transport.play')}" data-tip="${text('overlay.stage.play')}" data-key="${text('overlay.keys.space')}"><span class="lpo-stage-icon" data-ref="stagePlayIcon">${icon('play', { size: 48 })}</span><span class="lpo-stage-count mono" data-ref="stageCount" hidden></span></button>
        <button class="lpo-stage-btn lpo-stage-prev" data-action="part-step" data-value="-1" data-ref="stagePrev" aria-label="${text('overlay.stage.prev')}" data-tip="${text('overlay.stage.prev')}" data-key="↑">${icon('chevronLeft', { size: 28 })}<span class="lpo-stage-tag" data-ref="stagePrevTag"></span></button>
        <button class="lpo-stage-btn lpo-stage-loop" data-cmd="toggle-loop" data-ref="stageLoop" aria-pressed="true" aria-label="${text('overlay.transport.loop')}" data-tip="${text('overlay.transport.loop')}" data-key="L"><span class="lpo-stage-strike">${icon('repeat', { size: 28 })}</span><span class="lpo-stage-tag" data-ref="stageReps">0×</span></button>
        <button class="lpo-stage-btn lpo-stage-next" data-action="part-step" data-value="1" data-ref="stageNext" aria-label="${text('overlay.stage.next')}" data-tip="${text('overlay.stage.next')}" data-key="↓"><span class="lpo-stage-tag" data-ref="stageNextTag"></span>${icon('chevronRight', { size: 28 })}</button>
      </div>
    </div>
    <div class="lpo-toast" data-ref="toast" role="status" hidden></div>
  </div>
  <div class="lpo-tip" data-ref="tip" role="tooltip" hidden><span data-ref="tipText"></span><kbd class="lpo-tip-key" data-ref="tipKey"></kbd></div>`;
}

/**
 * @param {{css: string, send: (message: object) => Promise<any>, documentRef?: Document, tools?: object}} options
 * `tools` is the tools client (ui/tools-client.js); without it the Ferramentas area stays hidden.
 * `pip` is the page's shared Picture-in-Picture host (ui/pip.js): the tool windows join the same
 * detached window as tabs instead of closing the controller's.
 */
export function createOverlay({ css, send, documentRef = document, tools = null, pip = null }) {
  const host = documentRef.createElement(HOST_TAG);
  host.setAttribute('data-loop-player-overlay', '');
  const unregisterHost = registerHost(host);
  const shadow = host.attachShadow({ mode: 'closed' });
  setHTML(shadow, markup());
  const root = shadow.querySelector('.lpo');
  const refs = Object.fromEntries([...shadow.querySelectorAll('[data-ref]')].map((element) => [element.dataset.ref, element]));
  const pointInputs = [...shadow.querySelectorAll('[data-point]')];
  root.tabIndex = -1;

  let state = { visible: false, session: null, title: '', prefs: {} };
  let stamp = performance.now();
  let frame = null;
  let positioned = false;
  let position = { fx: 1, fy: 1 };
  let drag = null;
  let scrub = null;
  let pipWindow = null;
  let toastTimer = null;
  let shareOpen = false;
  let partKey = '';
  let draft = {};
  let draftTimer = null;
  let busy = false;
  let observeOpen = false;
  const tip = { target: null, timer: null, warmUntil: 0, muted: null };
  let stagePref = false;
  let stageHeard;
  let stageOverride = null;
  let compact = false;
  let toolsOpen = false;
  const toolsPanel = tools ? createToolsPanel({
    client: tools, mode: 'tabs', documentRef,
    onTabChange: () => savePrefs(),
    onSummary: (summary) => { refs.toolsSummary.textContent = toolsOpen || summary.text === '—' ? '' : summary.text; },
    onError: (message) => flash(message),
  }) : null;
  if (toolsPanel) refs.toolsBody.append(toolsPanel.element);

  const view = () => host.ownerDocument.defaultView;
  const configuration = () => state.session ? normalizeConfiguration(state.session.configuration, state.session.duration || Infinity) : null;
  const fragmentOf = (config) => config.fragments[config.activeFragmentIndex];
  const ready = () => Boolean(state.session && !state.session.error && !state.session.adPlaying && state.session.duration > 0);
  const playing = () => ready() && !state.session.paused && !(state.session.gapRemaining > 0);
  // The remembered choice wins in a roomy window; a small one switches to stage mode until the user says otherwise.
  const staged = () => Boolean(pipWindow) && (stageOverride ?? (stagePref || compact));

  function adoptStyles() {
    const sheet = new (view().CSSStyleSheet)();
    sheet.replaceSync(css);
    shadow.adoptedStyleSheets = [sheet];
  }

  function hostStyle(properties) {
    for (const [name, value] of Object.entries(properties)) host.style.setProperty(name, value, 'important');
  }

  function attach() {
    adoptStyles();
    hostStyle({ position: 'fixed', 'z-index': '2147483647', left: '0px', top: '0px', margin: '0', display: 'none' });
    documentRef.documentElement.append(host);
  }

  function place(x, y) {
    if (pipWindow) return;
    const rect = root.getBoundingClientRect();
    const width = documentRef.documentElement.clientWidth || view().innerWidth;
    const height = view().innerHeight;
    const maxX = Math.max(MARGIN, width - rect.width - MARGIN);
    const maxY = Math.max(MARGIN, height - rect.height - MARGIN);
    const left = clamp(x ?? MARGIN + position.fx * (maxX - MARGIN), MARGIN, maxX);
    const top = clamp(y ?? MARGIN + position.fy * (maxY - MARGIN), MARGIN, maxY);
    if (x !== undefined) position = { fx: maxX > MARGIN ? (left - MARGIN) / (maxX - MARGIN) : 0, fy: maxY > MARGIN ? (top - MARGIN) / (maxY - MARGIN) : 0 };
    hostStyle({ left: `${Math.round(left)}px`, top: `${Math.round(top)}px` });
  }

  function savePrefs() {
    send({ type: 'OVERLAY_PREFS', prefs: { position, collapsed: root.dataset.collapsed === 'true', observe: observeOpen, stage: stagePref, tools: { open: toolsOpen, tab: toolsPanel?.tab || 'tuner' } } });
  }

  // Tools listen to the input only while their area is open and the controller is expanded.
  function renderTools() {
    refs.toolsSection.hidden = !toolsPanel;
    if (!toolsPanel) return;
    refs.toolsBody.hidden = !toolsOpen;
    refs.toolsToggle.setAttribute('aria-expanded', String(toolsOpen));
    toolsPanel.setActive(state.visible && Boolean(state.session) && toolsOpen && root.dataset.collapsed !== 'true');
    if (toolsOpen) refs.toolsSummary.textContent = '';
  }

  function setToolsOpen(open, tool) {
    const before = root.getBoundingClientRect().height;
    toolsOpen = open;
    if (tool) toolsPanel?.setTab(tool);
    renderTools();
    place();
    // A detached controller grows with the area so nothing is cut off.
    if (pipWindow) {
      try { pipWindow.resizeBy(0, Math.round(root.getBoundingClientRect().height - before)); } catch { /* The window keeps its size and scrolls. */ }
    }
  }

  function flash(message, tone = 'danger') {
    clearTimeout(toastTimer);
    refs.toast.textContent = message;
    refs.toast.dataset.tone = tone;
    refs.toast.hidden = false;
    toastTimer = setTimeout(() => { refs.toast.hidden = true; }, tone === 'ok' ? 2500 : 5000);
  }

  function liveTime() {
    const session = state.session;
    if (!session) return 0;
    let time = session.currentTime || 0;
    if (playing()) {
      time += ((performance.now() - stamp) / 1000) * (session.configuration?.speed || 1);
      const config = configuration();
      const fragment = fragmentOf(config);
      if (config.loopEnabled && session.currentTime < fragment.end) time = Math.min(time, fragment.end);
    }
    return clamp(time, 0, session.duration || time);
  }

  function paintClock() {
    const config = configuration();
    if (!config) return;
    const fragment = fragmentOf(config);
    const time = scrub ? scrub.time : liveTime();
    const text = formatLoopTime(time);
    refs.now.textContent = text;
    refs.miniNow.textContent = text;
    refs.stageNow.textContent = text;
    const progress = ((time - fragment.start) / (fragment.end - fragment.start)) * 100;
    refs.loopbar.style.setProperty('--p', clamp(progress, 0, 100).toFixed(2));
    refs.loopbar.dataset.outside = String(progress < 0 || progress > 100);
  }

  function tick() {
    frame = null;
    if (!state.visible) return;
    paintClock();
    if (playing() && !scrub) frame = view().requestAnimationFrame(tick);
  }

  function startClock() {
    paintClock();
    if (!frame) frame = view().requestAnimationFrame(tick);
  }

  function status() {
    const session = state.session;
    const waiting = session.errorCode === 'PLAYER_NOT_READY' || (!session.error && !session.duration);
    if (waiting) return { tone: 'warn', label: t('overlay.status.waiting'), message: t('overlay.status.waitingMessage'), reconnect: false };
    if (session.adPlaying) return { tone: 'warn', label: t('overlay.status.ad'), message: t('overlay.status.adMessage'), reconnect: false };
    if (session.error) return { tone: 'danger', label: t('overlay.status.disconnected'), message: session.error, reconnect: true };
    if (session.gapRemaining > 0) return { tone: 'warn', label: t('overlay.status.gap') };
    return session.paused ? { tone: '', label: t('overlay.status.paused') } : { tone: 'live', label: t('overlay.status.playing') };
  }

  function renderTempo(config) {
    const speed = draft.speed ?? config.speed;
    const gap = draft.gap ?? config.gapSeconds;
    refs.speed.textContent = `${Math.round(speed * 100)}%`;
    refs.gapValue.textContent = `${Number.isInteger(gap) ? gap : gap.toFixed(1)} s`;
    shadow.querySelector('[data-step="speed"][data-value^="-"]').disabled = speed <= MIN_SPEED;
    shadow.querySelector('[data-step="speed"]:not([data-value^="-"])').disabled = speed >= MAX_SPEED;
    refs.speedHint.hidden = speed >= QUIET_SPEED;
    shadow.querySelector('[data-step="gap"][data-value^="-"]').disabled = gap <= 0;
    shadow.querySelector('[data-step="gap"]:not([data-value^="-"])').disabled = gap >= 30;
  }

  // Zoom and focus belong to the selected fragment; a pending edit wins until it is saved.
  function activeView(config) {
    return draft.view?.index === config.activeFragmentIndex ? draft.view.value : normalizeView(fragmentOf(config).view);
  }

  function renderObserve(config) {
    const view = activeView(config);
    const zoom = view?.zoom ?? 1;
    const mirror = draft.mirror ?? config.mirror;
    const focused = focusIndex(view, mirror);
    refs.zoom.textContent = `${zoom}×`;
    refs.zoomOut.disabled = zoom <= 1;
    refs.zoomIn.disabled = zoom >= MAX_ZOOM;
    for (const cell of refs.focusGrid.querySelectorAll('[data-focus]')) cell.setAttribute('aria-pressed', String(Number(cell.dataset.focus) === focused));
    const point = focusOnScreen(view, mirror);
    refs.focusDot.hidden = !point;
    if (point) { refs.focusDot.style.setProperty('--fx', point.x); refs.focusDot.style.setProperty('--fy', point.y); }
    refs.mirror.setAttribute('aria-pressed', String(mirror));
    refs.mirror.dataset.tip = t(mirror ? 'overlay.observe.mirrored' : 'overlay.observe.mirror');
    const canPan = zoom > 1;
    refs.stick.setAttribute('aria-disabled', String(!canPan));
    refs.stick.tabIndex = canPan ? 0 : -1;
    for (const arrow of refs.stick.querySelectorAll('[data-pan]')) arrow.disabled = !canPan;
    refs.centerView.disabled = !canPan || (view.x === 0.5 && view.y === 0.5);
    refs.stickHint.textContent = t(canPan ? 'overlay.framing.hint' : 'overlay.framing.needsZoom');
    refs.observeSummary.textContent = [zoom > 1 ? `${zoom}×` : '', mirror ? t('overlay.observe.mirroredSummary') : ''].filter(Boolean).join(' · ');
    refs.observe.dataset.open = String(observeOpen);
    refs.observeToggle.setAttribute('aria-expanded', String(observeOpen));
    refs.observeTools.hidden = !observeOpen;
    const fps = state.session.frameRate ? ` · ${Math.round(state.session.frameRate)} fps` : '';
    refs.frameBack.dataset.tip = `${t('overlay.observe.frameBack')}${fps}`;
    refs.frameForward.dataset.tip = `${t('overlay.observe.frameForward')}${fps}`;
  }

  // Drawn tooltips for controls whose icon or hidden click is not self-explanatory.
  // Native titles only show while Chrome is the active app, and while recording it is not.
  function fillTip() {
    const target = tip.target;
    if (!target?.isConnected || !target.getClientRects().length || !target.dataset.tip) { hideTip(); return; }
    refs.tipText.textContent = target.dataset.tip;
    refs.tipKey.textContent = target.dataset.key || '';
    refs.tipKey.hidden = !target.dataset.key;
    refs.tip.hidden = false;
    // Measure at the corner so the previous position does not squeeze the text.
    refs.tip.style.setProperty('left', '0px');
    refs.tip.style.setProperty('top', '0px');
    const page = host.ownerDocument.documentElement;
    const rect = target.getBoundingClientRect();
    const width = refs.tip.offsetWidth;
    const height = refs.tip.offsetHeight;
    const above = rect.top - height - 6 >= 4;
    const top = above ? rect.top - height - 6 : Math.min(rect.bottom + 6, (page.clientHeight || view().innerHeight) - height - 4);
    const center = rect.left + rect.width / 2;
    const left = clamp(center - width / 2, 4, Math.max(4, (page.clientWidth || view().innerWidth) - width - 4));
    refs.tip.dataset.side = above ? 'top' : 'bottom';
    refs.tip.style.setProperty('left', `${Math.round(left)}px`);
    refs.tip.style.setProperty('top', `${Math.round(top)}px`);
    refs.tip.style.setProperty('--arrow', `${Math.round(clamp(center - left, 10, width - 10))}px`);
  }

  function showTip(target, delay) {
    clearTimeout(tip.timer);
    tip.target = target;
    if (delay) tip.timer = setTimeout(fillTip, delay);
    else fillTip();
  }

  function hideTip() {
    clearTimeout(tip.timer);
    // Moving straight to a neighbouring button shows its tip without waiting again.
    if (!refs.tip.hidden) tip.warmUntil = performance.now() + 600;
    tip.target = null;
    refs.tip.hidden = true;
  }

  function renderStage(info) {
    const active = staged();
    root.dataset.stage = String(active);
    refs.stageToggle.setAttribute('aria-pressed', String(active));
    if (!active) { if (tip.target) fillTip(); return; }
    const session = state.session;
    refs.stagePanel.dataset.tone = info.tone;
    refs.stagePanel.dataset.ready = String(ready());
    refs.stageState.textContent = info.label;
    refs.stageNote.hidden = !info.message;
    refs.stageNoteText.textContent = info.message || '';
    refs.stageReconnect.hidden = !info.reconnect;
    refs.stagePad.hidden = Boolean(info.message);
    if (!ready()) return;
    const config = configuration();
    const index = config.activeFragmentIndex;
    const count = config.fragments.length;
    const waiting = session.gapRemaining > 0;
    const name = session.paused && !waiting ? 'play' : 'pause';
    if (refs.stagePlayIcon.dataset.icon !== name) { setHTML(refs.stagePlayIcon, icon(name, { size: 48 })); refs.stagePlayIcon.dataset.icon = name; }
    refs.stagePlay.setAttribute('aria-label', t(name === 'play' ? 'overlay.transport.play' : 'overlay.transport.pause'));
    refs.stagePlay.dataset.tip = t(name === 'play' ? 'overlay.stage.play' : waiting ? 'overlay.stage.pauseGap' : 'overlay.transport.pause');
    // The pause between repetitions counts down on the button that cancels it.
    refs.stageCount.hidden = !waiting;
    refs.stageCount.textContent = waiting ? session.gapRemaining.toFixed(1) : '';
    refs.stageLoop.setAttribute('aria-pressed', String(config.loopEnabled));
    const reps = session.repetitions || 0;
    refs.stageLoop.dataset.tip = config.loopEnabled ? t('overlay.stage.loopOn', { count: reps }) : t('overlay.transport.loopOff');
    refs.stagePartBox.dataset.tip = t('overlay.stage.partOf', { number: index + 1, total: count });
    refs.stagePart.textContent = index + 1;
    refs.stageParts.textContent = count;
    refs.stageReps.textContent = `${session.repetitions || 0}×`;
    refs.stagePrev.disabled = index === 0;
    refs.stagePrevTag.textContent = index === 0 ? '' : index;
    refs.stagePrev.dataset.tip = index === 0 ? t('overlay.stage.first') : t('overlay.stage.goTo', { number: index });
    refs.stageNext.disabled = index >= count - 1;
    refs.stageNextTag.textContent = index >= count - 1 ? '' : index + 2;
    refs.stageNext.dataset.tip = index >= count - 1 ? t('overlay.stage.last') : t('overlay.stage.goTo', { number: index + 2 });
    if (tip.target && !refs.tip.hidden) fillTip();
  }

  function render() {
    const session = state.session;
    if (!state.visible || !session) {
      hostStyle({ display: 'none' });
      exitPip();
      renderTools();
      return;
    }
    hostStyle({ display: 'block' });
    const info = status();
    refs.title.textContent = videoTitle(state.title, session.videoId);
    refs.title.dataset.tip = refs.title.textContent;
    refs.status.dataset.tone = info.tone;
    refs.status.dataset.tip = info.label;
    refs.message.hidden = !info.message;
    refs.message.dataset.tone = info.tone;
    refs.messageText.textContent = info.message || '';
    refs.reconnect.hidden = !info.reconnect;
    refs.controls.hidden = !ready();
    for (const button of shadow.querySelectorAll('.lpo-mini button[data-cmd]')) button.disabled = !ready();
    if (!positioned) {
      positioned = true;
      if (state.prefs?.position) position = { fx: clamp(Number(state.prefs.position.fx) || 0, 0, 1), fy: clamp(Number(state.prefs.position.fy) || 0, 0, 1) };
      root.dataset.collapsed = String(state.prefs?.collapsed === true);
      observeOpen = state.prefs?.observe === true;
      toolsOpen = state.prefs?.tools?.open === true;
      if (state.prefs?.tools?.tab) toolsPanel?.setTab(state.prefs.tools.tab);
    }
    // Follow the switch in Ajustes; the echo of a choice made here must not undo it.
    if (state.prefs?.stage !== undefined && state.prefs.stage !== stageHeard) {
      stageHeard = state.prefs.stage;
      if (stagePref !== (stageHeard === true)) {
        stagePref = stageHeard === true;
        stageOverride = null;
      }
    }
    renderStage(info);
    renderTools();
    if (!ready()) { place(); return; }

    const config = configuration();
    const fragment = fragmentOf(config);
    const isPlaying = !(session.paused && !session.gapRemaining);
    for (const [button, size] of [[refs.play, 22], [refs.miniPlay, 18]]) {
      const name = isPlaying ? 'pause' : 'play';
      if (button.dataset.icon !== name) { setHTML(button, icon(name, { size })); button.dataset.icon = name; }
      button.setAttribute('aria-label', t(isPlaying ? 'overlay.transport.pause' : 'overlay.transport.play'));
    }
    for (const button of [refs.loop, refs.miniLoop]) {
      button.setAttribute('aria-pressed', String(config.loopEnabled));
      button.dataset.tip = t(config.loopEnabled ? 'overlay.transport.loopOn' : 'overlay.transport.loopOff');
    }
    refs.loopbar.dataset.loop = String(config.loopEnabled);
    refs.reps.textContent = session.repetitions || 0;
    refs.miniReps.textContent = session.repetitions || 0;
    refs.repsLabel.textContent = t('overlay.transport.reps', { count: session.repetitions || 0 });
    refs.length.textContent = `${(fragment.end - fragment.start).toFixed(2)} s`;
    refs.gap.hidden = !(session.gapRemaining > 0);
    refs.gap.textContent = session.gapRemaining > 0 ? t('overlay.transport.restartsIn', { seconds: session.gapRemaining.toFixed(1) }) : '';
    for (const input of pointInputs) {
      if (shadow.activeElement !== input) input.value = formatLoopTime(fragment[input.dataset.point]);
    }
    const nextPartKey = JSON.stringify([config.fragments, config.activeFragmentIndex]);
    if (nextPartKey !== partKey) {
      partKey = nextPartKey;
      const addLabel = escapeHTML(t('overlay.parts.add'));
      setHTML(refs.parts, config.fragments.map((part, index) => `<button class="chip" data-part="${index}" aria-pressed="${index === config.activeFragmentIndex}" data-tip="${escapeHTML(t('overlay.parts.part', { number: index + 1, start: formatLoopTime(part.start), end: formatLoopTime(part.end) }))}" data-key="${index + 1}">${index + 1}</button>`).join('')
        + (config.fragments.length < MAX_LOOP_FRAGMENTS ? `<button class="chip chip-add" data-action="add-part" aria-label="${addLabel}" data-tip="${addLabel}">${icon('plus', { size: 13 })}</button>` : ''));
    }
    renderShare(config);
    renderTempo(config);
    renderObserve(config);
    if (tip.target && !refs.tip.hidden) fillTip();
    place();
    startClock();
  }

  function renderShare(config) {
    refs.share.hidden = !shareOpen;
    refs.shareToggle.setAttribute('aria-expanded', String(shareOpen));
    refs.shareActive.textContent = `${t('overlay.share.active')} (${config.activeFragmentIndex + 1})`;
    refs.shareAll.textContent = `${t('overlay.share.all')} (${config.fragments.length})`;
    if (!shareOpen) refs.shareCode.hidden = true;
  }

  // The worker builds the code from the live session; another Loop Player imports it in its Biblioteca.
  async function shareLoop(scope) {
    const config = configuration();
    if (!config || !ready()) return;
    if (!scope && config.fragments.length > 1) { shareOpen = !shareOpen; render(); return; }
    const response = await send({ type: 'OVERLAY_SHARE', scope: scope || 'all' });
    if (!response?.ok || !response.code) { flash(response?.error || t('overlay.share.failed')); return; }
    try {
      await view().navigator.clipboard.writeText(response.code);
      shareOpen = false;
      render();
      flash(t('overlay.share.copied'), 'ok');
    } catch {
      // Some pages block the clipboard; the code stays selected for ⌘C or Ctrl+C.
      shareOpen = true;
      render();
      refs.shareCode.value = response.code;
      refs.shareCode.hidden = false;
      place();
      refs.shareCode.focus();
      refs.shareCode.select();
      flash(t('overlay.share.copyManually'), 'ok');
    }
  }

  function applySession(session) {
    if (!session) return;
    state.session = session;
    stamp = performance.now();
    render();
  }

  async function run(message) {
    const response = await send(message);
    if (response?.ok === false && response.error) flash(response.error);
    if (response?.session) applySession(response.session);
    return response;
  }

  function command(name, value) {
    if (!ready()) return;
    run({ type: 'OVERLAY_COMMAND', command: name, ...(value === undefined ? {} : { value }) });
  }

  async function setConfiguration(next) {
    if (busy) return false;
    busy = true;
    try { return Boolean((await run({ type: 'OVERLAY_SET_CONFIG', configuration: next }))?.ok); }
    finally { busy = false; render(); }
  }

  function editPoint(point, value) {
    const config = configuration();
    if (!config) return;
    const fragment = fragmentOf(config);
    const parsed = parseLoopTime(value);
    const next = { ...fragment, [point]: parsed };
    if (parsed === null || next.start < 0 || next.end > state.session.duration || Math.round(next.end * 100) - Math.round(next.start * 100) < 10) {
      flash(t('overlay.points.invalid'));
      render();
      return;
    }
    config.fragments[config.activeFragmentIndex] = next;
    setConfiguration(config);
  }

  function stepTempo(kind, delta) {
    const config = configuration();
    if (!config || !ready()) return;
    const current = draft[kind] ?? (kind === 'speed' ? config.speed : config.gapSeconds);
    draft[kind] = kind === 'speed' ? clamp(Math.round((current + delta) * 100) / 100, MIN_SPEED, MAX_SPEED) : clamp(Math.round((current + delta) * 10) / 10, 0, 30);
    renderTempo(config);
    scheduleDraft(350);
  }

  function reframe(change) {
    const config = configuration();
    if (!config || !ready()) return;
    draft.view = { index: config.activeFragmentIndex, value: adjustView(activeView(config), change, draft.mirror ?? config.mirror) };
    renderObserve(config);
    scheduleDraft(150);
  }

  function toggleMirror() {
    const config = configuration();
    if (!config || !ready()) return;
    draft.mirror = !(draft.mirror ?? config.mirror);
    renderObserve(config);
    scheduleDraft(150);
  }

  // The joystick and arrows show their framing live and save it once they settle.
  function framingState() {
    const config = configuration();
    if (!config || !ready()) return null;
    return { index: config.activeFragmentIndex, view: activeView(config), mirror: draft.mirror ?? config.mirror };
  }

  function liveView(view, framing) {
    draft.view = { index: framing.index, value: view };
    const config = configuration();
    if (config) renderObserve(config);
  }

  function previewView(view, framing) {
    send({ type: 'OVERLAY_PREVIEW_VIEW', index: framing.index, view, mirror: framing.mirror });
  }

  function nudge(direction, multiplier = 1) {
    const framing = framingState();
    if (!framing?.view) return;
    const view = nudgeView(framing.view, direction, framing.mirror, multiplier);
    liveView(view, framing);
    previewView(view, framing);
    scheduleDraft(400);
  }

  function scheduleDraft(delay) {
    clearTimeout(draftTimer);
    draftTimer = setTimeout(flushDraft, delay);
  }

  async function flushDraft() {
    if (busy || joystick.active) { draftTimer = setTimeout(flushDraft, 200); return; }
    const sent = { ...draft };
    const config = configuration();
    if (!config || !Object.keys(sent).length) return;
    if (sent.speed !== undefined) config.speed = sent.speed;
    if (sent.gap !== undefined) config.gapSeconds = sent.gap;
    if (sent.mirror !== undefined) config.mirror = sent.mirror;
    const fragment = sent.view && config.fragments[sent.view.index];
    if (fragment) {
      if (sent.view.value) fragment.view = sent.view.value;
      else delete fragment.view;
    }
    await setConfiguration(config);
    for (const [kind, value] of Object.entries(sent)) if (draft[kind] === value) delete draft[kind];
    render();
  }

  function toggleObserve() {
    observeOpen = !observeOpen;
    render();
    savePrefs();
  }

  function addPart() {
    const config = configuration();
    if (!config || config.fragments.length >= MAX_LOOP_FRAGMENTS) return;
    const end = Math.floor(state.session.duration * 100) / 100;
    const start = Math.round(Math.max(0, Math.min(liveTime(), end - Math.min(10, end))) * 100) / 100;
    config.fragments.push({ start, end: Math.min(end, start + 10) });
    config.activeFragmentIndex = config.fragments.length - 1;
    setConfiguration(config);
  }

  function stepPart(delta) {
    const config = configuration();
    if (!config || !ready()) return;
    const index = config.activeFragmentIndex + delta;
    if (index >= 0 && index < config.fragments.length) command('select-part', index);
  }

  function toggleStage() {
    if (!pipWindow) return;
    const next = !staged();
    stagePref = next;
    stageOverride = next;
    render();
    root.focus({ preventScroll: true });
    savePrefs();
  }

  // Crossing the size threshold hands the layout back to the window size.
  function measurePip() {
    if (!pipWindow) return;
    const next = pipWindow.innerWidth < COMPACT_WINDOW.width || pipWindow.innerHeight < COMPACT_WINDOW.height;
    if (next === compact) return;
    compact = next;
    stageOverride = null;
    render();
  }

  function setCollapsed(collapsed) {
    root.dataset.collapsed = String(collapsed);
    renderTools();
    place();
    // The pressed button is hidden now; keep keyboard focus inside the controller.
    root.focus({ preventScroll: true });
    savePrefs();
  }

  function returnToPage() {
    pipWindow = null;
    compact = false;
    stageOverride = null;
    root.dataset.pip = 'false';
    documentRef.documentElement.append(host);
    host.style.removeProperty('width');
    hostStyle({ position: 'fixed' });
    adoptStyles();
    setHTML(refs.pip, icon('pip', { size: 16 }));
    refs.pip.dataset.tip = t('overlay.head.popOut');
    refs.pip.setAttribute('aria-label', t('overlay.head.popOut'));
    frame = null;
    render();
  }

  // Leaves only the controller's tab when tool windows share the detached window.
  function exitPip() {
    if (!pipWindow) return;
    if (pip) pip.leave('practice');
    else pipWindow.close();
  }

  async function togglePip() {
    if (pipWindow) { exitPip(); return; }
    const size = stagePref ? STAGE_WINDOW : { width: 320, height: Math.max(360, Math.round(root.getBoundingClientRect().height) + 8) };
    let slot;
    try {
      if (pip) {
        ({ window: pipWindow, slot } = await pip.enter({ id: 'practice', label: t('overlay.pip.controller'), icon: 'logo', size, onLeave: returnToPage }));
      } else {
        const pictureInPicture = view().documentPictureInPicture;
        if (!pictureInPicture?.requestWindow) throw new Error(t('overlay.pip.unsupported'));
        pipWindow = await pictureInPicture.requestWindow(size);
        pipWindow.document.title = 'Loop Player';
        paintWindow(pipWindow);
        pipWindow.document.body.style.setProperty('margin', '0');
        slot = pipWindow.document.body;
        pipWindow.addEventListener('pagehide', returnToPage, { once: true });
      }
    } catch (error) {
      pipWindow = null;
      flash(error.message);
      return;
    }
    root.dataset.collapsed = 'false';
    root.dataset.pip = 'true';
    slot.append(host);
    hostStyle({ position: 'static', display: 'block', left: 'auto', top: 'auto', width: '100%' });
    adoptStyles();
    setHTML(refs.pip, icon('pipExit', { size: 16 }));
    refs.pip.dataset.tip = t('overlay.head.backToPage');
    refs.pip.setAttribute('aria-label', t('overlay.head.backToPage'));
    pipWindow.document.addEventListener('keydown', onKeydown);
    pipWindow.addEventListener('resize', measurePip);
    frame = null;
    measurePip();
    render();
  }


  function onKeydown(event) {
    // Keys typed in the controller never reach the lesson page or its player shortcuts.
    event.stopPropagation();
    if (!event.isTrusted || event.altKey || event.ctrlKey || event.metaKey) return;
    const target = event.composedPath()[0];
    if (target instanceof view().HTMLInputElement || target?.tagName === 'INPUT') {
      if (event.key === 'Enter') target.blur();
      if (event.key === 'Escape') {
        // Restoring the focused value first keeps blur from committing the edit.
        const config = configuration();
        if (config && target.dataset.point) target.value = formatLoopTime(fragmentOf(config)[target.dataset.point]);
        target.blur();
      }
      return;
    }
    if (!ready() || event.repeat) return;
    const key = event.key.toLowerCase();
    if (KEY_COMMANDS[key]) { event.preventDefault(); command(KEY_COMMANDS[key]); }
    else if (/^[1-9]$/.test(key) && Number(key) <= configuration().fragments.length) { event.preventDefault(); command('select-part', Number(key) - 1); }
    else if (key === 'arrowleft' || key === 'arrowright') { event.preventDefault(); command('seek', (key === 'arrowleft' ? -1 : 1) * (event.shiftKey ? 0.1 : 1)); }
    else if (key === ',' || key === '.') { event.preventDefault(); command('frame-step', key === ',' ? -1 : 1); }
    else if (staged() && (key === 'arrowup' || key === 'arrowdown')) { event.preventDefault(); stepPart(key === 'arrowup' ? -1 : 1); }
  }

  const joystick = attachJoystick({
    pad: refs.stick,
    knob: refs.knob,
    start: framingState,
    change: liveView,
    preview: previewView,
    finish: (view, framing) => { liveView(normalizeView(view), framing); scheduleDraft(400); },
    nudge,
  });

  root.addEventListener('keydown', onKeydown);
  for (const type of ['keyup', 'keypress']) root.addEventListener(type, (event) => event.stopPropagation());

  root.addEventListener('pointerover', (event) => {
    const target = event.target.closest?.('[data-tip]');
    // A clicked button can move to the PiP window without a pointerout; any other element ends its silence.
    if (target !== tip.muted) tip.muted = null;
    if (!target || target === tip.target || target === tip.muted) return;
    // The video title only needs a tip when it is cut off.
    if (target.hasAttribute('data-tip-overflow') && target.scrollWidth <= target.clientWidth) return;
    showTip(target, performance.now() < tip.warmUntil ? 0 : 350);
  });
  root.addEventListener('pointerout', (event) => {
    const target = event.target.closest?.('[data-tip]');
    if (!target || target.contains(event.relatedTarget)) return;
    if (tip.muted === target) tip.muted = null;
    if (tip.target === target) hideTip();
  });
  // A click answers the question; the tip comes back only after the pointer leaves.
  root.addEventListener('pointerdown', (event) => {
    tip.muted = event.target.closest?.('[data-tip]') || null;
    if (tip.target) hideTip();
  });
  root.addEventListener('focusin', (event) => {
    const target = event.target.closest?.('[data-tip]');
    if (target?.matches(':focus-visible')) showTip(target, 0);
  });
  root.addEventListener('focusout', () => { if (tip.target) hideTip(); });

  root.addEventListener('click', (event) => {
    if (!event.isTrusted) return;
    const button = event.target.closest('button');
    if (!button || button.disabled) return;
    const data = button.dataset;
    if (data.share) shareLoop(data.share);
    if (data.cmd) command(data.cmd, data.value === undefined ? undefined : Number(data.value));
    if (data.part !== undefined) command('select-part', Number(data.part));
    if (data.nudge) {
      const fragment = fragmentOf(configuration());
      editPoint(data.nudge, Math.round((fragment[data.nudge] + Number(data.value)) * 100) / 100);
    }
    if (data.step) stepTempo(data.step, Number(data.value));
    if (data.reset) {
      const config = configuration();
      const target = data.reset === 'speed' ? 1 : 0;
      stepTempo(data.reset, target - (draft[data.reset] ?? (data.reset === 'speed' ? config.speed : config.gapSeconds)));
    }
    if (data.zoom) reframe({ zoom: (activeView(configuration())?.zoom ?? 1) + Number(data.zoom) });
    if (data.zoomReset !== undefined) reframe({ zoom: 1 });
    if (data.focus !== undefined) reframe({ focus: FOCUS_POINTS[data.focus] });
    if (data.pan) { const [x, y] = data.pan.split(',').map(Number); nudge({ x, y }); }
    switch (data.action) {
      case 'share': shareLoop(); break;
      case 'close': send({ type: 'OVERLAY_CLOSE' }); state.visible = false; render(); break;
      case 'collapse': setCollapsed(true); break;
      case 'expand': setCollapsed(false); break;
      case 'pip': togglePip(); break;
      case 'stage': toggleStage(); break;
      case 'part-step': stepPart(Number(data.value)); break;
      case 'reconnect': run({ type: 'OVERLAY_RECONNECT' }); break;
      case 'add-part': addPart(); break;
      case 'observe': toggleObserve(); break;
      case 'mirror': toggleMirror(); break;
      case 'center-view': reframe({ focus: { x: 0.5, y: 0.5 } }); break;
      case 'tools': setToolsOpen(!toolsOpen); savePrefs(); break;
      default: break;
    }
  });

  for (const input of pointInputs) input.addEventListener('change', () => editPoint(input.dataset.point, input.value));

  // Drag from the header or the collapsed pill.
  root.addEventListener('pointerdown', (event) => {
    const handle = event.target.closest('[data-drag]');
    if (!handle || pipWindow || event.button !== 0 || event.target.closest('button, input')) return;
    const rect = host.getBoundingClientRect();
    drag = { handle, id: event.pointerId, dx: event.clientX - rect.left, dy: event.clientY - rect.top };
    handle.setPointerCapture(event.pointerId);
    root.dataset.dragging = 'true';
    event.preventDefault();
  });
  root.addEventListener('pointermove', (event) => {
    if (drag?.id === event.pointerId) place(event.clientX - drag.dx, event.clientY - drag.dy);
  });
  const endDrag = (event) => {
    if (drag?.id !== event.pointerId) return;
    drag = null;
    root.dataset.dragging = 'false';
    savePrefs();
  };
  root.addEventListener('pointerup', endDrag);
  root.addEventListener('pointercancel', endDrag);

  // Scrubbing inside the loop bar seeks within A → B.
  const scrubTime = (event) => {
    const fragment = fragmentOf(configuration());
    const rect = refs.loopbar.getBoundingClientRect();
    const ratio = clamp((event.clientX - rect.left) / rect.width, 0, 1);
    return Math.round((fragment.start + ratio * (fragment.end - fragment.start)) * 100) / 100;
  };
  refs.loopbar.addEventListener('pointerdown', (event) => {
    if (!ready() || event.button !== 0) return;
    scrub = { id: event.pointerId, time: scrubTime(event) };
    refs.loopbar.setPointerCapture(event.pointerId);
    paintClock();
  });
  refs.loopbar.addEventListener('pointermove', (event) => {
    if (scrub?.id !== event.pointerId) return;
    scrub.time = scrubTime(event);
    paintClock();
  });
  const endScrub = (event) => {
    if (scrub?.id !== event.pointerId) return;
    const time = scrub.time;
    scrub = null;
    if (event.type === 'pointerup' && event.isTrusted) command('seek-to', time);
    startClock();
  };
  refs.loopbar.addEventListener('pointerup', endScrub);
  refs.loopbar.addEventListener('pointercancel', endScrub);

  const onResize = () => { if (state.visible) place(); };
  view().addEventListener('resize', onResize);
  // Players that go fullscreen inside this document keep the controller visible.
  const onFullscreen = () => {
    if (pipWindow) return;
    const target = documentRef.fullscreenElement;
    const parent = target && target.localName !== 'iframe' ? target : documentRef.documentElement;
    if (host.parentNode !== parent) { parent.append(host); adoptStyles(); }
    place();
  };
  documentRef.addEventListener('fullscreenchange', onFullscreen);
  documentRef.addEventListener('visibilitychange', () => { if (!documentRef.hidden) startClock(); });

  attach();

  return {
    host,
    update(next) {
      const wasVisible = state.visible;
      const { openTools, ...rest } = next;
      state = { ...state, ...rest };
      if (next.session !== undefined) stamp = performance.now();
      if (!next.visible) { draft = {}; partKey = ''; }
      if (!wasVisible && next.visible) frame = null;
      render();
      // The panel's practice tab asked for a tool: expand the controller on it.
      if (openTools && state.visible && toolsPanel) {
        root.dataset.collapsed = 'false';
        setToolsOpen(true, openTools);
        savePrefs();
      }
    },
    destroy() {
      unregisterHost();
      toolsPanel?.destroy();
      exitPip();
      view().removeEventListener('resize', onResize);
      documentRef.removeEventListener('fullscreenchange', onFullscreen);
      host.remove();
    },
  };
}
