// Interactive guitar neck drawn in SVG with DOM calls (no markup strings), so it works in extension
// pages and inside closed shadow roots on pages that enforce Trusted Types.
// Strings are numbered 0 (lowest) to 5 (highest); fret 0 is the open string, left of the nut.

const SVG = 'http://www.w3.org/2000/svg';
const FRET_WIDTH = 64;
const OPEN_WIDTH = 46;
const STRING_GAP = 30;
const TOP = 26;
const BOTTOM = 34;
const SIDE = 14;
// Column beside the nut with the open-string names.
const NAME_WIDTH = 18;
const DOT_RADIUS = 11.5;
const INLAYS = [3, 5, 7, 9, 15, 17, 19, 21];
const DOUBLE_INLAYS = [12, 24];

function node(documentRef, name, attributes = {}, parent = null) {
  const element = documentRef.createElementNS(SVG, name);
  for (const [key, value] of Object.entries(attributes)) if (value !== undefined && value !== null) element.setAttribute(key, String(value));
  parent?.append(element);
  return element;
}

// Readable text on any mark color (dark text on light fills, light text on dark fills).
export function inkFor(hex) {
  const value = /^#?([0-9a-f]{6})$/i.exec(hex || '')?.[1];
  if (!value) return null;
  const [r, g, b] = [0, 2, 4].map((index) => parseInt(value.slice(index, index + 2), 16) / 255).map((channel) => (channel <= 0.03928 ? channel / 12.92 : ((channel + 0.055) / 1.055) ** 2.4));
  return 0.2126 * r + 0.7152 * g + 0.0722 * b > 0.4 ? '#12160f' : '#ffffff';
}

/**
 * Geometry shared by drawing and hit-testing.
 * @param {{range: {from: number, to: number}, strings?: number, leftHanded?: boolean, highOnTop?: boolean, names?: boolean}} view
 */
export function fretboardGeometry({ range, strings = 6, leftHanded = false, highOnTop = true, names = false }) {
  const { from, to } = range;
  const open = from === 0;
  const lead = SIDE + (names ? NAME_WIDTH : 0);
  const nutX = lead + (open ? OPEN_WIDTH : 0);
  const firstWire = open ? 0 : from - 1;
  const width = nutX + (to - firstWire) * FRET_WIDTH + SIDE;
  const height = TOP + (strings - 1) * STRING_GAP + BOTTOM;
  const mirror = (x) => (leftHanded ? width - x : x);
  // x of the wire that closes fret n (wire 0 is the nut or the first visible wire).
  const wireX = (fret) => mirror(nutX + (fret - firstWire) * FRET_WIDTH);
  const cellX = (fret) => (fret === 0 ? mirror(lead + OPEN_WIDTH / 2) : mirror(nutX + (fret - firstWire - 0.5) * FRET_WIDTH));
  const stringY = (string) => TOP + (highOnTop ? strings - 1 - string : string) * STRING_GAP;
  const nameX = mirror(SIDE + NAME_WIDTH / 2 - 2);
  return { width, height, from, to, open, firstWire, strings, wireX, cellX, stringY, mirror, lead, nameX };
}

/**
 * @param {{documentRef?: Document, label?: string, onCell?: (cell: {string: number, fret: number}, event: Event) => void}} options
 */
export function createFretboard({ documentRef = document, label = 'Guitar neck', onCell = () => {} } = {}) {
  const svg = node(documentRef, 'svg', { class: 'fb', role: 'img', 'aria-label': label, tabindex: 0, focusable: 'true' });
  let model = null;
  let geometry = null;
  let cursor = null;
  // The cursor ring only shows while the neck is driven from the keyboard.
  let keyboard = false;

  function clear() {
    while (svg.firstChild) svg.firstChild.remove();
  }

  function drawNeck(g) {
    const { width, height, from, to, open, firstWire, strings, wireX, stringY, mirror, lead, nameX } = geometry;
    const top = stringY(geometry.strings - 1) < stringY(0) ? stringY(strings - 1) : stringY(0);
    const bottom = stringY(strings - 1) > stringY(0) ? stringY(strings - 1) : stringY(0);
    const neckLeft = Math.min(wireX(firstWire), wireX(to));
    node(documentRef, 'rect', { class: 'fb-wood', x: neckLeft, y: top - 10, width: Math.abs(wireX(to) - wireX(firstWire)), height: bottom - top + 20, rx: 4 }, g);
    for (const fret of [...INLAYS, ...DOUBLE_INLAYS]) {
      if (fret < Math.max(1, from) || fret > to) continue;
      const x = geometry.cellX(fret);
      const middle = (top + bottom) / 2;
      if (DOUBLE_INLAYS.includes(fret)) {
        node(documentRef, 'circle', { class: 'fb-inlay', cx: x, cy: middle - STRING_GAP, r: 3.5 }, g);
        node(documentRef, 'circle', { class: 'fb-inlay', cx: x, cy: middle + STRING_GAP, r: 3.5 }, g);
      } else {
        node(documentRef, 'circle', { class: 'fb-inlay', cx: x, cy: middle, r: 3.5 }, g);
      }
    }
    for (let fret = firstWire; fret <= to; fret++) {
      const nut = open && fret === 0;
      node(documentRef, 'line', { class: nut ? 'fb-nut' : 'fb-fret', x1: wireX(fret), x2: wireX(fret), y1: top - 10, y2: bottom + 10 }, g);
    }
    for (let string = 0; string < strings; string++) {
      const y = stringY(string);
      node(documentRef, 'line', { class: 'fb-string', x1: mirror(lead + (open ? OPEN_WIDTH * 0.35 : 0)), x2: mirror(width - SIDE), y1: y, y2: y, 'stroke-width': 1 + (strings - 1 - string) * 0.32 }, g);
      // Every string is named, so an open string outside the scale does not read as a missing note.
      if (model.stringNames?.[string]) node(documentRef, 'text', { class: 'fb-string-name', x: nameX, y: y + 0.5, 'text-anchor': 'middle', 'dominant-baseline': 'central' }, g).textContent = model.stringNames[string];
    }
    for (let fret = Math.max(from, 1); fret <= to; fret++) {
      const numbered = INLAYS.includes(fret) || DOUBLE_INLAYS.includes(fret) || fret === from || fret === 1;
      const text = node(documentRef, 'text', { class: numbered ? 'fb-number fb-number--marked' : 'fb-number', x: geometry.cellX(fret), y: height - 10, 'text-anchor': 'middle' }, g);
      text.textContent = String(fret);
    }
  }

  function drawLines(g) {
    for (const line of model.lines || []) {
      const start = { x: geometry.cellX(line.a.fret), y: geometry.stringY(line.a.string) };
      const end = { x: geometry.cellX(line.b.fret), y: geometry.stringY(line.b.string) };
      const link = node(documentRef, 'line', { class: 'fb-link', x1: start.x, y1: start.y, x2: end.x, y2: end.y }, g);
      if (line.color) link.style.setProperty('stroke', line.color);
    }
  }

  function drawDots(g) {
    for (const dot of model.dots || []) {
      if (dot.fret < geometry.from || dot.fret > geometry.to) continue;
      const group = node(documentRef, 'g', { class: `fb-dot fb-dot--${dot.kind || 'scale'}${dot.dim ? ' is-dim' : ''}${dot.ring ? ' has-ring' : ''}`, 'data-string': dot.string, 'data-fret': dot.fret, 'data-quality': dot.quality }, g);
      const x = geometry.cellX(dot.fret);
      const y = geometry.stringY(dot.string);
      const circle = node(documentRef, 'circle', { cx: x, cy: y, r: DOT_RADIUS }, group);
      if (dot.color) { circle.style.setProperty('fill', dot.color); circle.style.setProperty('stroke', dot.color); }
      if (dot.text) {
        const text = node(documentRef, 'text', { x, y: y + 0.5, 'text-anchor': 'middle', 'dominant-baseline': 'central', class: dot.text.length > 2 ? 'is-long' : '' }, group);
        if (dot.color && inkFor(dot.color)) text.style.setProperty('fill', inkFor(dot.color));
        text.textContent = dot.text;
      }
      if (dot.title) node(documentRef, 'title', {}, group).textContent = dot.title;
    }
  }

  function drawCells(g) {
    for (let string = 0; string < geometry.strings; string++) {
      for (let fret = geometry.from; fret <= geometry.to; fret++) {
        const cell = node(documentRef, 'g', { class: 'fb-cell', 'data-string': string, 'data-fret': fret }, g);
        const x = geometry.cellX(fret);
        const y = geometry.stringY(string);
        const width = fret === 0 ? OPEN_WIDTH : FRET_WIDTH;
        node(documentRef, 'rect', { class: 'fb-hit', x: x - width / 2, y: y - STRING_GAP / 2, width, height: STRING_GAP }, cell);
        node(documentRef, 'circle', { class: 'fb-ghost', cx: x, cy: y, r: DOT_RADIUS }, cell);
      }
    }
  }

  function drawCursor(g) {
    if (!cursor || !keyboard || !model.interactive) return;
    node(documentRef, 'circle', { class: 'fb-cursor', cx: geometry.cellX(cursor.fret), cy: geometry.stringY(cursor.string), r: DOT_RADIUS + 4 }, g);
  }

  function render(next) {
    model = next;
    geometry = fretboardGeometry({ range: model.range, strings: model.strings || 6, leftHanded: model.leftHanded, highOnTop: model.highOnTop !== false, names: Boolean(model.stringNames) });
    svg.setAttribute('viewBox', `0 0 ${geometry.width} ${geometry.height}`);
    // Pages size the neck from its natural width, so a short window of frets is not blown up.
    svg.style.setProperty('--fb-width', `${geometry.width}px`);
    svg.classList.toggle('is-interactive', Boolean(model.interactive));
    clear();
    const neck = node(documentRef, 'g', { class: 'fb-neck' }, svg);
    drawNeck(neck);
    if (model.interactive) drawCells(node(documentRef, 'g', { class: 'fb-cells' }, svg));
    drawLines(node(documentRef, 'g', { class: 'fb-links' }, svg));
    drawDots(node(documentRef, 'g', { class: 'fb-dots' }, svg));
    if (model.pending) node(documentRef, 'circle', { class: 'fb-pending', cx: geometry.cellX(model.pending.fret), cy: geometry.stringY(model.pending.string), r: DOT_RADIUS + 5 }, svg);
    drawCursor(svg);
  }

  // Clicks land on the invisible cell grid; dots and lines let them through (pointer-events in CSS).
  svg.addEventListener('click', (event) => {
    const cell = event.target.closest?.('.fb-cell');
    if (!cell || !model?.interactive) return;
    cursor = { string: Number(cell.dataset.string), fret: Number(cell.dataset.fret) };
    keyboard = false;
    onCell(cursor, event);
  });

  // Arrow keys move a cursor along the neck; Enter or Space acts on it.
  svg.addEventListener('keydown', (event) => {
    if (!model?.interactive) return;
    const highOnTop = model.highOnTop !== false;
    const moves = {
      ArrowLeft: [0, model.leftHanded ? 1 : -1], ArrowRight: [0, model.leftHanded ? -1 : 1],
      ArrowUp: [highOnTop ? 1 : -1, 0], ArrowDown: [highOnTop ? -1 : 1, 0],
    };
    if (moves[event.key]) {
      event.preventDefault();
      const [dString, dFret] = moves[event.key];
      cursor = cursor || { string: 5, fret: Math.max(geometry.from, Math.min(geometry.to, 5)) };
      cursor = { string: Math.min(geometry.strings - 1, Math.max(0, cursor.string + dString)), fret: Math.min(geometry.to, Math.max(geometry.from, cursor.fret + dFret)) };
      keyboard = true;
      render(model);
    } else if ((event.key === 'Enter' || event.key === ' ') && cursor) {
      event.preventDefault();
      onCell(cursor, event);
    }
  });

  return {
    element: svg,
    render,
    get geometry() { return geometry; },
  };
}
