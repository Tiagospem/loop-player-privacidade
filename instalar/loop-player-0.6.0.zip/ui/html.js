// Pages such as YouTube enforce Trusted Types; all markup set here is built from our own templates.
let policy;

export function setHTML(element, markup) {
  if (policy === undefined) {
    try { policy = globalThis.trustedTypes?.createPolicy?.('loop-player-overlay', { createHTML: (value) => value }) ?? null; }
    catch { policy = null; }
  }
  element.innerHTML = policy ? policy.createHTML(markup) : markup;
}

export function escapeHTML(value) {
  return String(value ?? '').replace(/[&<>"']/g, (character) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[character]);
}
