// One port per document to the service worker, shared by every tool panel in that document.
// Panels report which tools they show; the worker captures audio only while one is visible.
export function createToolsClient({ connect, send }) {
  const panels = new Set();
  let port = null;
  let state = null;
  let sentViews = '';
  let retryTimer = null;

  const views = () => [...new Set([...panels].flatMap((panel) => panel.views()))].sort();

  function receive(message) {
    if (message?.type === 'state') state = message;
    for (const panel of [...panels]) panel.receive(message);
  }

  function open() {
    if (port || !panels.size) return;
    try { port = connect(); } catch { port = null; return; }
    port.onMessage.addListener(receive);
    port.onDisconnect.addListener(() => {
      port = null;
      sentViews = '';
      // The worker restarts on demand; reconnect while a panel still needs it.
      clearTimeout(retryTimer);
      if (panels.size) retryTimer = setTimeout(refresh, 1000);
    });
  }

  function refresh() {
    open();
    const next = JSON.stringify(views());
    if (!port || next === sentViews) return;
    sentViews = next;
    try { port.postMessage({ type: 'views', views: JSON.parse(next) }); } catch { port = null; sentViews = ''; }
  }

  return {
    get state() { return state; },
    send,
    refresh,
    attach(panel) {
      panels.add(panel);
      open();
      if (state) panel.receive(state);
      refresh();
    },
    detach(panel) {
      panels.delete(panel);
      if (panels.size) { refresh(); return; }
      clearTimeout(retryTimer);
      try { port?.disconnect(); } catch { /* Already gone. */ }
      port = null;
      sentViews = '';
    },
    destroy() {
      panels.clear();
      clearTimeout(retryTimer);
      try { port?.disconnect(); } catch { /* Already gone. */ }
      port = null;
    },
  };
}
