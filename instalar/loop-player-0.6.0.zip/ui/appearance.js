// Applies the theme and accent to extension pages (<html>) and to every shadow host on lesson pages.
import { UI_PREFS_KEY, sanitizeUiPrefs } from '../lib/preferences.js';

const CACHE_KEY = 'lp-ui';
const hosts = new Set();
let current = null;

export function applyAppearance(element, prefs) {
  element.setAttribute('data-theme', prefs.theme);
  element.setAttribute('data-accent', prefs.accent);
}

// Hosts created later (tool windows, Picture-in-Picture bars) pick up the current choice immediately.
export function registerHost(host) {
  hosts.add(host);
  if (current) applyAppearance(host, current);
  return () => hosts.delete(host);
}

export function setAppearance(prefs) {
  current = sanitizeUiPrefs(prefs);
  for (const host of hosts) applyAppearance(host, current);
  for (const targetWindow of windows) targetWindow.document.documentElement.style.setProperty('background', themeBackground(targetWindow));
  return current;
}

const storage = () => globalThis.chrome?.storage?.local;

export async function loadUiPrefs() {
  if (!storage()) return sanitizeUiPrefs(readCache());
  try { return sanitizeUiPrefs((await storage().get(UI_PREFS_KEY))[UI_PREFS_KEY]); }
  catch { return sanitizeUiPrefs(readCache()); }
}

export async function saveUiPrefs(patch) {
  const next = sanitizeUiPrefs({...await loadUiPrefs(), ...patch});
  if (storage()) await storage().set({[UI_PREFS_KEY]: next});
  writeCache(next);
  return next;
}

export function watchUiPrefs(callback) {
  const listener = (changes, area) => {
    if (area === 'local' && changes[UI_PREFS_KEY]) callback(sanitizeUiPrefs(changes[UI_PREFS_KEY].newValue));
  };
  globalThis.chrome?.storage?.onChanged?.addListener(listener);
  return () => globalThis.chrome?.storage?.onChanged?.removeListener(listener);
}

// Extension pages keep a synchronous copy so ui/boot.js can paint the right theme before modules load.
export function writeCache(prefs, lang) {
  try { localStorage.setItem(CACHE_KEY, JSON.stringify({...prefs, ...(lang ? {lang} : {})})); } catch { /* Private contexts. */ }
}

function readCache() {
  try { return JSON.parse(localStorage.getItem(CACHE_KEY) || 'null'); } catch { return null; }
}

// Picture-in-Picture windows start blank; paint them with the theme's background and keep them in sync.
const windows = new Set();

export function themeBackground(targetWindow = globalThis) {
  const theme = current?.theme || 'dark';
  const light = theme === 'light' || (theme === 'auto' && targetWindow.matchMedia?.('(prefers-color-scheme: light)').matches);
  return light ? '#f4f5f0' : '#0d0f0c';
}

export function paintWindow(targetWindow) {
  windows.add(targetWindow);
  targetWindow.addEventListener?.('pagehide', () => windows.delete(targetWindow), {once: true});
  targetWindow.document.documentElement.style.setProperty('background', themeBackground(targetWindow));
}
