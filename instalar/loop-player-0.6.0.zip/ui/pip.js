// One Document Picture-in-Picture window per page. Chrome keeps a single one and opening another
// closes the first (video PiP included), so the practice controller and the tool windows share it:
// each joins as a tab (Controle | Afinador | Notas | Metrônomo | Braço) instead of replacing the others.
import { icon } from './icons.js';
import { registerHost, paintWindow } from './appearance.js';
import { setHTML, escapeHTML } from './html.js';
import { t } from '../lib/i18n.js';

const ORDER = ['practice', 'tuner', 'notes', 'metronome', 'fretboard'];
const REPLACE_CONFIRM_MS = 6000;

export function createPipHost({ css, documentRef = document }) {
  let pipWindow = null;
  let opening = null;
  let bar = null;
  let active = null;
  let replaceArmedUntil = 0;
  const entries = new Map();

  const ordered = () => [...entries.values()].sort((a, b) => ORDER.indexOf(a.id) - ORDER.indexOf(b.id));

  function hostStyle(element, properties) {
    for (const [name, value] of Object.entries(properties)) element.style.setProperty(name, value, 'important');
  }

  function createBar(pipDocument) {
    const host = pipDocument.createElement('loop-player-pip-tabs');
    const shadow = host.attachShadow({ mode: 'closed' });
    const sheet = new pipWindow.CSSStyleSheet();
    sheet.replaceSync(css);
    shadow.adoptedStyleSheets = [sheet];
    setHTML(shadow, `<nav class="lpp-tabs" role="tablist" aria-label="${escapeHTML(t('overlay.pip.tabs'))}"></nav>`);
    const nav = shadow.querySelector('nav');
    nav.addEventListener('click', (event) => {
      const button = event.target.closest('button[data-pip-tab]');
      if (button) select(button.dataset.pipTab);
    });
    registerHost(host);
    hostStyle(host, { display: 'none', position: 'sticky', top: '0', 'z-index': '2' });
    pipDocument.body.prepend(host);
    return { host, nav };
  }

  function renderBar() {
    if (!bar) return;
    const list = ordered();
    hostStyle(bar.host, { display: list.length > 1 ? 'block' : 'none' });
    setHTML(bar.nav, list.map((entry) => `<button class="lpp-tab" role="tab" data-pip-tab="${entry.id}" aria-selected="${entry.id === active}" title="${escapeHTML(entry.label)}">${icon(entry.icon, { size: 16 })}<span>${escapeHTML(entry.label)}</span></button>`).join(''));
    // Full-height layouts such as the stage mode leave room for the tabs.
    pipWindow.document.documentElement.style.setProperty('--lp-pip-bar', list.length > 1 ? `${Math.ceil(bar.host.getBoundingClientRect().height)}px` : '0px');
  }

  // A detached window grows to the shown tab when the browser allows it; otherwise it scrolls.
  function fit(entry) {
    if (!pipWindow || !entry) return;
    const needed = Math.ceil(entry.slot.getBoundingClientRect().height + (bar && entries.size > 1 ? bar.host.getBoundingClientRect().height : 0));
    const missing = needed - pipWindow.innerHeight;
    if (missing > 4) {
      try { pipWindow.resizeBy(0, missing); } catch { /* Needs a click in the window; scrolling still works. */ }
    }
  }

  function select(id) {
    if (!entries.has(id)) return;
    active = id;
    for (const entry of entries.values()) {
      hostStyle(entry.slot, { display: entry.id === id ? 'block' : 'none' });
      entry.onShow?.(entry.id === id);
    }
    renderBar();
    fit(entries.get(id));
  }

  async function open(size) {
    const view = documentRef.defaultView;
    const pictureInPicture = view.documentPictureInPicture;
    if (!pictureInPicture?.requestWindow) throw new Error(t('overlay.pip.unsupportedWindows'));
    // Our window would close the video's Picture-in-Picture: say so once before doing it.
    if (documentRef.pictureInPictureElement && Date.now() > replaceArmedUntil) {
      replaceArmedUntil = Date.now() + REPLACE_CONFIRM_MS;
      throw new Error(t('overlay.pip.replaceVideo'));
    }
    replaceArmedUntil = 0;
    pipWindow = await pictureInPicture.requestWindow(size);
    const pipDocument = pipWindow.document;
    pipDocument.title = 'Loop Player';
    paintWindow(pipWindow);
    pipDocument.body.style.setProperty('margin', '0');
    bar = createBar(pipDocument);
    pipWindow.addEventListener('pagehide', () => {
      const leaving = ordered();
      entries.clear();
      pipWindow = null;
      bar = null;
      active = null;
      for (const entry of leaving) entry.onLeave();
    }, { once: true });
  }

  return {
    get window() { return pipWindow; },
    has: (id) => entries.has(id),
    /**
     * Opens the window if needed and gives the entry a slot to move its host into. `onLeave` must
     * bring the host back to the page; it runs on leave() and when the window closes.
     */
    async enter({ id, label, icon: iconName, size, onLeave, onShow }) {
      if (!entries.has(id)) {
        if (!pipWindow) {
          opening ??= open(size).finally(() => { opening = null; });
          await opening;
        }
        const slot = pipWindow.document.createElement('div');
        slot.setAttribute('data-loop-player-pip-slot', id);
        pipWindow.document.body.append(slot);
        entries.set(id, { id, label, icon: iconName, slot, onLeave, onShow });
      }
      select(id);
      return { window: pipWindow, slot: entries.get(id).slot };
    },
    leave(id) {
      const entry = entries.get(id);
      if (!entry) return;
      entries.delete(id);
      entry.onLeave();
      entry.slot.remove();
      if (!entries.size) { pipWindow?.close(); return; }
      if (active === id) select(ordered()[0].id);
      else renderBar();
    },
    select,
    fit: (id) => fit(entries.get(id)),
  };
}
