// Floating fretboard window on a lesson page: the frame of the tool windows (drag, remembered position,
// minimize and the Picture-in-Picture window shared with the controller) around the fretboard board.
// Runs in a closed shadow root; markup comes from our own templates (pages may enforce Trusted Types).
import { registerHost } from './appearance.js';
import { mountFretboard, fretboardStorage } from './fretboard-board.js';
import { TOOL_HOST_TAG } from './tool-window.js';
import { t } from '../lib/i18n.js';
import { icon } from './icons.js';
import { setHTML, escapeHTML } from './html.js';

const MARGIN = 16;
const WINDOW_KEY = 'loopPlayer.fretboardFloat.v1';
const clamp = (value, minimum, maximum) => Math.min(Math.max(value, minimum), maximum);
const tx = (key, params) => escapeHTML(t(key, params));

function markup() {
  const button = (action, name, label, title = label, ref = '') => `<button class="icon-btn" data-action="${action}"${ref ? ` data-ref="${ref}"` : ''} aria-label="${tx(label)}" title="${tx(title)}">${icon(name, { size: 16 })}</button>`;
  return `
  <div class="lpo lpw lpw-fretboard" data-collapsed="false" data-pip="false" role="dialog" aria-label="${tx('fretboard.title')} · Loop Player">
    <div class="lpo-head" data-drag>
      <span class="lpo-grip" aria-hidden="true">${icon('grip', { size: 14 })}</span>
      <span class="lpo-logo" aria-hidden="true">${icon('fretboard', { size: 15 })}</span>
      <div class="lpo-heading"><strong class="lpo-title">${tx('fretboard.title')}</strong></div>
      <div class="lpo-head-actions">
        ${button('full', 'expand', 'fretboard.openFull', 'fretboard.openFullHint')}
        ${button('pip', 'pip', 'tools.window.popOut', 'tools.window.popOutTitle', 'pip')}
        ${button('collapse', 'chevronDown', 'tools.window.minimize')}
        <button class="icon-btn" data-action="close" aria-label="${tx('tools.window.close', { tool: t('fretboard.title') })}" title="${tx('tools.window.closeTitle')}">${icon('x', { size: 16 })}</button>
      </div>
    </div>
    <div class="lpo-body"><section data-ref="board"></section></div>
    <div class="lpo-mini" data-drag>
      <span class="lpo-logo" aria-hidden="true">${icon('fretboard', { size: 14 })}</span>
      <span class="lpw-fretboard-summary" data-ref="summary" aria-live="polite"></span>
      <button class="icon-btn" data-action="expand" aria-label="${tx('tools.window.expand', { tool: t('fretboard.title') })}" title="${tx('tools.window.expandTitle')}">${icon('chevronUp', { size: 16 })}</button>
    </div>
  </div>`;
}

/**
 * @param {{css: string, send: (message: object) => Promise<any>, documentRef?: Document, pip?: object}} options
 * `pip` is the page's shared Picture-in-Picture host (ui/pip.js).
 */
export async function createFretboardWindow({ css, send, documentRef = document, pip = null }) {
  const storage = fretboardStorage(true);
  const saved = (await storage.read(WINDOW_KEY)) || {};
  const host = documentRef.createElement(TOOL_HOST_TAG);
  host.setAttribute('data-loop-player-tool', 'fretboard');
  const unregisterHost = registerHost(host);
  const shadow = host.attachShadow({ mode: 'closed' });
  setHTML(shadow, markup());
  const root = shadow.querySelector('.lpo');
  const refs = Object.fromEntries([...shadow.querySelectorAll('[data-ref]')].map((element) => [element.dataset.ref, element]));
  root.tabIndex = -1;

  let position = { fx: clamp(Number(saved.position?.fx ?? 0.5), 0, 1), fy: clamp(Number(saved.position?.fy ?? 0.15), 0, 1) };
  let drag = null;
  let pipWindow = null;
  let destroyed = false;
  root.dataset.collapsed = String(saved.collapsed === true);
  const view = () => host.ownerDocument.defaultView;

  function adoptStyles() {
    const sheet = new (view().CSSStyleSheet)();
    sheet.replaceSync(css);
    shadow.adoptedStyleSheets = [sheet];
  }

  function hostStyle(properties) {
    for (const [name, value] of Object.entries(properties)) host.style.setProperty(name, value, 'important');
  }

  function place(x, y) {
    if (pipWindow) return;
    const rect = root.getBoundingClientRect();
    const width = documentRef.documentElement.clientWidth || view().innerWidth;
    const height = view().innerHeight;
    const maxX = Math.max(MARGIN, width - rect.width - MARGIN);
    const maxY = Math.max(MARGIN, height - rect.height - MARGIN);
    const left = clamp(x ?? MARGIN + position.fx * (maxX - MARGIN), MARGIN, maxX);
    const top = clamp(y ?? MARGIN + position.fy * (maxY - MARGIN), MARGIN, maxY);
    if (x !== undefined) position = { fx: maxX > MARGIN ? (left - MARGIN) / (maxX - MARGIN) : 0, fy: maxY > MARGIN ? (top - MARGIN) / (maxY - MARGIN) : 0 };
    hostStyle({ left: `${Math.round(left)}px`, top: `${Math.round(top)}px` });
  }

  const savePrefs = () => storage.write(WINDOW_KEY, { position, collapsed: root.dataset.collapsed === 'true' });

  // The minimized pill names the scale or the open diagram.
  let app = null;
  app = await mountFretboard({
    board: refs.board,
    isExtension: true,
    layout: 'window',
    onRender: () => { if (app) refs.summary.textContent = app.summary(); },
  });
  refs.summary.textContent = app.summary();

  function setCollapsed(collapsed) {
    root.dataset.collapsed = String(collapsed);
    place();
    root.focus({ preventScroll: true });
    savePrefs();
  }

  // Keys typed in the window never reach the page or its player shortcuts.
  const onKeydown = (event) => event.stopPropagation();

  function returnToPage() {
    pipWindow = null;
    root.dataset.pip = 'false';
    if (destroyed) return;
    documentRef.documentElement.append(host);
    host.style.removeProperty('width');
    hostStyle({ position: 'fixed' });
    adoptStyles();
    setHTML(refs.pip, icon('pip', { size: 16 }));
    refs.pip.title = t('tools.window.popOutTitle');
    refs.pip.setAttribute('aria-label', t('tools.window.popOut'));
    place();
  }

  function exitPip() {
    if (!pipWindow) return;
    if (pip) pip.leave('fretboard');
    else pipWindow.close();
  }

  async function togglePip() {
    if (pipWindow) { exitPip(); return; }
    const size = { width: 1000, height: Math.min(720, Math.max(420, Math.round(root.getBoundingClientRect().height) + 8)) };
    let slot;
    try {
      if (!pip) throw new Error(t('tools.window.pipUnsupported'));
      ({ window: pipWindow, slot } = await pip.enter({ id: 'fretboard', label: t('fretboard.title'), icon: 'fretboard', size, onLeave: returnToPage }));
    } catch (error) {
      pipWindow = null;
      app.toast(error.message, { tone: 'danger' });
      return;
    }
    root.dataset.collapsed = 'false';
    root.dataset.pip = 'true';
    slot.append(host);
    hostStyle({ position: 'static', display: 'block', left: 'auto', top: 'auto', width: '100%' });
    adoptStyles();
    setHTML(refs.pip, icon('pipExit', { size: 16 }));
    refs.pip.title = t('tools.window.popIn');
    refs.pip.setAttribute('aria-label', t('tools.window.popIn'));
    pipWindow.document.addEventListener('keydown', onKeydown);
  }

  function close() {
    exitPip();
    hostStyle({ display: 'none' });
    send({ type: 'FRETBOARD_WINDOW', close: true });
  }

  root.addEventListener('keydown', onKeydown);
  for (const type of ['keyup', 'keypress']) root.addEventListener(type, (event) => event.stopPropagation());
  root.addEventListener('click', async (event) => {
    if (!event.isTrusted) return;
    const button = event.target.closest('button[data-action]');
    if (!button || button.disabled || !button.closest('.lpo-head, .lpo-mini')) return;
    switch (button.dataset.action) {
      case 'close': close(); break;
      case 'collapse': setCollapsed(true); break;
      case 'expand': setCollapsed(false); break;
      case 'pip': togglePip(); break;
      // The tab continues from the same state; this window steps aside.
      case 'full': if ((await send({ type: 'OPEN_FRETBOARD', layout: 'tab' }))?.ok) close(); break;
      default: break;
    }
  });

  root.addEventListener('pointerdown', (event) => {
    const handle = event.target.closest('[data-drag]');
    if (!handle || pipWindow || event.button !== 0 || event.target.closest('button, input, select')) return;
    const rect = host.getBoundingClientRect();
    drag = { id: event.pointerId, dx: event.clientX - rect.left, dy: event.clientY - rect.top };
    handle.setPointerCapture(event.pointerId);
    root.dataset.dragging = 'true';
    event.preventDefault();
  });
  root.addEventListener('pointermove', (event) => {
    if (drag?.id === event.pointerId) place(event.clientX - drag.dx, event.clientY - drag.dy);
  });
  const endDrag = (event) => {
    if (drag?.id !== event.pointerId) return;
    drag = null;
    root.dataset.dragging = 'false';
    savePrefs();
  };
  root.addEventListener('pointerup', endDrag);
  root.addEventListener('pointercancel', endDrag);

  const pageView = documentRef.defaultView;
  const onResize = () => place();
  pageView.addEventListener('resize', onResize);
  const onFullscreen = () => {
    if (pipWindow) return;
    const target = documentRef.fullscreenElement;
    const parent = target && target.localName !== 'iframe' ? target : documentRef.documentElement;
    if (host.parentNode !== parent) { parent.append(host); adoptStyles(); }
    place();
  };
  documentRef.addEventListener('fullscreenchange', onFullscreen);

  adoptStyles();
  hostStyle({ position: 'fixed', 'z-index': '2147483647', left: '0px', top: '0px', margin: '0', display: 'block' });
  documentRef.documentElement.append(host);
  place();
  root.focus({ preventScroll: true });

  return {
    host,
    destroy() {
      unregisterHost();
      destroyed = true;
      exitPip();
      pageView.removeEventListener('resize', onResize);
      documentRef.removeEventListener('fullscreenchange', onFullscreen);
      host.remove();
    },
  };
}
