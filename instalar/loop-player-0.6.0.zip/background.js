import {encodeShareCode, mergeSharedConfiguration, sanitizeSharedVideos} from './lib/share.js';
import {extractYouTubeVideoId, youtubeUrl, defaultConfiguration, normalizeConfiguration, normalizeEntry, normalizeView, sanitizeLibrary, upsertVideo, effectiveBpm, MAX_LIBRARY_ENTRIES} from './lib/core.js';
import {TOOL_IDS, CAPTURE_VIEWS, defaultToolPrefs, sanitizeToolPrefs, sanitizeViews, sanitizeReading, sanitizeBeat, sanitizeEngineStatus, sanitizeCountIn} from './lib/tools.js';
import {t, applyLocaleChoice, videoTitle} from './lib/i18n.js';
import {UI_PREFS_KEY, sanitizeUiPrefs} from './lib/preferences.js';
import {createBackup, parseBackup, mergeLibrary, addRestorePoint, createRestorePoint, restorePointInfo, sanitizeRestorePoints, RESTORE_POINT_LIMIT} from './lib/backup.js';
import {sanitizeTrash, moveToTrash, takeFromTrash, trashExpiresAt} from './lib/trash.js';
import {MAX_DIAGRAMS, mergeDiagrams, sanitizeDiagrams, saveDiagram} from './lib/diagrams.js';
import {folderErrorState, folderPermission, forgetFolderHandle, loadFolderHandle, writeBackupFolder} from './lib/backup-writer.js';

const LIBRARY_KEY = 'loopPlayer.library.v1';
const REPORTS_KEY = 'loopPlayer.reports.v1';
const SESSION_KEY = 'loopPlayer.session.v1';
const SHORTCUTS_KEY = 'loopPlayer.pageShortcuts.v1';
const OVERLAY_KEY = 'loopPlayer.overlay.v1';
const OVERLAY_TAB_KEY = 'loopPlayer.overlayTab.v1';
const TRASH_KEY = 'loopPlayer.trash.v1';
const RESTORE_POINTS_KEY = 'loopPlayer.restorePoints.v1';
const FOLDER_KEY = 'loopPlayer.backupFolder.v1';
const DIAGRAMS_KEY = 'loopPlayer.diagrams.v1';
const FRETBOARD_WINDOW_KEY = 'loopPlayer.fretboardWindow.v1';
// What the floating fretboard window on a page may ask for (saved diagrams are still validated here).
const FRETBOARD_MESSAGES = ['GET_DIAGRAMS', 'SAVE_DIAGRAM', 'DELETE_DIAGRAM', 'IMPORT_DIAGRAMS', 'OPEN_FRETBOARD', 'FRETBOARD_WINDOW'];
// The fretboard window reopens with its last size and place, kept within reasonable limits.
const fretboardBounds = (saved) => {
  const size = (value, min, max, fallback) => (Number.isInteger(value) ? Math.min(max, Math.max(min, value)) : fallback);
  return {
    width: size(saved?.width, 640, 2400, 1040),
    height: size(saved?.height, 420, 1600, 720),
    ...(Number.isInteger(saved?.left) && Number.isInteger(saved?.top) ? {left: saved.left, top: saved.top} : {}),
  };
};
// Changes reach the backup folder in one write a few seconds after the last one.
const FOLDER_BACKUP_DELAY_MS = 3000;
const TOOLS_KEY = 'loopPlayer.tools.v1';
const TOOLS_STATE_KEY = 'loopPlayer.toolsState.v1';
let pageShortcuts = false;
const shortcutScopes = new Map();
const PENDING_KEY = 'loopPlayer.pending.v1';
const OVERLAY_COMMANDS = ['toggle-play', 'capture-a', 'capture-b', 'toggle-loop', 'restart', 'seek', 'seek-to', 'select-part', 'frame-step'];
let overlayPrefs = {autoShow: true, position: null, collapsed: false, observe: false, stage: false, tools: {open: false, tab: 'tuner'}};
// Tab whose top frame shows the floating controller, or null.
let overlayTab = null;
const uiPorts = new Set();
let notifiedKey = '';
let persistTimer = null;
let library = [];
let trash = [];
let restorePoints = [];
let diagrams = [];
let folderStatus = {state: 'none', name: '', lastBackupAt: 0, error: '', pending: false};
let folderTimer = null;
let folderRun = null;
let folderChanges = 0;
let reports = {};
let session = null;
let pending = null;
let pendingConnecting = false;
const scanTimes = new Map();
const scanWork = new Map();
const scanErrors = new Map();
const recoveryWork = new Map();
let storageQueue = Promise.resolve();
let sessionQueue = Promise.resolve();
const frameKey = (tabId, frameId) => `${tabId}:${frameId}`;
const safePage = (value) => {
  try { const url = new URL(value); return /^https?:$/.test(url.protocol) && !url.username && !url.password ? url.href : null; } catch { return null; }
};
const readId = (value) => extractYouTubeVideoId(value) || extractYouTubeVideoId(`https://youtu.be/${value || ''}`);
const userError = (message) => { throw new Error(message); };

// Tuner, Notes and Metronome: one offscreen audio engine serves every window that shows a tool.
const ENGINE_URL = 'offscreen.html';
// Stopping waits a moment: switching tool tabs or a restarted worker reconnects within it.
const ENGINE_GRACE_MS = 1500;
const ENGINE_IDLE_MS = 20000;
let toolPrefs = defaultToolPrefs();
// Tab whose top frame shows each standalone tool window, or null.
let toolWindows = Object.fromEntries(TOOL_IDS.map((tool) => [tool, null]));
// Extension windows used where a page cannot host a tool window.
let toolPopups = {};
let metronomeOn = false;
// Tab whose top frame shows the floating fretboard window, or null.
let fretboardTab = null;
let tunerVisible = false;
let practiceToolsRequest = null;
const toolClients = new Map();
let enginePort = null;
let engineWaiters = [];
let engineCreating = null;
let engineStatus = sanitizeEngineStatus({});
let engineLast;
let engineSent = '';
let engineQueue = Promise.resolve();
let engineGraceTimer = null;
let engineIdleTimer = null;
let metronomeStopTimer = null;
let toolsBroadcastKey = '';

const ready = (async () => {
  const [local, ephemeral] = await Promise.all([
    chrome.storage.local.get([LIBRARY_KEY, SHORTCUTS_KEY, OVERLAY_KEY, TOOLS_KEY, UI_PREFS_KEY, TRASH_KEY, RESTORE_POINTS_KEY, FOLDER_KEY, DIAGRAMS_KEY]),
    chrome.storage.session.get([REPORTS_KEY, SESSION_KEY, PENDING_KEY, OVERLAY_TAB_KEY, TOOLS_STATE_KEY]),
  ]);
  // Messages and toolbar titles follow the language chosen in Settings (or the browser's).
  applyLocaleChoice(sanitizeUiPrefs(local[UI_PREFS_KEY]).locale);
  library = sanitizeLibrary(local[LIBRARY_KEY]);
  trash = sanitizeTrash(local[TRASH_KEY], Date.now());
  restorePoints = sanitizeRestorePoints(local[RESTORE_POINTS_KEY]);
  diagrams = sanitizeDiagrams(local[DIAGRAMS_KEY]);
  folderStatus = sanitizeFolderStatus(local[FOLDER_KEY]);
  pageShortcuts = local[SHORTCUTS_KEY] === true;
  overlayPrefs = sanitizeOverlayPrefs(local[OVERLAY_KEY]);
  reports = ephemeral[REPORTS_KEY] || {};
  session = ephemeral[SESSION_KEY] || null;
  pending = ephemeral[PENDING_KEY] || null;
  overlayTab = Number.isInteger(ephemeral[OVERLAY_TAB_KEY]) ? ephemeral[OVERLAY_TAB_KEY] : null;
  toolPrefs = sanitizeToolPrefs(local[TOOLS_KEY]);
  const tools = ephemeral[TOOLS_STATE_KEY] || {};
  for (const tool of TOOL_IDS) {
    toolWindows[tool] = Number.isInteger(tools.windows?.[tool]) ? tools.windows[tool] : null;
    if (Number.isInteger(tools.popups?.[tool])) toolPopups[tool] = tools.popups[tool];
  }
  metronomeOn = tools.metronomeOn === true;
  fretboardTab = Number.isInteger(tools.fretboard) ? tools.fretboard : null;
  // A backup the worker could not finish before it stopped is tried again.
  if (folderStatus.pending) scheduleFolderBackup();
})();

chrome.storage.onChanged?.addListener((changes, area) => {
  if (area !== 'local' || !changes[UI_PREFS_KEY]) return;
  applyLocaleChoice(sanitizeUiPrefs(changes[UI_PREFS_KEY].newValue).locale);
  // Toolbar titles and the practiced video's title already on screen follow the new language.
  ready.then(() => {
    notify();
    return Promise.all([...new Set(Object.values(reports).map((report) => report.tabId))].map(refreshAction));
  }).catch(() => {});
});

function writeEphemeral() {
  const snapshot = {[REPORTS_KEY]: structuredClone(reports), [SESSION_KEY]: structuredClone(session), [PENDING_KEY]: structuredClone(pending), [OVERLAY_TAB_KEY]: overlayTab};
  sessionQueue = sessionQueue.catch(() => {}).then(() => chrome.storage.session.set(snapshot));
  return sessionQueue;
}

// Live player state arrives several times per second; its snapshot only needs to survive a worker restart.
function persistEphemeral({deferred = false} = {}) {
  notify();
  if (deferred) {
    persistTimer ??= setTimeout(() => { persistTimer = null; writeEphemeral().catch(() => {}); }, 1000);
    return Promise.resolve();
  }
  clearTimeout(persistTimer);
  persistTimer = null;
  return writeEphemeral();
}

function sanitizeOverlayPrefs(value) {
  const unit = (number) => Math.min(1, Math.max(0, number));
  const position = value?.position;
  return {
    autoShow: value?.autoShow !== false,
    position: Number.isFinite(position?.fx) && Number.isFinite(position?.fy) ? {fx: unit(position.fx), fy: unit(position.fy)} : null,
    collapsed: value?.collapsed === true,
    observe: value?.observe === true,
    stage: value?.stage === true,
    tools: {open: value?.tools?.open === true, tab: TOOL_IDS.includes(value?.tools?.tab) ? value.tools.tab : 'tuner'},
  };
}

function overlayInfo() {
  return {visible: overlayTab !== null && session?.tabId === overlayTab, autoShow: overlayPrefs.autoShow, stage: overlayPrefs.stage};
}

function sessionTitle() {
  if (!session) return '';
  const entry = library.find((item) => item.videoId === session.videoId);
  // Stored placeholders ("Vídeo <id>") are shown in the current language.
  if (entry) return videoTitle(entry.title, entry.videoId);
  const candidate = allCandidates(session.tabId).find((item) => item.videoId === session.videoId && !/^Vídeo [\w-]{11}$/.test(item.title));
  return videoTitle(candidate?.title, session.videoId);
}

function overlayMessage() {
  const visible = overlayInfo().visible;
  return {type: 'LPO_STATE', visible, session: visible ? session : null, title: visible ? sessionTitle() : '', prefs: {position: overlayPrefs.position, collapsed: overlayPrefs.collapsed, observe: overlayPrefs.observe, stage: overlayPrefs.stage, tools: overlayPrefs.tools}, ...(visible && practiceToolsRequest ? {openTools: practiceToolsRequest} : {})};
}

async function pushOverlay(tabId = overlayTab, inject = false) {
  if (!Number.isInteger(tabId)) return false;
  const message = tabId === overlayTab ? overlayMessage() : {type: 'LPO_STATE', visible: false, session: null};
  const deliver = async () => {
    try { return await chrome.tabs.sendMessage(tabId, message, {frameId: 0}); } catch { return null; }
  };
  let reply = await deliver();
  if (!reply?.ok && inject) {
    try { await chrome.scripting.executeScript({target: {tabId, frameIds: [0]}, files: ['overlay.js']}); } catch { return false; }
    reply = await deliver();
  }
  if (reply?.ok && message.openTools) practiceToolsRequest = null;
  return !!reply?.ok;
}

// Moves the floating controller to tabId (or hides it with null).
async function setOverlayTab(tabId) {
  const previous = overlayTab;
  overlayTab = Number.isInteger(tabId) ? tabId : null;
  if (previous !== null && previous !== overlayTab) await pushOverlay(previous);
  let shown = true;
  if (overlayTab !== null) {
    shown = await pushOverlay(overlayTab, true);
    if (!shown) overlayTab = null;
  }
  await persistEphemeral();
  return shown;
}

// Keeps the controller following the selected session.
async function presentOverlay(tabId, isNewSelection) {
  if (overlayTab === tabId) return pushOverlay(tabId, true);
  if (overlayTab !== null || (isNewSelection && overlayPrefs.autoShow)) return setOverlayTab(tabId);
  return false;
}

function notify() {
  const key = JSON.stringify([session, overlayTab, overlayPrefs.autoShow, overlayPrefs.stage, session ? sessionTitle() : '']);
  if (key === notifiedKey) return;
  notifiedKey = key;
  const message = {type: 'SESSION', session, overlay: overlayInfo()};
  for (const port of uiPorts) {
    try { port.postMessage(message); } catch { uiPorts.delete(port); }
  }
  if (overlayTab !== null) pushOverlay().catch(() => {});
  syncTools();
}

// Library, fretboard diagrams, trash and restore points are written together, so an import and its
// restore point land at once.
function modifyData(callback) {
  const task = storageQueue.catch(() => {}).then(async () => {
    const next = callback({library, trash, restorePoints, diagrams});
    const values = {};
    if (next.library) values[LIBRARY_KEY] = sanitizeLibrary(next.library);
    if (next.diagrams) values[DIAGRAMS_KEY] = sanitizeDiagrams(next.diagrams);
    if (next.trash) values[TRASH_KEY] = next.trash;
    if (next.restorePoints) values[RESTORE_POINTS_KEY] = next.restorePoints;
    if (!Object.keys(values).length) return;
    await chrome.storage.local.set(values);
    if (values[LIBRARY_KEY]) library = values[LIBRARY_KEY];
    if (values[DIAGRAMS_KEY]) diagrams = values[DIAGRAMS_KEY];
    if (next.trash) trash = next.trash;
    if (next.restorePoints) restorePoints = next.restorePoints;
    if (values[LIBRARY_KEY] || values[DIAGRAMS_KEY]) scheduleFolderBackup();
  });
  storageQueue = task;
  return task;
}

function modifyLibrary(callback) {
  return modifyData((state) => ({library: callback(state.library)})).then(() => library);
}

const currentPreferences = () => ({pageShortcuts, overlay: overlayPrefs, tools: toolPrefs});

// Saves a change together with a restore point of the data before it. When storage is short, older
// points give way; without room for even one, nothing changes.
async function modifyWithRestorePoint(reason, callback) {
  let point;
  const attempt = (older) => modifyData((state) => {
    point = createRestorePoint({reason, library: state.library, trash: state.trash, diagrams: state.diagrams, preferences: currentPreferences(), createdAt: Date.now()});
    return {...callback(state), restorePoints: addRestorePoint(state.restorePoints.slice(0, older), point)};
  });
  try {
    await attempt(RESTORE_POINT_LIMIT - 1);
  } catch (error) {
    if (!/quota/i.test(String(error?.message))) throw error;
    try { await attempt(0); } catch (retry) {
      if (/quota/i.test(String(retry?.message))) userError(t('backup.error.quota'));
      throw retry;
    }
  }
  return point;
}

async function applyPreferences(preferences) {
  overlayPrefs = sanitizeOverlayPrefs(preferences.overlay);
  pageShortcuts = preferences.pageShortcuts === true;
  // The microphone or interface chosen here stays: device IDs do not travel between computers.
  if (preferences.tools) toolPrefs = sanitizeToolPrefs({...preferences.tools, input: toolPrefs.input}, toolPrefs);
  await chrome.storage.local.set({[OVERLAY_KEY]: overlayPrefs, [SHORTCUTS_KEY]: pageShortcuts, [TOOLS_KEY]: toolPrefs});
  await syncShortcutScopes();
  if (preferences.tools) syncTools();
  scheduleFolderBackup();
}

// The practiced video plays the saved fragments now instead of overwriting them on its next change.
async function syncSessionConfiguration() {
  const entry = session && library.find((item) => item.videoId === session.videoId);
  if (!entry || JSON.stringify(entry.configuration) === JSON.stringify(normalizeConfiguration(session.configuration))) return;
  const applied = session.error ? null : await sendToSession({type: 'LP_SET_CONFIG', configuration: entry.configuration}).catch(() => null);
  if (!applied?.ok) { session = {...session, configuration: entry.configuration}; await persistEphemeral(); }
}

function purgeTrash() {
  const now = Date.now();
  if (!trash.some((item) => trashExpiresAt(item) <= now)) return Promise.resolve();
  return modifyData((state) => ({trash: sanitizeTrash(state.trash, now)}));
}

function sanitizeFolderStatus(value) {
  const states = ['none', 'ok', 'needs-permission', 'unavailable', 'error'];
  return {
    state: states.includes(value?.state) ? value.state : 'none',
    name: typeof value?.name === 'string' ? value.name.slice(0, 200) : '',
    lastBackupAt: Number.isSafeInteger(value?.lastBackupAt) ? value.lastBackupAt : 0,
    error: typeof value?.error === 'string' ? value.error.slice(0, 300) : '',
    pending: value?.pending === true,
  };
}

async function setFolderStatus(next) {
  folderStatus = sanitizeFolderStatus({...folderStatus, ...next});
  await chrome.storage.local.set({[FOLDER_KEY]: folderStatus}).catch(() => {});
}

// Library or preference changes reach the chosen folder a few seconds later, in one write.
function scheduleFolderBackup() {
  if (folderStatus.state === 'none') return;
  folderChanges++;
  if (!folderStatus.pending) setFolderStatus({pending: true});
  clearTimeout(folderTimer);
  folderTimer = setTimeout(() => { folderTimer = null; runFolderBackup().catch(() => {}); }, FOLDER_BACKUP_DELAY_MS);
}

// Writes the backup folder now. Without a granted permission (Chrome drops it when the last extension
// page closes, unless the person allowed it on every visit) the write waits for a re-authorization.
function runFolderBackup() {
  folderRun ??= (async () => {
    const changes = folderChanges;
    let directory;
    try {
      directory = await loadFolderHandle();
    } catch (error) {
      await setFolderStatus({state: 'error', error: t('backup.error.readFolder', {error: error?.message || error}), pending: true});
      return;
    }
    if (!directory) {
      await setFolderStatus({state: 'none', name: '', error: '', pending: false});
      return;
    }
    try {
      if (await folderPermission(directory) !== 'granted') {
        await setFolderStatus({state: 'needs-permission', name: directory.name, pending: true});
        return;
      }
      await storageQueue.catch(() => {});
      const backup = createBackup({library, diagrams, preferences: currentPreferences(), appVersion: chrome.runtime.getManifest?.().version, exportedAt: Date.now()});
      await writeBackupFolder(directory, backup, {now: Date.now()});
      await setFolderStatus({state: 'ok', name: directory.name, lastBackupAt: Date.now(), error: '', pending: folderChanges !== changes});
    } catch (error) {
      await setFolderStatus({state: folderErrorState(error), name: directory.name, error: String(error?.message || error), pending: true});
    }
  })().finally(() => { folderRun = null; });
  return folderRun;
}

function frameUrlMatches(source, actual) {
  if (source === actual) return true;
  const sourceVideo = extractYouTubeVideoId(source);
  const actualVideo = extractYouTubeVideoId(actual);
  if (sourceVideo || actualVideo) return !!sourceVideo && sourceVideo === actualVideo;
  try {
    const original = new URL(source);
    const loaded = new URL(actual);
    // Token/SPA query changes preserve a wrapper's visible document route.
    return /^https?:$/.test(original.protocol) && original.origin === loaded.origin && original.pathname === loaded.pathname;
  } catch { return false; }
}

function frameIsRendered(report, visited = new Set()) {
  if (report.frameId === 0) return true;
  const key = frameKey(report.tabId, report.frameId);
  if (visited.has(key)) return false;
  visited.add(key);
  const parent = reports[frameKey(report.tabId, report.parentFrameId ?? 0)];
  const visible = (parent?.visibleFrameUrls || []).some((url) => frameUrlMatches(url, report.pageUrl));
  return !!parent && visible && frameIsRendered(parent, visited);
}

function allCandidates(tabId) {
  const result = [];
  for (const report of Object.values(reports)) {
    if (report.tabId !== tabId || !frameIsRendered(report)) continue;
    for (const candidate of report.candidates) {
      result.push({...candidate, frameId: report.frameId, pageUrl: reports[frameKey(tabId, 0)]?.pageUrl || report.pageUrl, directPlayer: extractYouTubeVideoId(report.pageUrl) === candidate.videoId});
    }
  }
  return result.sort((a, b) => (b.directPlayer ? 2 : b.kind === 'player' ? 1 : 0) - (a.directPlayer ? 2 : a.kind === 'player' ? 1 : 0));
}

function candidateList(tabId) {
  const unique = new Map();
  for (const candidate of allCandidates(tabId)) {
    if (!unique.has(candidate.videoId)) { const {directPlayer, ...publicCandidate} = candidate; unique.set(candidate.videoId, publicCandidate); }
  }
  return [...unique.values()];
}

async function refreshAction(tabId) {
  const count = new Set(candidateList(tabId).map((candidate) => candidate.videoId)).size;
  const state = count ? 'active' : 'idle';
  try {
    await Promise.all([
      chrome.action.setIcon({tabId, path: Object.fromEntries([16, 32, 48, 128].map((size) => [size, `assets/icon-${state}-${size}.png`]))}),
      chrome.action.setBadgeText({tabId, text: count ? String(count) : ''}),
      chrome.action.setBadgeBackgroundColor({tabId, color: '#267a56'}),
      chrome.action.setTitle({tabId, title: count ? t('runtime.action.found', {count}) : t('runtime.action.none')}),
    ]);
  } catch { /* A closed tab no longer has a toolbar action. */ }
}

function normalizeCandidates(values) {
  const found = new Map();
  for (const raw of Array.isArray(values) ? values : []) {
    const videoId = readId(raw?.videoId || raw?.youtubeUrl);
    if (!videoId) continue;
    const candidate = {videoId, title: String(raw.title || `Vídeo ${videoId}`).slice(0, 200), youtubeUrl: youtubeUrl(videoId), kind: raw.kind === 'player' ? 'player' : 'link'};
    if (!found.has(videoId) || candidate.kind === 'player') found.set(videoId, candidate);
  }
  return [...found.values()].slice(0, 500);
}

function normalizeFrameUrls(values) {
  return [...new Set((Array.isArray(values) ? values : []).map((url) => safePage(url) || (['about:blank', 'about:srcdoc'].includes(url) ? url : null)).filter(Boolean))];
}

async function acceptReport(tabId, frameId, candidates, pageUrl, visibleFrameUrls) {
  const key = frameKey(tabId, frameId);
  let parentFrameId = reports[key]?.parentFrameId;
  if (frameId > 0 && parentFrameId === undefined) {
    try { parentFrameId = (await chrome.webNavigation.getFrame({tabId, frameId}))?.parentFrameId ?? 0; } catch { parentFrameId = 0; }
  }
  reports[key] = {tabId, frameId, parentFrameId, candidates: normalizeCandidates(candidates), pageUrl: safePage(pageUrl) || (['about:blank', 'about:srcdoc'].includes(pageUrl) ? pageUrl : null), visibleFrameUrls: normalizeFrameUrls(visibleFrameUrls), updatedAt: Date.now()};
  if (frameId === 0) scanErrors.delete(tabId);
  await persistEphemeral();
  await refreshAction(tabId);
}

async function activeTab(tabId) {
  if (Number.isInteger(tabId)) {
    try { return await chrome.tabs.get(tabId); } catch { return null; }
  }
  const tabs = await chrome.tabs.query({active: true, currentWindow: true});
  return tabs[0] || null;
}

async function sendFrame(tabId, frameId, message) {
  try { return await chrome.tabs.sendMessage(tabId, message, {frameId}); }
  catch { return {ok: false, error: t('runtime.player.unavailable')}; }
}

function pageAccessError(tab) {
  if (!tab) return t('runtime.page.noTab');
  if (!safePage(tab.url)) return t('runtime.page.protected');
  try {
    const url = new URL(tab.url);
    if (url.hostname === 'chromewebstore.google.com' || url.hostname === 'chrome.google.com' && url.pathname.startsWith('/webstore')) {
      return t('runtime.page.webStore');
    }
  } catch { /* The general permission message below covers malformed URLs. */ }
  return t('runtime.page.denied');
}

async function scanFrame(tabId, frameId) {
  let result = await sendFrame(tabId, frameId, {type: 'LP_SCAN'});
  if (result?.ok) return result;
  try {
    // Tabs opened before installation do not receive declarative content scripts.
    await chrome.scripting.executeScript({target: {tabId, frameIds: [frameId]}, files: ['content.js']});
    result = await sendFrame(tabId, frameId, {type: 'LP_SCAN'});
  } catch { return {ok: false}; }
  return result;
}

async function scanTab(tab, force = false) {
  if (!tab || !safePage(tab.url)) {
    if (tab) scanErrors.set(tab.id, pageAccessError(tab));
    return [];
  }
  if (!force && Date.now() - (scanTimes.get(tab.id) || 0) < 1500) return candidateList(tab.id);
  if (scanWork.has(tab.id)) { await scanWork.get(tab.id); return candidateList(tab.id); }
  const work = runScan(tab);
  scanWork.set(tab.id, work);
  try { await work; } finally { scanWork.delete(tab.id); }
  scanTimes.set(tab.id, Date.now());
  return candidateList(tab.id);
}

async function runScan(tab) {
  let frames;
  try { frames = await chrome.webNavigation.getAllFrames({tabId: tab.id}); } catch { frames = null; }
  frames = frames || [{frameId: 0, url: tab.url}];
  const alive = new Set(frames.map((frame) => frameKey(tab.id, frame.frameId)));
  for (const key of Object.keys(reports)) {
    if (reports[key].tabId === tab.id && !alive.has(key)) delete reports[key];
  }
  let responses = 0;
  await Promise.all(frames.map(async (frame) => {
    const result = await scanFrame(tab.id, frame.frameId);
    if (result?.ok) {
      responses++;
      const pageUrl = result.pageUrl || frame.url;
      reports[frameKey(tab.id, frame.frameId)] = {tabId: tab.id, frameId: frame.frameId, parentFrameId: frame.parentFrameId ?? 0, candidates: normalizeCandidates(result.candidates), pageUrl: safePage(pageUrl) || (['about:blank', 'about:srcdoc'].includes(pageUrl) ? pageUrl : null), visibleFrameUrls: normalizeFrameUrls(result.visibleFrameUrls), updatedAt: Date.now()};
    } else {
      delete reports[frameKey(tab.id, frame.frameId)];
    }
  }));
  if (responses) scanErrors.delete(tab.id);
  else scanErrors.set(tab.id, pageAccessError(tab));
  await persistEphemeral();
  await refreshAction(tab.id);
}

function sanitizeSession(value, tabId, frameId) {
  if (!value || !readId(value.videoId)) return null;
  return {
    videoId: readId(value.videoId), tabId, frameId,
    currentTime: Math.max(0, Number(value.currentTime) || 0),
    duration: Math.max(0, Number(value.duration) || 0),
    paused: !!value.paused,
    configuration: normalizeConfiguration(value.configuration),
    repetitions: Math.max(0, Math.floor(Number(value.repetitions) || 0)),
    gapRemaining: Math.max(0, Number(value.gapRemaining) || 0),
    countingIn: !!value.countingIn,
    adPlaying: !!value.adPlaying,
    frameRate: Number(value.frameRate) > 0 ? Math.min(240, Number(value.frameRate)) : null,
    error: value.error ? String(value.error).slice(0, 300) : null,
  };
}

async function acceptState(value, tabId, frameId, options = {}) {
  if (!session || session.tabId !== tabId || session.frameId !== frameId || session.videoId !== value?.videoId) return;
  session = sanitizeSession(value, tabId, frameId);
  await syncShortcutScopes();
  await persistEphemeral(options);
  const entry = library.find((item) => item.videoId === session.videoId);
  if (entry && JSON.stringify(entry.configuration) !== JSON.stringify(session.configuration)) {
    const videoId = session.videoId;
    const configuration = structuredClone(session.configuration);
    await modifyLibrary((items) => items.map((item) => item.videoId === videoId ? normalizeEntry({...item, configuration, updatedAt: Date.now()}) : item));
  }
}

async function clearChangedVideo(tabId, url) {
  const videoId = extractYouTubeVideoId(url);
  if (!session || session.tabId !== tabId || !videoId || videoId === session.videoId) return;
  const previous = session;
  session = null;
  if (pending?.tabId === tabId) pending = null;
  scanTimes.delete(tabId);
  await sendFrame(previous.tabId, previous.frameId, {type: 'LP_DISCONNECT'});
  await syncShortcutScopes();
  await setOverlayTab(null);
}

async function status() {
  if (!session) return null;
  const source = await activeTab(session.tabId);
  if (source) await clearChangedVideo(source.id, source.url);
  if (!session) return null;
  const bound = {...session};
  const result = await sendFrame(bound.tabId, bound.frameId, {type: 'LP_STATUS'});
  if (result?.ok && result.session?.videoId === bound.videoId && !result.session.error) {
    await acceptState(result.session, bound.tabId, bound.frameId);
    // A reloaded lesson page lost its controller even though the player answered again.
    if (bound.error && overlayTab === bound.tabId) await pushOverlay(bound.tabId, true);
  } else {
    const recovered = await recoverConnection(bound);
    if (!recovered?.ok && sameSelection(bound)) {
      session = {...bound, restore: playbackRestore(bound), paused: true, gapRemaining: 0, errorCode: recovered?.code || null, error: recovered?.error || result?.session?.error || t('runtime.player.disconnected')};
      await persistEphemeral();
    }
  }
  await syncShortcutScopes();
  return session;
}

function sameSelection(bound) {
  return !!session && session.tabId === bound.tabId && session.videoId === bound.videoId && session.frameId === bound.frameId;
}

function playbackRestore(bound) {
  return bound.restore || {currentTime: bound.currentTime, paused: bound.paused, repetitions: bound.repetitions};
}

async function connectFrame(tabId, frameId, videoId, configuration, options = {}) {
  if (options.expected && !sameSelection(options.expected)) return null;
  const result = await sendFrame(tabId, frameId, {type: 'LP_CONNECT', videoId, configuration, repetitions: options.repetitions || 0, restore: options.restore});
  if (!result?.ok || !result.session) return result;
  if (options.expected && !sameSelection(options.expected)) return null;
  const previous = session;
  session = sanitizeSession(result.session, tabId, frameId);
  pending = null;
  await acceptState(result.session, tabId, frameId);
  if (previous && (previous.tabId !== tabId || previous.frameId !== frameId)) {
    await sendFrame(previous.tabId, previous.frameId, {type: 'LP_DISCONNECT'});
  }
  await presentOverlay(tabId, !previous || previous.tabId !== tabId || previous.videoId !== videoId);
  return {ok: true, session};
}

async function connectInTab(tab, videoId, configuration, options = {}) {
  await scanTab(tab, true);
  const candidates = allCandidates(tab.id);
  const players = candidates.filter((candidate) => candidate.videoId === videoId && candidate.kind === 'player');
  let failure = null;
  for (const candidate of players) {
    const result = await connectFrame(tab.id, candidate.frameId, videoId, configuration, options);
    if (result?.ok) return result;
    if (!failure && result?.error) failure = {...result, frameId: candidate.frameId};
  }
  return players.length ? {ok: false, code: failure?.code || null, frameId: failure?.frameId, error: failure?.error || t('runtime.player.notReady')} : null;
}

async function recoverConnection(bound, configuration = bound.configuration) {
  if (!sameSelection(bound)) {
    return session?.tabId === bound.tabId && session.videoId === bound.videoId && !session.error ? {ok: true, session} : null;
  }
  const key = `${bound.tabId}:${bound.videoId}`;
  if (recoveryWork.has(key)) return recoveryWork.get(key);
  const work = (async () => {
    const tab = await activeTab(bound.tabId);
    if (!tab || !sameSelection(bound)) return null;
    if (bound.errorCode === 'PLAYER_NOT_READY') {
      // Keep the user's first play gesture and current position intact.
      return connectInTab(tab, bound.videoId, configuration, {expected: bound, repetitions: bound.repetitions});
    }
    // Recovery stays in the selected tab and never opens another video or tab.
    const restore = playbackRestore(bound);
    return connectInTab(tab, bound.videoId, configuration, {expected: bound, repetitions: restore.repetitions, restore});
  })();
  recoveryWork.set(key, work);
  try { return await work; } finally { recoveryWork.delete(key); }
}

async function sendToSession(message) {
  if (!session) userError(t('runtime.session.connectFirst'));
  let bound = {...session};
  let response = await sendFrame(bound.tabId, bound.frameId, message);
  if (response?.ok && response.session?.videoId === bound.videoId && !response.session.error) {
    await acceptState(response.session, bound.tabId, bound.frameId);
    return response;
  }
  const health = await sendFrame(bound.tabId, bound.frameId, {type: 'LP_STATUS'});
  if (health?.ok && health.session?.videoId === bound.videoId && !health.session.error) return response;
  const recovered = await recoverConnection(bound, message.configuration || bound.configuration);
  if (!recovered?.ok) return {ok: false, error: recovered?.error || t('runtime.player.lost')};
  if (message.type === 'LP_SET_CONFIG') return {ok: true, session: recovered.session};
  bound = {...recovered.session};
  response = await sendFrame(bound.tabId, bound.frameId, message);
  if (response?.ok) await acceptState(response.session, bound.tabId, bound.frameId);
  return response;
}

async function tryPending(tabId) {
  if (!pending || pending.tabId !== tabId || pendingConnecting) return;
  if (Date.now() - pending.createdAt > 90000) { pending = null; await persistEphemeral(); return; }
  const requested = {...pending};
  const tab = await activeTab(tabId);
  if (!tab) return;
  pendingConnecting = true;
  try { await connectInTab(tab, requested.videoId, requested.configuration); }
  finally { pendingConnecting = false; }
}

// Live framing while a joystick is dragged: straight to the player, never stored.
async function previewFraming(message) {
  if (!session || session.error) return {ok: false};
  if (!Number.isInteger(message.index) || message.index < 0 || message.index >= 9) return {ok: false, error: t('runtime.error.invalidSection')};
  const response = await sendFrame(session.tabId, session.frameId, {type: 'LP_PREVIEW_VIEW', index: message.index, view: normalizeView(message.view), mirror: message.mirror === true});
  return {ok: response?.ok === true};
}

async function playerCommand(command, value) {
  const response = await sendToSession({type: 'LP_COMMAND', command, value});
  if (!response?.ok) userError(response?.error || t('runtime.player.controlFailed'));
  return {ok: true, session};
}

function shortcutScope(tabId) {
  return !!(pageShortcuts && session?.tabId === tabId && !session.error && !session.adPlaying && session.duration > 0);
}

async function syncShortcutScopes() {
  const tabIds = new Set([...Object.values(reports).map((report) => report.tabId), ...shortcutScopes.keys()]);
  await Promise.all([...tabIds].map(async (tabId) => {
    const enabled = shortcutScope(tabId);
    if (shortcutScopes.get(tabId) === enabled) return;
    shortcutScopes.set(tabId, enabled);
    const frameIds = new Set(Object.values(reports).filter((report) => report.tabId === tabId).map((report) => report.frameId));
    await Promise.all([...frameIds].map((frameId) => sendFrame(tabId, frameId, {type: 'LP_SHORTCUT_SCOPE', enabled})));
  }));
}

async function applyConfiguration(videoId, raw) {
  if (!videoId) userError(t('runtime.error.chooseVideo'));
  const configuration = normalizeConfiguration(raw);
  if (library.some((item) => item.videoId === videoId)) {
    await modifyLibrary((items) => items.map((item) => item.videoId === videoId ? normalizeEntry({...item, configuration, updatedAt: Date.now()}) : item));
  }
  if (session?.videoId === videoId) {
    const result = await sendToSession({type: 'LP_SET_CONFIG', configuration});
    if (!result?.ok) userError(result?.error || t('runtime.error.applyFailed'));
  }
  return {ok: true, session, entry: library.find((item) => item.videoId === videoId)};
}

// Shared loops arrive from other people: they were confirmed in the panel and are validated again here.
async function importLoops(raw, mode) {
  const {videos} = sanitizeSharedVideos(raw);
  if (!videos.length) userError(t('runtime.error.noLoopsToImport'));
  const summary = {added: 0, updated: 0, skipped: 0};
  const point = await modifyWithRestorePoint('import-loops', ({library: items}) => {
    const now = Date.now();
    summary.skipped = 0;
    const created = [];
    const updated = new Map();
    for (const video of videos) {
      const entry = items.find((item) => item.videoId === video.videoId);
      const base = entry?.configuration ?? (session?.videoId === video.videoId ? session.configuration : null);
      const {configuration} = mergeSharedConfiguration(base, video.configuration, mode);
      if (entry) {
        updated.set(video.videoId, normalizeEntry({...entry, configuration, updatedAt: now}));
      } else if (items.length + created.length < MAX_LIBRARY_ENTRIES) {
        // A video that is not saved yet keeps its YouTube link as the origin.
        created.push(normalizeEntry({videoId: video.videoId, title: video.title, configuration, sources: [{url: youtubeUrl(video.videoId), title: 'YouTube'}], createdAt: now, updatedAt: now}));
      } else { summary.skipped++; continue; }
    }
    summary.added = created.length;
    summary.updated = updated.size;
    return {library: [...created, ...items.map((item) => updated.get(item.videoId) || item)]};
  });
  await syncSessionConfiguration();
  return {ok: true, library, summary, session, restorePoint: restorePointInfo(point)};
}

async function connectVideo({videoId: rawId, tabId, allowOpen}) {
  const videoId = readId(rawId);
  if (!videoId) userError(t('runtime.error.chooseYouTubeVideo'));
  const entry = library.find((item) => item.videoId === videoId);
  const reconnecting = allowOpen === false && session?.videoId === videoId && session.tabId === tabId;
  const configuration = reconnecting ? session.configuration : entry?.configuration || defaultConfiguration();
  const tab = await activeTab(tabId);
  if (tab) {
    const restore = reconnecting ? playbackRestore(session) : null;
    const connected = await connectInTab(tab, videoId, configuration, restore ? {repetitions: restore.repetitions, restore} : {});
    if (connected) {
      if (connected.code === 'PLAYER_NOT_READY') {
        const previous = session;
        session = {...(reconnecting ? session : {}), videoId, tabId: tab.id, frameId: connected.frameId,
          configuration, paused: true, currentTime: reconnecting ? session.currentTime : 0,
          duration: 0, repetitions: reconnecting ? session.repetitions : 0,
          errorCode: connected.code, error: connected.error};
        if (previous && (previous.tabId !== session.tabId || previous.frameId !== session.frameId)) {
          await sendFrame(previous.tabId, previous.frameId, {type: 'LP_DISCONNECT'});
        }
        await syncShortcutScopes();
        await persistEphemeral();
        // The controller explains the next step (press play) on the lesson page itself.
        await presentOverlay(tab.id, !previous || previous.tabId !== tab.id || previous.videoId !== videoId);
        return {ok: true, session, overlay: overlayInfo()};
      }
      if (!connected.ok && session?.videoId === videoId && session.tabId === tab.id) {
        session = {...session, error: connected.error};
        await persistEphemeral();
      }
      return connected.ok ? {...connected, overlay: overlayInfo()} : connected;
    }
  }
  if (allowOpen !== true) userError(t('runtime.player.connectFailed'));
  const opened = await chrome.tabs.create({url: youtubeUrl(videoId)});
  pending = {videoId, configuration, tabId: opened.id, createdAt: Date.now()};
  await persistEphemeral();
  return {ok: true, opening: true, tabId: opened.id};
}

function overlayValue(command, value) {
  if (command === 'seek') return Number.isFinite(value) && Math.abs(value) <= 10 ? value : null;
  if (command === 'seek-to') return Number.isFinite(value) && value >= 0 ? value : null;
  if (command === 'select-part') return Number.isInteger(value) && value >= 0 && value < 9 ? value : null;
  if (command === 'frame-step') return value === -1 || value === 1 ? value : null;
  return undefined;
}

// Messages from the floating controller in a lesson page's top frame.
async function handleOverlay(message, tabId, frameId) {
  if (frameId !== 0 || overlayTab !== tabId) return {ok: false, error: t('runtime.overlay.notThisTab')};
  switch (message.type) {
    case 'OVERLAY_PREFS': {
      overlayPrefs = sanitizeOverlayPrefs({...overlayPrefs, ...message.prefs, autoShow: overlayPrefs.autoShow});
      await chrome.storage.local.set({[OVERLAY_KEY]: overlayPrefs});
      scheduleFolderBackup();
      notify();
      return {ok: true};
    }
    case 'OVERLAY_CLOSE': await setOverlayTab(null); return {ok: true};
    default: break;
  }
  if (session?.tabId !== tabId) return {ok: false, error: t('runtime.overlay.selectPractice')};
  switch (message.type) {
    case 'OVERLAY_COMMAND': {
      const value = overlayValue(message.command, message.value);
      if (!OVERLAY_COMMANDS.includes(message.command) || value === null) return {ok: false, error: t('runtime.error.invalidCommand')};
      return playerCommand(message.command, value);
    }
    case 'OVERLAY_SET_CONFIG': return applyConfiguration(session.videoId, message.configuration);
    case 'OVERLAY_PREVIEW_VIEW': return previewFraming(message);
    case 'OVERLAY_RECONNECT': return connectVideo({videoId: session.videoId, tabId, allowOpen: false});
    case 'OVERLAY_SHARE': return {ok: true, code: encodeShareCode(session, {scope: message.scope === 'active' ? 'active' : 'all'})};
    default: return {ok: false, error: t('runtime.error.unknownAction')};
  }
}

// ---- Tools: Tuner, Notes and Metronome --------------------------------------------------------

function persistTools() {
  return chrome.storage.session.set({[TOOLS_STATE_KEY]: {windows: toolWindows, popups: toolPopups, metronomeOn, fretboard: fretboardTab}}).catch(() => {});
}

// Tabs whose top frame shows a tool interface: the practice controller or a standalone window.
function toolTabs() {
  const tabs = new Set(Object.values(toolWindows).filter(Number.isInteger));
  if (overlayInfo().visible) tabs.add(overlayTab);
  return tabs;
}

function videoTempo() {
  if (!session || session.error || !session.configuration) return null;
  const {bpm, speed, beats, countIn} = session.configuration;
  return {bpm, speed, effective: effectiveBpm(session.configuration), beats, countIn};
}

// The metronome follows the practice video (song tempo × speed) once its tempo is known.
function metronomeSettings() {
  const prefs = toolPrefs.metronome;
  const tempo = videoTempo();
  const follow = Boolean(prefs.follow && tempo?.effective);
  return {running: metronomeOn, bpm: follow ? tempo.effective : prefs.bpm, beats: follow ? tempo.beats : prefs.beats, accent: prefs.accent, volume: prefs.volume, source: follow ? 'video' : 'manual'};
}

function unionViews() {
  const views = new Set();
  for (const client of toolClients.values()) for (const view of client.views) views.add(view);
  return views;
}

function toolsState() {
  return {
    type: 'state', prefs: toolPrefs, engine: engineStatus, metronome: metronomeSettings(), tempo: videoTempo(),
    session: session ? {ready: !session.error && session.duration > 0, title: sessionTitle()} : null,
    windows: Object.fromEntries(TOOL_IDS.map((tool) => [tool, toolWindows[tool] !== null || Number.isInteger(toolPopups[tool])])),
  };
}

function postPort(port, message) {
  try { port.postMessage(message); } catch { toolClients.delete(port); }
}

function broadcastTools(force = false) {
  const state = toolsState();
  const key = JSON.stringify(state);
  if (!force && key === toolsBroadcastKey) return;
  toolsBroadcastKey = key;
  for (const port of [...toolClients.keys()]) postPort(port, state);
}

// Session changes reach the tools (follow speed, count-in) without extra messages.
function syncTools() {
  broadcastTools();
  queueEngineSync();
}

function engineConfig() {
  const views = unionViews();
  const capture = CAPTURE_VIEWS.some((view) => views.has(view));
  const {source, ...metronome} = metronomeSettings();
  return {type: 'configure', capture: capture ? {deviceId: toolPrefs.input.deviceId, channel: toolPrefs.input.channel} : null, analysis: toolPrefs.tuner, metronome};
}

// Keeping the engine while a count-in is configured makes the first click land on time.
function engineNeeded(config) {
  const countIn = session && !session.error && session.configuration?.countIn !== 'off' && session.configuration?.bpm;
  return Boolean(config.capture || config.metronome.running || countIn);
}

function postEngine(message) {
  if (!enginePort) return false;
  try { enginePort.postMessage(message); return true; } catch { enginePort = null; return false; }
}

function waitForEngine(timeout = 4000) {
  if (enginePort) return Promise.resolve(true);
  return new Promise((resolve) => {
    const done = (value) => { clearTimeout(timer); engineWaiters = engineWaiters.filter((waiter) => waiter !== done); resolve(value); };
    const timer = setTimeout(() => done(false), timeout);
    engineWaiters.push(done);
  });
}

async function ensureEngine() {
  if (enginePort) return true;
  if (!chrome.offscreen?.createDocument) return false;
  try {
    const contexts = await chrome.runtime.getContexts?.({contextTypes: ['OFFSCREEN_DOCUMENT'], documentUrls: [chrome.runtime.getURL(ENGINE_URL)]}) || [];
    if (!contexts.length) {
      engineCreating ??= chrome.offscreen.createDocument({url: ENGINE_URL, reasons: ['USER_MEDIA', 'AUDIO_PLAYBACK'], justification: 'Afinador, detecção de notas e metrônomo do Loop Player.'}).finally(() => { engineCreating = null; });
      await engineCreating;
    }
  } catch (error) {
    // A document created by a concurrent call is fine; anything else is reported to the tools.
    if (!/single offscreen|only a single/i.test(String(error?.message))) {
      engineStatus = sanitizeEngineStatus({status: 'error', error: 'unknown', message: String(error?.message || error)});
      broadcastTools();
      return false;
    }
  }
  return waitForEngine();
}

function scheduleEngineClose() {
  if (engineIdleTimer || !enginePort) return;
  engineIdleTimer = setTimeout(() => {
    engineIdleTimer = null;
    if (engineNeeded(engineConfig())) return;
    chrome.offscreen?.closeDocument?.().catch(() => {});
  }, ENGINE_IDLE_MS);
}

async function syncEngine({settled = false, force = false} = {}) {
  const config = engineConfig();
  // Before the first configuration (worker restart) the engine may be capturing: wait for clients.
  if (!settled && !config.capture && (engineLast === undefined ? enginePort !== null : engineLast.capture)) {
    engineGraceTimer ??= setTimeout(() => { engineGraceTimer = null; queueEngineSync({settled: true}); }, ENGINE_GRACE_MS);
    return;
  }
  clearTimeout(engineGraceTimer);
  engineGraceTimer = null;
  if (engineNeeded(config)) {
    clearTimeout(engineIdleTimer);
    engineIdleTimer = null;
    if (!await ensureEngine()) return;
  } else if (!enginePort) {
    engineLast = config;
    return;
  } else {
    scheduleEngineClose();
  }
  const key = JSON.stringify(config);
  if (!force && key === engineSent) return;
  engineSent = key;
  engineLast = config;
  postEngine(config);
}

function queueEngineSync(options) {
  engineQueue = engineQueue.catch(() => {}).then(() => syncEngine(options));
  return engineQueue;
}

function onViewsChanged() {
  const views = unionViews();
  const tuner = views.has('tuner');
  // Opening the tuner pauses the practice video so its sound does not reach the microphone.
  if (tuner && !tunerVisible && session && !session.error && (!session.paused || session.gapRemaining > 0)) playerCommand('pause').catch(() => {});
  tunerVisible = tuner;
  clearTimeout(metronomeStopTimer);
  metronomeStopTimer = null;
  if (!toolClients.size && metronomeOn) {
    // Closing the last tool interface also stops the metronome.
    metronomeStopTimer = setTimeout(() => {
      metronomeStopTimer = null;
      if (toolClients.size || !metronomeOn) return;
      metronomeOn = false;
      persistTools();
      syncTools();
    }, ENGINE_GRACE_MS);
  }
  queueEngineSync();
}

function fromEngine(message) {
  switch (message?.type) {
    case 'status':
      engineStatus = sanitizeEngineStatus(message);
      broadcastTools();
      break;
    case 'reading': {
      const reading = {type: 'reading', ...sanitizeReading(message)};
      for (const [port, client] of [...toolClients]) if (client.views.some((view) => CAPTURE_VIEWS.includes(view))) postPort(port, reading);
      break;
    }
    case 'beat': {
      const beat = {type: 'beat', ...sanitizeBeat(message)};
      for (const [port, client] of [...toolClients]) if (client.views.includes('metronome')) postPort(port, beat);
      break;
    }
    default: break;
  }
}

function toolWindowMessage(tabId) {
  return {type: 'LPO_TOOLS', windows: Object.fromEntries(TOOL_IDS.map((tool) => [tool, toolWindows[tool] === tabId ? {open: true, ...toolPrefs.windows[tool]} : {open: false}]))};
}

async function pushTools(tabId, inject = false) {
  if (!Number.isInteger(tabId)) return false;
  const deliver = async () => {
    try { return await chrome.tabs.sendMessage(tabId, toolWindowMessage(tabId), {frameId: 0}); } catch { return null; }
  };
  let reply = await deliver();
  if (!reply?.ok && inject) {
    try { await chrome.scripting.executeScript({target: {tabId, frameIds: [0]}, files: ['overlay.js']}); } catch { return false; }
    reply = await deliver();
  }
  return !!reply?.ok;
}

// Shows or removes the floating fretboard window in a tab's top frame (injecting the overlay when asked).
async function pushFretboard(tabId, inject = false) {
  if (!Number.isInteger(tabId)) return false;
  const deliver = async () => {
    try { return await chrome.tabs.sendMessage(tabId, {type: 'LPO_FRETBOARD', open: fretboardTab === tabId}, {frameId: 0}); } catch { return null; }
  };
  let reply = await deliver();
  if (!reply?.ok && inject) {
    try { await chrome.scripting.executeScript({target: {tabId, frameIds: [0]}, files: ['overlay.js']}); } catch { return false; }
    reply = await deliver();
  }
  return !!reply?.ok;
}

async function setFretboardTab(tabId) {
  const previous = fretboardTab;
  fretboardTab = tabId;
  if (Number.isInteger(previous) && previous !== tabId) await pushFretboard(previous);
  await persistTools();
}

function pageHostsTools(tab) {
  if (!tab || !safePage(tab.url)) return false;
  try {
    const {hostname, pathname} = new URL(tab.url);
    return hostname !== 'chromewebstore.google.com' && !(hostname === 'chrome.google.com' && pathname.startsWith('/webstore'));
  } catch { return false; }
}

async function openToolPopup(tool) {
  const existing = toolPopups[tool];
  if (Number.isInteger(existing)) {
    try {
      await chrome.windows.update(existing, {focused: true});
      return {ok: true, where: 'window', windowId: existing};
    } catch { delete toolPopups[tool]; }
  }
  const created = await chrome.windows.create({url: chrome.runtime.getURL(`tools.html?tool=${tool}`), type: 'popup', width: 360, height: 600, focused: true});
  toolPopups[tool] = created.id;
  await persistTools();
  broadcastTools();
  return {ok: true, where: 'window', windowId: created.id};
}

// Shows a standalone tool window on the page, or in a small extension window where pages refuse it.
async function openTool(tool, tabId) {
  if (!TOOL_IDS.includes(tool)) userError(t('runtime.tools.unknownTool'));
  const tab = await activeTab(tabId);
  if (pageHostsTools(tab)) {
    const previous = toolWindows[tool];
    toolWindows[tool] = tab.id;
    if (await pushTools(tab.id, true)) {
      if (Number.isInteger(previous) && previous !== tab.id) await pushTools(previous);
      await persistTools();
      broadcastTools();
      return {ok: true, where: 'page', tabId: tab.id};
    }
    toolWindows[tool] = previous;
  }
  return openToolPopup(tool);
}

async function closeToolWindow(tool) {
  const tabId = toolWindows[tool];
  toolWindows[tool] = null;
  await pushTools(tabId);
  await persistTools();
  broadcastTools();
}

async function dropToolWindows(tabId) {
  let changed = false;
  for (const tool of TOOL_IDS) if (toolWindows[tool] === tabId) { toolWindows[tool] = null; changed = true; }
  if (changed) { await persistTools(); broadcastTools(); }
}

// The metronome edits the tempo heard at the current speed; the video keeps it at 100%.
async function setVideoTempo(message) {
  if (!session || session.error || !session.configuration) userError(t('runtime.tools.connectForTempo'));
  const configuration = structuredClone(session.configuration);
  if (message.effective === null) configuration.bpm = null;
  else if (message.effective !== undefined) {
    const effective = Number(message.effective);
    if (!Number.isFinite(effective) || effective <= 0) userError(t('runtime.tools.invalidBpm'));
    configuration.bpm = effective / (configuration.speed || 1);
  }
  if (message.beats !== undefined) configuration.beats = message.beats;
  if (message.countIn !== undefined) configuration.countIn = message.countIn;
  const result = await applyConfiguration(session.videoId, configuration);
  syncTools();
  return {...result, tempo: videoTempo()};
}

// Commands from tool interfaces. Page overlays may only use them while their tab shows a tool.
async function handleTools(message, sender, trusted) {
  if (!trusted && (sender.frameId !== 0 || !toolTabs().has(sender.tab?.id))) return {ok: false, error: t('runtime.tools.notOpen')};
  switch (message.type) {
    case 'TOOLS_PREFS': {
      const next = sanitizeToolPrefs(message.patch, toolPrefs);
      await chrome.storage.local.set({[TOOLS_KEY]: next});
      toolPrefs = next;
      syncTools();
      scheduleFolderBackup();
      return {ok: true, prefs: toolPrefs};
    }
    case 'TOOLS_METRONOME': {
      if (typeof message.running !== 'boolean') return {ok: false, error: t('runtime.tools.metronomeChoice')};
      metronomeOn = message.running;
      await persistTools();
      syncTools();
      return {ok: true, metronome: metronomeSettings()};
    }
    case 'TOOLS_TEMPO': return setVideoTempo(message);
    case 'TOOLS_CLEAR_NOTES': postEngine({type: 'clear-notes'}); return {ok: true};
    case 'TOOLS_RETRY': await queueEngineSync({settled: true, force: true}); return {ok: true};
    case 'TOOLS_OPEN_SETUP': await chrome.tabs.create({url: chrome.runtime.getURL('tools.html?setup=mic')}); return {ok: true};
    case 'TOOLS_WINDOW': {
      const tool = message.tool;
      if (!TOOL_IDS.includes(tool) || (!trusted && toolWindows[tool] !== sender.tab.id)) return {ok: false, error: t('runtime.tools.windowNotOpen')};
      if (message.close === true) { await closeToolWindow(tool); return {ok: true}; }
      toolPrefs = sanitizeToolPrefs({windows: {[tool]: message.prefs}}, toolPrefs);
      await chrome.storage.local.set({[TOOLS_KEY]: toolPrefs});
      scheduleFolderBackup();
      return {ok: true};
    }
    default: return {ok: false, error: t('runtime.tools.unknownAction')};
  }
}

// Count-in requests come only from the frame that plays the practice video.
async function handleCountIn(message, tabId, frameId) {
  if (session?.tabId !== tabId || session.frameId !== frameId) return {ok: false};
  if (message.type === 'CONTENT_COUNT_IN_CANCEL') return {ok: postEngine({type: 'count-in-cancel'})};
  const request = sanitizeCountIn(message, Date.now());
  if (!request || !await ensureEngine()) return {ok: false};
  return {ok: postEngine({type: 'count-in', ...request, accent: toolPrefs.metronome.accent, volume: toolPrefs.metronome.volume})};
}

function connectToolClient(port) {
  const sender = port.sender || {};
  const trusted = trustedUi(sender);
  if (!trusted && !(sender.id === chrome.runtime.id && Number.isInteger(sender.tab?.id) && sender.frameId === 0)) { port.disconnect(); return; }
  const client = {tabId: sender.tab?.id ?? null, trusted, views: []};
  toolClients.set(port, client);
  port.onMessage.addListener((message) => ready.then(() => {
    if (message?.type !== 'views') return;
    // Page overlays only count while their tab shows a tool interface.
    client.views = client.trusted || toolTabs().has(client.tabId) ? sanitizeViews(message.views) : [];
    onViewsChanged();
  }));
  port.onDisconnect.addListener(() => {
    toolClients.delete(port);
    ready.then(onViewsChanged).catch(() => {});
  });
  ready.then(() => postPort(port, toolsState())).catch(() => {});
}

function connectEngine(port) {
  if (port.sender?.url !== chrome.runtime.getURL(ENGINE_URL)) { port.disconnect(); return; }
  enginePort = port;
  engineSent = '';
  port.onMessage.addListener((message) => ready.then(() => fromEngine(message)).catch(() => {}));
  port.onDisconnect.addListener(() => {
    if (enginePort !== port) return;
    enginePort = null;
    engineLast = undefined;
    engineSent = '';
    engineStatus = sanitizeEngineStatus({});
    ready.then(() => broadcastTools()).catch(() => {});
  });
  for (const waiter of [...engineWaiters]) waiter(true);
  ready.then(() => queueEngineSync()).catch(() => {});
}

async function handleUi(message) {
  switch (message.type) {
    case 'SHOW_OVERLAY': {
      await status();
      if (!session) userError(t('runtime.overlay.selectBeforeOpening'));
      if (!await setOverlayTab(session.tabId)) userError(t('runtime.overlay.showDenied'));
      return {ok: true, overlay: overlayInfo()};
    }
    case 'HIDE_OVERLAY': await setOverlayTab(null); return {ok: true, overlay: overlayInfo()};
    case 'SET_OVERLAY_PREFS': {
      // Each switch in Ajustes sends only its own preference.
      const changes = {};
      for (const [name, error] of [['autoShow', 'runtime.overlay.autoShowChoice'], ['stage', 'runtime.overlay.stageChoice']]) {
        if (message[name] === undefined) continue;
        if (typeof message[name] !== 'boolean') userError(t(error));
        changes[name] = message[name];
      }
      if (!Object.keys(changes).length) userError(t('runtime.overlay.prefChoice'));
      overlayPrefs = {...overlayPrefs, ...changes};
      await chrome.storage.local.set({[OVERLAY_KEY]: overlayPrefs});
      scheduleFolderBackup();
      notify();
      return {ok: true, overlay: overlayInfo()};
    }
    case 'SET_PAGE_SHORTCUTS': {
      if (typeof message.enabled !== 'boolean') userError(t('runtime.settings.shortcutsChoice'));
      await chrome.storage.local.set({[SHORTCUTS_KEY]: message.enabled});
      pageShortcuts = message.enabled;
      await syncShortcutScopes();
      scheduleFolderBackup();
      return {ok: true, pageShortcuts};
    }
    case 'GET_DIAGNOSTICS': {
      const tab = await activeTab();
      const tabId = session?.tabId ?? tab?.id;
      let frames = [];
      let navigationError = null;
      try { frames = await chrome.webNavigation.getAllFrames({tabId}) || []; }
      catch (error) { navigationError = String(error.message || error); }
      const known = Object.values(reports).filter((report) => report.tabId === tabId);
      const frameIds = [...new Set([...frames.map((frame) => frame.frameId), ...known.map((report) => report.frameId), ...(session ? [session.frameId] : [])])];
      const probes = await Promise.all(frameIds.map(async (frameId) => {
        try {
          const reply = await chrome.tabs.sendMessage(tabId, {type: 'LP_STATUS'}, {frameId});
          return {frameId, responds: !!reply?.ok, videoId: reply?.session?.videoId || null, error: reply?.error || reply?.session?.error || null};
        } catch (error) { return {frameId, responds: false, error: String(error.message || error)}; }
      }));
      return {ok: true, diagnostics: {
        version: chrome.runtime.getManifest?.().version || t('runtime.diagnostics.unknownVersion'), activeTabId: tab?.id ?? null,
        selection: session ? {tabId: session.tabId, frameId: session.frameId, videoId: session.videoId, error: session.error} : null,
        navigationError, frames: frames.map((frame) => ({frameId: frame.frameId, parentFrameId: frame.parentFrameId})),
        reports: known.map((report) => ({frameId: report.frameId, parentFrameId: report.parentFrameId, rendered: frameIsRendered(report), videos: report.candidates.map(({videoId, kind}) => ({videoId, kind}))})),
        probes,
      }};
    }
    case 'GET_CONTEXT': {
      const tab = await activeTab(message.tabId);
      const candidates = await scanTab(tab);
      if (pending) await tryPending(pending.tabId);
      await status();
      const commands = await chrome.commands.getAll();
      await purgeTrash();
      return {ok: true, tab: tab ? {id: tab.id, url: tab.url || '', title: tab.title || ''} : null, candidates, library, session, commands, pageShortcuts, overlay: overlayInfo(), error: tab ? scanErrors.get(tab.id) || null : pageAccessError(tab),
        backupFolder: folderStatus, trashCount: trash.length, restorePoints: restorePoints.map(restorePointInfo)};
    }
    case 'SAVE_VIDEO': {
      const tab = await activeTab(message.tabId);
      const candidate = normalizeCandidates([message.candidate])[0];
      if (!candidate) userError(t('runtime.library.invalidLink'));
      const sourceUrl = safePage(message.candidate?.pageUrl) || safePage(tab?.url) || candidate.youtubeUrl;
      const sources = {url: sourceUrl, title: sourceUrl === tab?.url ? tab.title || sourceUrl : sourceUrl};
      await modifyLibrary((items) => {
        if (!items.some((entry) => entry.videoId === candidate.videoId) && items.length >= MAX_LIBRARY_ENTRIES) userError(t('runtime.library.full', {max: MAX_LIBRARY_ENTRIES}));
        return upsertVideo(items, candidate, sources);
      });
      return {ok: true, entry: library.find((item) => item.videoId === candidate.videoId), library};
    }
    case 'UPDATE_VIDEO': {
      const videoId = readId(message.videoId);
      if (!library.some((item) => item.videoId === videoId)) userError(t('runtime.library.notSaved'));
      const patch = message.patch || {};
      await modifyLibrary((items) => items.map((item) => item.videoId === videoId ? normalizeEntry({...item, ...(typeof patch.title === 'string' ? {title: patch.title} : {}), ...(typeof patch.notes === 'string' ? {notes: patch.notes} : {}), ...(patch.configuration ? {configuration: normalizeConfiguration(patch.configuration)} : {}), updatedAt: Date.now()}) : item));
      if (patch.configuration && session?.videoId === videoId) {
        const result = await sendToSession({type: 'LP_SET_CONFIG', configuration: normalizeConfiguration(patch.configuration)});
        if (!result?.ok) userError(result?.error || t('runtime.error.applyFailed'));
      }
      return {ok: true, entry: library.find((item) => item.videoId === videoId), library};
    }
    case 'DELETE_VIDEO': {
      const videoId = readId(message.videoId);
      let moved = null;
      await modifyData((state) => {
        const result = moveToTrash(state.library, sanitizeTrash(state.trash, Date.now()), videoId, Date.now());
        moved = result.moved;
        return moved ? {library: result.library, trash: result.trash} : {};
      });
      return {ok: true, library, trashed: moved ? {videoId: moved.videoId, title: moved.title} : null, trashCount: trash.length};
    }
    case 'GET_TRASH': {
      await purgeTrash();
      return {ok: true, trash: trash.map(({entry, deletedAt}) => ({videoId: entry.videoId, title: entry.title, fragments: entry.configuration.fragments.length, deletedAt, expiresAt: trashExpiresAt({deletedAt})}))};
    }
    case 'RESTORE_FROM_TRASH': {
      const videoId = readId(message.videoId);
      await modifyData((state) => {
        const result = takeFromTrash(state.library, sanitizeTrash(state.trash, Date.now()), videoId);
        if (!result.entry) userError(t('backup.trash.missing'));
        // Saved again since the deletion: both copies are merged.
        if (result.saved) return {library: mergeLibrary(result.library, [result.entry]).library, trash: result.trash};
        if (state.library.length >= MAX_LIBRARY_ENTRIES) userError(t('backup.trash.libraryFull', {max: MAX_LIBRARY_ENTRIES}));
        return {library: result.library, trash: result.trash};
      });
      await syncSessionConfiguration();
      return {ok: true, library, trashCount: trash.length};
    }
    case 'EMPTY_TRASH': {
      await modifyData(() => ({trash: []}));
      return {ok: true, trash: [], trashCount: 0};
    }
    case 'UNDO_RESTORE_POINT': {
      const point = restorePoints.find((item) => item.id === message.id);
      if (!point) userError(t('backup.points.missing'));
      await modifyData((state) => ({library: point.library, trash: sanitizeTrash(point.trash, Date.now()), ...(Array.isArray(point.diagrams) ? {diagrams: point.diagrams} : {}), restorePoints: state.restorePoints.filter((item) => item.id !== point.id)}));
      await applyPreferences(point.preferences);
      await syncSessionConfiguration();
      notify();
      return {ok: true, library, trashCount: trash.length, pageShortcuts, overlay: overlayInfo(), restorePoints: restorePoints.map(restorePointInfo)};
    }
    case 'RESTORE_BACKUP': {
      // Restoring replaces the library; videos that are not in the backup go to the trash.
      const backup = parseBackup(message.backup);
      const kept = new Set(backup.library.map((entry) => entry.videoId));
      let removed = 0;
      const point = await modifyWithRestorePoint('restore', (state) => {
        const now = Date.now();
        let current = state.library;
        let nextTrash = sanitizeTrash(state.trash, now);
        removed = 0;
        for (const entry of state.library) {
          if (kept.has(entry.videoId)) continue;
          ({library: current, trash: nextTrash} = moveToTrash(current, nextTrash, entry.videoId, now));
          removed++;
        }
        return {library: backup.library, trash: nextTrash, ...(backup.diagrams ? {diagrams: backup.diagrams} : {})};
      });
      await applyPreferences(backup.preferences);
      await syncSessionConfiguration();
      notify();
      return {ok: true, library, removed, trashCount: trash.length, pageShortcuts, overlay: overlayInfo(), restorePoint: restorePointInfo(point)};
    }
    case 'BACKUP_FOLDER_CHANGED':
    case 'BACKUP_FOLDER_RUN': {
      clearTimeout(folderTimer);
      folderTimer = null;
      await runFolderBackup();
      return {ok: true, backupFolder: folderStatus};
    }
    case 'BACKUP_FOLDER_FORGET': {
      clearTimeout(folderTimer);
      folderTimer = null;
      await forgetFolderHandle().catch(() => {});
      await setFolderStatus({state: 'none', name: '', lastBackupAt: 0, error: '', pending: false});
      return {ok: true, backupFolder: folderStatus};
    }
    case 'EXPORT_BACKUP': {
      await storageQueue.catch(() => {});
      return {ok: true, backup: createBackup({library, diagrams, preferences: currentPreferences(), appVersion: chrome.runtime.getManifest?.().version, exportedAt: Date.now()})};
    }
    case 'IMPORT_BACKUP': {
      const backup = parseBackup(message.backup);
      let summary;
      const point = await modifyWithRestorePoint('import-backup', (state) => {
        const {library: merged, ...counts} = mergeLibrary(state.library, backup.library);
        const shapes = backup.diagrams ? mergeDiagrams(state.diagrams, backup.diagrams, {now: Date.now()}) : null;
        summary = {...counts, ignored: backup.ignored, diagrams: shapes ? shapes.added + shapes.updated : 0};
        return {library: merged, ...(shapes ? {diagrams: shapes.diagrams} : {})};
      });
      await applyPreferences(backup.preferences);
      await syncSessionConfiguration();
      notify();
      return {ok: true, summary, library, pageShortcuts, overlay: overlayInfo(), restorePoint: restorePointInfo(point)};
    }
    case 'OPEN_FRETBOARD': {
      // Like the other tools, the fretboard floats over the current page; pages the extension cannot
      // reach get the compact window instead, and "Abrir completo" a tab.
      if (message.layout !== 'tab' && message.layout !== 'window') {
        const tab = await activeTab(message.tabId);
        if (pageHostsTools(tab)) {
          const previous = fretboardTab;
          await setFretboardTab(tab.id);
          if (await pushFretboard(tab.id, true)) return {ok: true, where: 'page', tabId: tab.id};
          await setFretboardTab(previous);
        }
      }
      // One compact window and one full tab at most: an open one comes to the front instead of a copy.
      const base = chrome.runtime.getURL('fretboard.html');
      const compact = message.layout !== 'tab';
      const existing = (await chrome.tabs.query({}).catch(() => [])).find((tab) => typeof tab.url === 'string' && tab.url.startsWith(base) && tab.url.includes('layout=compact') === compact);
      if (existing) {
        await chrome.tabs.update(existing.id, {active: true});
        if (Number.isInteger(existing.windowId)) await chrome.windows?.update(existing.windowId, {focused: true, ...(compact ? {state: 'normal'} : {})}).catch(() => {});
        return {ok: true, where: compact ? 'window' : 'tab', tabId: existing.id};
      }
      if (!compact) {
        const tab = await chrome.tabs.create({url: base});
        return {ok: true, where: 'tab', tabId: tab.id};
      }
      const created = await chrome.windows.create({url: `${base}?layout=compact`, type: 'popup', focused: true, ...fretboardBounds((await chrome.storage.local.get(FRETBOARD_WINDOW_KEY))[FRETBOARD_WINDOW_KEY])});
      return {ok: true, where: 'window', windowId: created.id};
    }
    case 'FRETBOARD_WINDOW': {
      if (message.close !== true) return {ok: false};
      const tabId = fretboardTab;
      await setFretboardTab(null);
      await pushFretboard(tabId);
      return {ok: true};
    }
    case 'GET_DIAGRAMS': return {ok: true, diagrams};
    case 'SAVE_DIAGRAM': {
      let saved = null;
      await modifyData((state) => {
        const result = saveDiagram(state.diagrams, message.diagram, {now: Date.now()});
        saved = result.diagram;
        return {diagrams: result.diagrams};
      });
      return {ok: true, diagram: saved, diagrams};
    }
    case 'DELETE_DIAGRAM': {
      await modifyData((state) => (state.diagrams.some((item) => item.id === message.id) ? {diagrams: state.diagrams.filter((item) => item.id !== message.id)} : {}));
      return {ok: true, diagrams};
    }
    case 'IMPORT_DIAGRAMS': {
      // Shared diagrams were checked in the page; they are normalized again here before they are saved.
      if (!Array.isArray(message.diagrams)) userError(t('fretboard.file.noDiagrams'));
      let summary;
      await modifyData((state) => {
        const {diagrams: merged, ...counts} = mergeDiagrams(state.diagrams, message.diagrams.slice(0, MAX_DIAGRAMS * 2), {now: Date.now()});
        summary = counts;
        return counts.added || counts.updated ? {diagrams: merged} : {};
      });
      return {ok: true, summary, diagrams};
    }
    case 'OPEN_VIDEO': {
      const entry = library.find((item) => item.videoId === readId(message.videoId));
      if (!entry) userError(t('runtime.library.notSaved'));
      const url = message.mode === 'source' ? safePage(entry.sources[0]?.url) || entry.youtubeUrl : entry.youtubeUrl;
      const tab = await chrome.tabs.create({url});
      return {ok: true, tabId: tab.id};
    }
    case 'CONNECT_VIDEO': return connectVideo(message);
    case 'IMPORT_LOOPS': return importLoops(message.videos, message.mode === 'replace' ? 'replace' : 'add');
    case 'PLAYER_COMMAND': return playerCommand(message.command, message.value);
    case 'SET_CONFIG': return applyConfiguration(readId(message.videoId), message.configuration);
    case 'PREVIEW_VIEW': return previewFraming(message);
    case 'GET_TOOLS': return {ok: true, ...toolsState()};
    case 'OPEN_TOOL': return openTool(message.tool, message.tabId);
    case 'SHOW_PRACTICE_TOOLS': {
      if (!TOOL_IDS.includes(message.tool)) userError(t('runtime.tools.unknownTool'));
      await status();
      if (!session) userError(t('runtime.tools.selectBeforeOpening'));
      overlayPrefs = {...overlayPrefs, tools: {open: true, tab: message.tool}};
      await chrome.storage.local.set({[OVERLAY_KEY]: overlayPrefs});
      scheduleFolderBackup();
      practiceToolsRequest = message.tool;
      if (!await setOverlayTab(session.tabId)) userError(t('runtime.overlay.showDenied'));
      return {ok: true, overlay: overlayInfo()};
    }
    default:
      if (message.type.startsWith('TOOLS_')) return handleTools(message, {}, true);
      userError(t('runtime.error.unknownMessage'));
  }
}

function trustedUi(sender) {
  return sender.id === chrome.runtime.id && typeof sender.url === 'string' && sender.url.startsWith(chrome.runtime.getURL(''));
}

chrome.runtime.onMessage.addListener((message, sender, respond) => {
  if (!message || typeof message.type !== 'string' || sender.id !== chrome.runtime.id) return;
  const work = ready.then(async () => {
    if (trustedUi(sender)) return handleUi(message);
    if (sender.tab && Number.isInteger(sender.tab.id) && Number.isInteger(sender.frameId)) {
      if (message.type === 'CONTENT_SHORTCUT') {
        const allowed = ['toggle-play', 'capture-a', 'capture-b', 'toggle-loop', 'restart', 'seek', 'select-part', 'frame-step'];
        if (!shortcutScope(sender.tab.id) || !allowed.includes(message.command)) return {ok: false};
        if (message.command === 'seek' && ![-1, 1, -0.1, 0.1].includes(message.value)) return {ok: false};
        if (message.command === 'frame-step' && ![-1, 1].includes(message.value)) return {ok: false};
        if (message.command === 'select-part' && (!Number.isInteger(message.value) || message.value < 0 || message.value > 8)) return {ok: false};
        return playerCommand(message.command, message.value);
      }
      if (message.type === 'CONTENT_REPORT') {
        await acceptReport(sender.tab.id, sender.frameId, message.candidates, sender.url || message.pageUrl, message.visibleFrameUrls);
        if (pending?.tabId === sender.tab.id) await tryPending(sender.tab.id);
        if (session?.tabId === sender.tab.id && (session.frameId !== sender.frameId || session.error) && !recoveryWork.has(`${session.tabId}:${session.videoId}`) && normalizeCandidates(message.candidates).some((candidate) => candidate.kind === 'player' && candidate.videoId === session.videoId)) {
          // A course can replace its iframe while the popup is closed.
          status().catch(() => {});
        }
        return {ok: true, shortcutScope: shortcutScope(sender.tab.id)};
      }
      if (message.type === 'CONTENT_STATE') { await acceptState(message.session, sender.tab.id, sender.frameId, {deferred: true}); return {ok: true}; }
      if (message.type === 'CONTENT_COUNT_IN' || message.type === 'CONTENT_COUNT_IN_CANCEL') return handleCountIn(message, sender.tab.id, sender.frameId);
      if (message.type.startsWith('OVERLAY_')) return handleOverlay(message, sender.tab.id, sender.frameId);
      if (message.type.startsWith('TOOLS_')) return handleTools(message, sender, false);
      if (FRETBOARD_MESSAGES.includes(message.type)) {
        if (sender.frameId !== 0 || fretboardTab !== sender.tab.id) return {ok: false, error: t('runtime.error.uiOnly')};
        // From a page, "open" only means the full tab ("Abrir completo").
        return handleUi(message.type === 'OPEN_FRETBOARD' ? {type: 'OPEN_FRETBOARD', layout: 'tab'} : message);
      }
      return {ok: false, error: t('runtime.error.uiOnly')};
    }
    return {ok: false, error: t('runtime.error.unauthorized')};
  });
  work.then(respond).catch((error) => respond({ok: false, error: error.message || t('runtime.error.actionFailed')}));
  return true;
});

const commandMap = {
  'toggle-playback': ['toggle-play'],
  'capture-a': ['capture-a'],
  'capture-b': ['capture-b'],
  'toggle-loop': ['toggle-loop'],
  restart: ['restart'],
  'seek-back': ['seek', -1],
  'seek-forward': ['seek', 1],
};
chrome.commands.onCommand.addListener((name) => {
  if (name === 'toggle-overlay') {
    ready.then(() => setOverlayTab(overlayTab === null && session ? session.tabId : null)).catch(() => {});
    return;
  }
  if (!commandMap[name]) return;
  ready.then(() => playerCommand(...commandMap[name])).catch(() => {});
});

// Open extension pages receive live session updates instead of waiting for the next poll.
chrome.runtime.onConnect?.addListener((port) => {
  if (port.name === 'lp-engine') { connectEngine(port); return; }
  if (port.name === 'lp-tools') { connectToolClient(port); return; }
  if (port.name !== 'lp-ui' || !trustedUi(port.sender || {})) return;
  uiPorts.add(port);
  port.onDisconnect.addListener(() => uiPorts.delete(port));
  // An external disk may be back, or the permission was granted on every visit.
  ready.then(() => { if (folderStatus.pending && folderStatus.state !== 'none') runFolderBackup().catch(() => {}); });
  ready.then(() => port.postMessage({type: 'SESSION', session, overlay: overlayInfo()})).catch(() => uiPorts.delete(port));
});

chrome.tabs.onRemoved.addListener((tabId) => {
  ready.then(async () => {
    scanErrors.delete(tabId);
    scanTimes.delete(tabId);
    shortcutScopes.delete(tabId);
    for (const key of Object.keys(reports)) if (reports[key].tabId === tabId) delete reports[key];
    if (session?.tabId === tabId) session = {...session, paused: true, gapRemaining: 0, error: t('runtime.session.tabClosed')};
    if (pending?.tabId === tabId) pending = null;
    if (overlayTab === tabId) overlayTab = null;
    await persistEphemeral();
    await dropToolWindows(tabId);
    if (fretboardTab === tabId) await setFretboardTab(null);
  });
});

chrome.windows?.onRemoved?.addListener((windowId) => {
  ready.then(async () => {
    const tool = TOOL_IDS.find((name) => toolPopups[name] === windowId);
    if (!tool) return;
    delete toolPopups[tool];
    await persistTools();
    broadcastTools();
  }).catch(() => {});
});

chrome.webNavigation.onCommitted.addListener((details) => {
  ready.then(async () => {
    if (details.frameId === 0) {
      for (const key of Object.keys(reports)) if (reports[key].tabId === details.tabId) delete reports[key];
    } else delete reports[frameKey(details.tabId, details.frameId)];
    scanTimes.delete(details.tabId);
    scanErrors.delete(details.tabId);
    if (session?.tabId === details.tabId && (details.frameId === 0 || session.frameId === details.frameId)) {
      session = {...session, restore: playbackRestore(session), paused: true, gapRemaining: 0, error: t('runtime.session.pageReloaded')};
    }
    await syncShortcutScopes();
    await persistEphemeral();
    await refreshAction(details.tabId);
  });
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (changeInfo.url) ready.then(() => clearChangedVideo(tabId, changeInfo.url)).catch(() => {});
  if (changeInfo.status === 'complete') ready.then(() => tryPending(tabId)).catch(() => {});
  // Standalone tool windows come back after the page navigates or reloads.
  if (changeInfo.status === 'complete') {
    ready.then(async () => {
      if (Object.values(toolWindows).includes(tabId) && !await pushTools(tabId, true)) await dropToolWindows(tabId);
      if (fretboardTab === tabId && !await pushFretboard(tabId, true)) await setFretboardTab(null);
    }).catch(() => {});
  }
});

async function refreshExistingTabs() {
  await ready;
  const tabs = await chrome.tabs.query({url: ['http://*/*', 'https://*/*']});
  const queue = tabs.filter((tab) => Number.isInteger(tab.id) && safePage(tab.url));
  await Promise.allSettled(Array.from({length: Math.min(4, queue.length)}, async () => {
    while (queue.length) await scanTab(queue.shift(), true);
  }));
}

chrome.runtime.onInstalled.addListener(() => { refreshExistingTabs().catch(() => {}); });
chrome.runtime.onStartup.addListener(() => { refreshExistingTabs().catch(() => {}); });
