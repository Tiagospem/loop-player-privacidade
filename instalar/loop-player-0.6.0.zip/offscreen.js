// Audio engine in the extension's offscreen document: one capture and one AudioContext serve every
// tool window. The service worker sends the desired state; readings and beats go back over a port.
import { createPitchTracker, createNoteTracker, decibels } from './lib/pitch.js';

const CAPTURE_TIMEOUT_MS = 8000;
let port = null;
let context = null;
let node = null;
let stream = null;
let source = null;
let openKey = '';
let analysisKey = '';
let desired = { capture: null, analysis: {}, metronome: { running: false } };
let status = { status: 'idle', error: null, message: '', input: { label: '', channels: 0, channel: 1 }, sampleRate: 0, devices: [] };
let countInUntil = 0;
let suspendTimer = null;
let queue = Promise.resolve();
const tracker = createPitchTracker();
const notes = createNoteTracker();

function post(message) {
  try { port?.postMessage(message); } catch { /* The worker reconnects and asks again. */ }
}

function setStatus(next) {
  status = { ...status, ...next, input: { ...status.input, ...next.input } };
  post({ type: 'status', ...status });
}

function connect() {
  port = chrome.runtime.connect({ name: 'lp-engine' });
  port.onMessage.addListener(receive);
  // A restarted service worker drops the port; the engine keeps running and reconnects.
  port.onDisconnect.addListener(() => { port = null; setTimeout(connect, 500); });
  post({ type: 'status', ...status });
}

function schedule(task) {
  queue = queue.then(task).catch((error) => setStatus({ status: 'error', error: 'unknown', message: String(error?.message || error) }));
  return queue;
}

function receive(message) {
  switch (message?.type) {
    case 'configure': desired = message; schedule(apply); break;
    case 'count-in': schedule(() => countIn(message)); break;
    case 'count-in-cancel': node?.port.postMessage({ type: 'count-in-cancel' }); break;
    case 'clear-notes': notes.clear(); break;
    default: break;
  }
}

async function ensureContext() {
  if (!context) {
    context = new AudioContext({ latencyHint: 'interactive' });
    await context.audioWorklet.addModule('audio-worklet.js');
    node = new AudioWorkletNode(context, 'loop-player-audio', {
      numberOfInputs: 1, numberOfOutputs: 1, outputChannelCount: [2],
      // Discrete keeps channel 2 of an interface separate instead of mixing it into channel 1.
      channelCount: 2, channelCountMode: 'explicit', channelInterpretation: 'discrete',
    });
    node.port.onmessage = (event) => fromWorklet(event.data);
    node.connect(context.destination);
    setStatus({ sampleRate: context.sampleRate });
  }
  clearTimeout(suspendTimer);
  if (context.state !== 'running') await context.resume();
}

const audioNeeded = () => Boolean(desired.capture) || desired.metronome?.running === true || Date.now() < countInUntil;

function scheduleSuspend(delay = 3000) {
  clearTimeout(suspendTimer);
  suspendTimer = setTimeout(() => schedule(async () => {
    if (!audioNeeded() && context?.state === 'running') await context.suspend();
  }), Math.max(0, delay));
}

function configureWorklet(reset = false) {
  node?.port.postMessage({ type: 'configure', capture: Boolean(source), channel: status.input.channel, gateDB: desired.analysis?.gateDB, metronome: desired.metronome, reset });
}

async function apply() {
  const key = JSON.stringify(desired.analysis || {});
  if (key !== analysisKey) {
    analysisKey = key;
    tracker.configure(desired.analysis || {});
  }
  if (audioNeeded()) await ensureContext();
  if (desired.capture) await openInput(desired.capture);
  else closeInput();
  configureWorklet();
  if (!audioNeeded()) scheduleSuspend();
}

function closeInput() {
  source?.disconnect();
  source = null;
  for (const track of stream?.getTracks() || []) track.stop();
  stream = null;
  openKey = '';
  if (status.status !== 'idle' && !desired.capture) setStatus({ status: 'idle', error: null, message: '', input: { label: '', channels: 0 } });
}

function getMedia(audio) {
  // Without a granted permission an offscreen document cannot show the prompt; never wait forever.
  return Promise.race([
    navigator.mediaDevices.getUserMedia({ audio, video: false }),
    new Promise((_, reject) => setTimeout(() => reject(Object.assign(new Error('Tempo esgotado ao abrir a entrada.'), { name: 'NotAllowedError' })), CAPTURE_TIMEOUT_MS)),
  ]);
}

async function failInput(error) {
  closeInput();
  let code = 'unknown';
  if (error?.name === 'NotAllowedError' || error?.name === 'SecurityError') {
    code = 'permission';
    try { if ((await navigator.permissions.query({ name: 'microphone' })).state === 'denied') code = 'denied'; } catch { /* Keep the generic permission code. */ }
  } else if (error?.name === 'NotFoundError' || error?.name === 'OverconstrainedError') code = 'no-device';
  else if (error?.name === 'NotReadableError' || error?.name === 'AbortError') code = 'busy';
  setStatus({ status: 'error', error: code, message: code === 'unknown' ? String(error?.message || error).slice(0, 300) : '' });
}

async function openInput({ deviceId = '', channel = 1 }) {
  const key = `${deviceId}|${channel}`;
  if (stream && key === openKey && stream.getAudioTracks()[0]?.readyState === 'live') return;
  closeInput();
  setStatus({ status: 'starting', error: null, message: '' });
  // Raw guitar signal: browser voice processing would distort pitch and dynamics.
  const audio = { echoCancellation: false, noiseSuppression: false, autoGainControl: false, channelCount: { ideal: 2 } };
  let warning = null;
  let opened;
  try {
    opened = await getMedia(deviceId ? { ...audio, deviceId: { exact: deviceId } } : audio);
  } catch (error) {
    if (!deviceId || !['OverconstrainedError', 'NotFoundError'].includes(error?.name)) return failInput(error);
    warning = 'device-missing';
    try { opened = await getMedia(audio); } catch (fallback) { return failInput(fallback); }
  }
  if (!desired.capture) {
    for (const track of opened.getTracks()) track.stop();
    return undefined;
  }
  stream = opened;
  const track = stream.getAudioTracks()[0];
  const channels = track?.getSettings?.().channelCount || 1;
  if (channel === 2 && channels < 2) warning ??= 'mono';
  source = context.createMediaStreamSource(stream);
  source.connect(node);
  openKey = key;
  tracker.reset();
  track?.addEventListener('ended', () => {
    if (stream?.getAudioTracks()[0] !== track) return;
    closeInput();
    setStatus({ status: 'error', error: 'device-lost', message: '' });
  });
  setStatus({ status: 'capturing', error: warning, message: '', input: { label: track?.label || '', channels, channel: channel === 2 && channels >= 2 ? 2 : 1 }, devices: await listDevices() });
  configureWorklet(true);
  return undefined;
}

// Labels are only visible once the extension has the microphone permission. This document has no
// interface language: an unnamed input goes out with an empty label and the tool panel names it.
async function listDevices() {
  try {
    return (await navigator.mediaDevices.enumerateDevices())
      .filter((device) => device.kind === 'audioinput' && device.deviceId && !['default', 'communications'].includes(device.deviceId))
      .map((device) => ({ deviceId: device.deviceId, label: device.label }));
  } catch { return []; }
}

// Frames of the context timeline ↔ wall-clock milliseconds at which they are heard.
function clock() {
  const stamp = context.getOutputTimestamp?.();
  if (stamp?.performanceTime > 0 && stamp.contextTime > 0) return { time: stamp.contextTime, epoch: performance.timeOrigin + stamp.performanceTime };
  return { time: context.currentTime, epoch: performance.timeOrigin + performance.now() + ((context.baseLatency || 0) + (context.outputLatency || 0)) * 1000 };
}
const epochToFrame = (epoch) => { const now = clock(); return Math.round((now.time + (epoch - now.epoch) / 1000) * context.sampleRate); };
const frameToEpoch = (frame) => { const now = clock(); return now.epoch + (frame / context.sampleRate - now.time) * 1000; };

async function countIn({ at, bpm, beats, accent, volume }) {
  countInUntil = Math.max(countInUntil, at + 1000);
  await ensureContext();
  // The video's sound leaves the same output with about the same latency as these clicks.
  const outputLatency = (context.outputLatency || 0) * 1000;
  node.port.postMessage({ type: 'count-in', endFrame: epochToFrame(at + outputLatency), bpm, beats, accent, volume });
  scheduleSuspend(at + 1000 - Date.now());
}

function fromWorklet(message) {
  if (message?.type === 'window') {
    if (!source) return;
    const { reading } = tracker.update(message.samples, context.sampleRate);
    const snapshot = notes.update(reading, { attack: message.attack });
    post({ type: 'reading', tuner: reading, notes: { current: snapshot.current, history: snapshot.history }, level: decibels(message.rms) });
  } else if (message?.type === 'beat') {
    post({ type: 'beat', beat: message.beat, beats: message.beats, countIn: message.countIn, at: frameToEpoch(message.frame) });
  }
}

// Plugging the interface in or granting the microphone retries a failed capture by itself.
const retry = () => {
  if (!desired.capture || (stream && status.error !== 'device-missing')) return;
  openKey = '';
  schedule(apply);
};
navigator.mediaDevices?.addEventListener?.('devicechange', async () => {
  setStatus({ devices: await listDevices() });
  retry();
});
navigator.permissions?.query({ name: 'microphone' }).then((permission) => { permission.onchange = retry; }).catch(() => {});

connect();
