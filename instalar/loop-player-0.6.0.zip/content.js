/* Runs in an isolated extension world, including eligible YouTube frames. */
(() => {
  const version = chrome.runtime.getManifest?.().version || 'development';
  const previous = globalThis.__loopPlayerContentInstalled;
  if (previous?.extensionId === chrome.runtime.id && previous.version === version) return;
  const marker = {extensionId: chrome.runtime.id, version};
  globalThis.__loopPlayerContentInstalled = marker;
  // Translator for code outside the ready callback; set once the catalogs load.
  let translate = null;

  const ready = Promise.all(['lib/core.js', 'lib/i18n.js', 'lib/preferences.js'].map((path) => import(chrome.runtime.getURL(path)))).then(async ([core, i18n, preferences]) => {
    // Error messages shown in the panel follow the language chosen in Settings.
    const stored = await Promise.resolve(chrome.storage?.local?.get(preferences.UI_PREFS_KEY)).catch(() => null);
    i18n.applyLocaleChoice(preferences.sanitizeUiPrefs(stored?.[preferences.UI_PREFS_KEY]).locale);
    chrome.storage?.onChanged?.addListener((changes, area) => {
      if (area === 'local' && changes[preferences.UI_PREFS_KEY]) i18n.applyLocaleChoice(preferences.sanitizeUiPrefs(changes[preferences.UI_PREFS_KEY].newValue).locale);
    });
    const {t} = i18n;
    translate = t;
    const {extractYouTubeVideoId, youtubeUrl, normalizeConfiguration, normalizeView, defaultConfiguration, viewTransform, countInPlan} = core;
    const roots = new Map();
    let lastReport = '';
    let visibleFrameUrls = [];
    let scanTimer;
    let scanStartedAt = null;
    let tickTimer;
    let session = null;
    let video = null;
    let gap = null;
    let gapTimer = null;
    let pendingSeek = null;
    let pendingPause = false;
    let framing = null;
    let framingPreview = null;
    let frameWatch = null;
    let lastStateAt = 0;
    let lastUrl = location.href;
    let destroyed = false;
    let shortcutScope = false;
    const now = () => performance.now();
    const isYouTubeFrame = () => /(^|\.)(youtube\.com|youtube-nocookie\.com)$/.test(location.hostname);
    const pageVideoId = () => isYouTubeFrame() ? extractYouTubeVideoId(location.href) : null;
    const finite = (value) => Number.isFinite(value) ? value : 0;
    // The audio engine runs in another document; both sides agree on wall-clock time.
    const epoch = (time) => (performance.timeOrigin || 0) + time;
    const send = (message) => {
      try { Promise.resolve(chrome.runtime.sendMessage(message)).then((reply) => { if (typeof reply?.shortcutScope === 'boolean') shortcutScope = reply.shortcutScope; }).catch(() => {}); } catch { destroyed = true; }
    };

    function visible(element) {
      if (!element.getClientRects().length) return false;
      const style = getComputedStyle(element);
      return style.visibility !== 'hidden' && style.visibility !== 'collapse' && style.display !== 'none';
    }

    function inspectRoots() {
      const discovered = [document];
      for (let i = 0; i < discovered.length; i++) {
        const root = discovered[i];
        if (!roots.has(root)) {
          const observer = new MutationObserver(scheduleScan);
          observer.observe(root, {childList: true, subtree: true, attributes: true, attributeFilter: ['href', 'src', 'data-src', 'data-lazy-src', 'style', 'class', 'hidden', 'title']});
          roots.set(root, observer);
        }
        for (const element of root.querySelectorAll('*')) {
          if (element.shadowRoot) discovered.push(element.shadowRoot);
        }
      }
      const alive = new Set(discovered);
      for (const [root, observer] of roots) {
        if (!alive.has(root)) { observer.disconnect?.(); roots.delete(root); }
      }
      return discovered;
    }

    function candidates() {
      const found = new Map();
      const renderedFrames = new Set();
      const embeddedYouTube = isYouTubeFrame() && /^\/embed\//.test(location.pathname);
      const title = document.title.replace(/\s*[-–]\s*YouTube\s*$/, '').trim();
      const titleScore = (value) => !value || /^Vídeo [\w-]{11}$/.test(value) || /^(?:\d+:){1,2}\d{2}(?:\s*\/\s*(?:\d+:){1,2}\d{2})?$/.test(value) ? 0 : Math.min(value.length, 80);
      const add = (url, text, kind) => {
        const videoId = extractYouTubeVideoId(url);
        if (!videoId) return;
        const candidate = {videoId, title: (text || '').replace(/\s+/g, ' ').trim().slice(0, 200) || `Vídeo ${videoId}`, youtubeUrl: youtubeUrl(videoId), kind};
        const previous = found.get(videoId);
        if (!previous || kind === 'player' && previous.kind !== 'player' || kind === previous.kind && titleScore(candidate.title) > titleScore(previous.title)) found.set(videoId, candidate);
      };
      for (const root of inspectRoots()) {
        for (const anchor of root.querySelectorAll('a[href]')) {
          // Recommendations inside an embedded player are not videos in the lesson.
          if (embeddedYouTube) continue;
          if (visible(anchor)) add(anchor.href, anchor.getAttribute('title') || anchor.getAttribute('aria-label') || anchor.textContent, 'link');
        }
        for (const player of root.querySelectorAll('iframe, embed, object')) {
          if (!visible(player)) continue;
          let hasSource = false;
          for (const attribute of ['src', 'data-src', 'data-lazy-src', 'data']) {
            const source = player.getAttribute(attribute);
            add(source, player.getAttribute('title') || player.getAttribute('aria-label'), 'player');
            if (source) {
              try { renderedFrames.add(new URL(source, location.href).href); hasSource = true; } catch { /* Invalid source. */ }
            }
          }
          if (!hasSource) renderedFrames.add(player.hasAttribute?.('srcdoc') ? 'about:srcdoc' : 'about:blank');
        }
      }
      visibleFrameUrls = [...renderedFrames];
      if (isYouTubeFrame() && document.querySelector('video')) add(location.href, title, 'player');
      return [...found.values()];
    }

    function scan(force = false) {
      if (destroyed) return [];
      const result = candidates();
      const report = JSON.stringify({candidates: result, pageUrl: location.href, visibleFrameUrls});
      if (force || report !== lastReport) {
        lastReport = report;
        send({type: 'CONTENT_REPORT', candidates: result, pageUrl: location.href, visibleFrameUrls});
      }
      return result;
    }

    function scheduleScan() {
      if (scanStartedAt === null) scanStartedAt = now();
      clearTimeout(scanTimer);
      // A busy player's style mutations must not postpone detection indefinitely.
      scanTimer = setTimeout(() => { scanStartedAt = null; scan(); }, Math.min(180, Math.max(0, 1000 - (now() - scanStartedAt))));
    }

    function adPlaying() {
      return isYouTubeFrame() && !!document.querySelector('.html5-video-player.ad-showing, .html5-video-player.ad-interrupting');
    }

    // Frame duration measured from presented frames; YouTube does not expose the frame rate.
    function watchFrames(target) {
      if (frameWatch?.video === target) return;
      if (frameWatch) frameWatch.video.cancelVideoFrameCallback?.(frameWatch.handle);
      frameWatch = null;
      if (typeof target?.requestVideoFrameCallback !== 'function') return;
      const watch = {video: target, handle: 0, samples: [], last: null};
      const onFrame = (_now, metadata) => {
        if (frameWatch !== watch || destroyed) return;
        const previous = watch.last;
        const delta = previous ? metadata.mediaTime - previous.mediaTime : 0;
        // Consecutive frames at normal speed or slower; faster playback may skip frames.
        if (previous && metadata.presentedFrames - previous.presentedFrames === 1 && target.playbackRate <= 1 && delta > 1 / 121 && delta < 1 / 9) {
          watch.samples.push(delta);
          if (watch.samples.length > 30) watch.samples.shift();
        }
        watch.last = {mediaTime: metadata.mediaTime, presentedFrames: metadata.presentedFrames};
        watch.handle = target.requestVideoFrameCallback(onFrame);
      };
      frameWatch = watch;
      watch.handle = target.requestVideoFrameCallback(onFrame);
    }

    function measuredFrameDuration() {
      const samples = frameWatch?.video === video ? frameWatch.samples : [];
      if (samples.length < 5) return null;
      return [...samples].sort((a, b) => a - b)[Math.floor(samples.length / 2)];
    }

    function frameStepTarget(direction) {
      const duration = measuredFrameDuration() ?? 1 / 30;
      const shown = frameWatch?.video === video ? frameWatch.last : null;
      // Aim at the middle of the neighbouring frame so rounding never lands on the same one.
      const target = shown && Math.abs(shown.mediaTime - video.currentTime) < duration
        ? shown.mediaTime + (direction + 0.5) * duration
        : video.currentTime + direction * duration;
      const end = Number.isFinite(video.duration) ? video.duration - duration / 2 : Infinity;
      return Math.max(0, Math.min(target, end));
    }

    const saveStyles = (element, names) => names.map((name) => [name, element.style.getPropertyValue(name), element.style.getPropertyPriority(name)]);
    const restoreStyles = (element, saved) => {
      for (const [name, value, priority] of saved) {
        if (value) element.style.setProperty(name, value, priority);
        else element.style.removeProperty(name);
      }
    };

    // YouTube positions the video inside a zero-height container; clip at the first ancestor that covers it.
    function clipHost(target) {
      const box = target.getBoundingClientRect?.();
      for (let node = target.parentElement; node; node = node.parentElement) {
        const rect = node.getBoundingClientRect?.();
        if (!box || !rect || rect.width >= box.width - 1 && rect.height >= box.height - 1) return node;
      }
      return null;
    }

    function clearFraming() {
      if (!framing) return;
      restoreStyles(framing.video, framing.saved);
      if (framing.clip) restoreStyles(framing.clip, framing.clipSaved);
      framing = null;
    }

    // A joystick drag shows its framing live without saving it; it lapses if the drag stops reporting.
    function previewFraming({index, view, mirror}) {
      if (!session || session.error || !video) return false;
      framingPreview = {index, view: normalizeView(view), mirror: mirror === true, until: now() + 3000};
      applyFraming();
      return true;
    }

    function framedConfiguration() {
      const configuration = session.configuration;
      if (framingPreview && now() > framingPreview.until) framingPreview = null;
      if (framingPreview?.index !== configuration.activeFragmentIndex) return configuration;
      const {index, view, mirror} = framingPreview;
      return {...configuration, mirror, fragments: configuration.fragments.map((fragment, position) => position === index ? {...fragment, view} : fragment)};
    }

    // Zoom and mirror live only in inline styles of the connected <video>; the player may rewrite them.
    function applyFraming() {
      const wanted = session && !session.error && video?.isConnected && !adPlaying() ? viewTransform(framedConfiguration()) : null;
      if (framing && (framing.video !== video || !wanted)) clearFraming();
      if (!wanted) return;
      if (!framing) {
        const clip = clipHost(video);
        framing = {video, clip, saved: saveStyles(video, ['transform', 'transform-origin']), clipSaved: clip ? saveStyles(clip, ['overflow']) : [], key: '', seen: ''};
      }
      const seen = () => [video.style.getPropertyValue('transform'), video.style.getPropertyValue('transform-origin'), framing.clip?.style.getPropertyValue('overflow')].join('|');
      const key = `${wanted.transform}|${wanted.origin}`;
      if (framing.key === key && framing.seen === seen()) return;
      video.style.setProperty('transform', wanted.transform, 'important');
      video.style.setProperty('transform-origin', wanted.origin, 'important');
      framing.clip?.style.setProperty('overflow', 'hidden', 'important');
      framing.key = key;
      framing.seen = seen();
    }

    function selectedFragment() {
      const fragment = session.configuration.fragments[session.configuration.activeFragmentIndex];
      const duration = video && Number.isFinite(video.duration) ? video.duration : Infinity;
      return {start: fragment.start, end: Math.min(fragment.end, duration)};
    }

    function state() {
      if (!session) return null;
      return {
        videoId: session.videoId,
        configuration: session.configuration,
        currentTime: finite(video?.currentTime),
        duration: finite(video?.duration),
        paused: video ? video.paused : true,
        repetitions: session.repetitions,
        gapRemaining: gap ? Math.max(0, (gap.deadline - now()) / 1000) : 0,
        countingIn: Boolean(gap?.countIn),
        adPlaying: adPlaying(),
        frameRate: measuredFrameDuration() ? Math.round(100 / measuredFrameDuration()) / 100 : null,
        error: session.error || null,
      };
    }

    function publish(force = false) {
      if (!session || destroyed) return;
      if (force || now() - lastStateAt >= 300) {
        lastStateAt = now();
        send({type: 'CONTENT_STATE', session: state()});
      }
    }

    function cancelGap() {
      if (gap?.countIn) send({type: 'CONTENT_COUNT_IN_CANCEL'});
      clearTimeout(gapTimer);
      gapTimer = null;
      gap = null;
      pendingPause = false;
    }

    function waitGap(next) {
      gap = next;
      clearTimeout(gapTimer);
      // A dedicated timer resumes on time; the 40 ms tick is only a fallback.
      gapTimer = setTimeout(finishGap, Math.max(0, next.deadline - now()));
    }

    // Pauses at `target` while one bar is counted in, then resumes exactly when the bar ends.
    function beginCountIn(target, plan) {
      cancelGap();
      pendingSeek = null;
      if (!video.paused) {
        pendingPause = true;
        video.pause();
      }
      const deadline = now() + plan.waitMs;
      waitGap({deadline, countIn: {target, bpm: plan.bpm, beats: plan.beats}});
      if (Math.abs(video.currentTime - target) > 0.05) {
        // Seek during the count so that playback can start without waiting for the player.
        pendingSeek = {target, resume: false, createdAt: now(), deadline: now() + 2500};
        try { video.currentTime = target; } catch { pendingSeek = null; }
      }
      send({type: 'CONTENT_COUNT_IN', at: epoch(deadline), bpm: plan.bpm, beats: plan.beats});
      publish(true);
    }

    function finishGap() {
      clearTimeout(gapTimer);
      gapTimer = null;
      if (!gap || !session || session.error || !video || adPlaying() || now() < gap.deadline) return;
      const finished = gap;
      gap = null;
      const target = finished.countIn ? finished.countIn.target : selectedFragment().start;
      if (finished.countIn && !pendingSeek && !video.seeking && Math.abs(video.currentTime - target) <= 0.3) {
        play();
        publish(true);
        return;
      }
      try { seekTo(target, true); } catch (error) { fail(error.message); }
    }

    function fail(message) {
      if (!session || session.error === message) return;
      cancelGap();
      pendingSeek = null;
      session.error = message;
      publish(true);
    }

    function assertConnected(allowAd = false) {
      if (!session || !video || !video.isConnected) throw new Error(t('runtime.content.selectVideo'));
      if (pageVideoId() !== session.videoId) {
        fail(t('runtime.content.videoChanged'));
        throw new Error(session.error);
      }
      if (session.error) throw new Error(session.error);
      if (!allowAd && adPlaying()) throw new Error(t('runtime.content.waitAd'));
    }

    function play() {
      try { Promise.resolve(video.play()).catch(() => {
        fail(t('runtime.content.playBlocked'));
      }); } catch { fail(t('runtime.content.playFailed')); }
    }

    function finishSeek() {
      if (!pendingSeek || !video || video.seeking) return;
      const target = pendingSeek.target;
      if (Math.abs(video.currentTime - target) > 0.3) return;
      const resume = pendingSeek.resume;
      pendingSeek = null;
      if (resume && !adPlaying() && !session.error) play();
      publish(true);
    }

    function seekTo(time, resume = false) {
      cancelGap();
      const duration = Number.isFinite(video.duration) ? video.duration : Infinity;
      const target = Math.max(0, Math.min(time, duration));
      pendingSeek = {target, resume, createdAt: now(), deadline: now() + 2500};
      try { video.currentTime = target; } catch {
        pendingSeek = null;
        throw new Error(t('runtime.content.seekUnavailable'));
      }
      publish(true);
    }

    function applySpeed() {
      if (video && !adPlaying()) video.playbackRate = session.configuration.speed;
    }

    function updateConfiguration(configuration) {
      const duration = Number.isFinite(video?.duration) && video.duration > 0 ? video.duration : Infinity;
      const normalized = normalizeConfiguration(configuration, duration);
      const previous = session.configuration;
      framingPreview = null;
      // Zoom, focus and mirror only change the picture: the loop, its gap and pending seeks carry on.
      const playback = (value) => JSON.stringify({...value, mirror: false, fragments: value.fragments.map(({start, end}) => [start, end])});
      if (playback(previous) === playback(normalized)) {
        session.configuration = normalized;
        applyFraming();
        publish(true);
        return state();
      }
      // Reframing a fragment keeps its repetition count.
      const bounds = (fragments) => JSON.stringify(fragments.map(({start, end}) => [start, end]));
      const changedFragment = previous.activeFragmentIndex !== normalized.activeFragmentIndex || bounds(previous.fragments) !== bounds(normalized.fragments);
      const resumePending = !!pendingSeek?.resume;
      cancelGap();
      pendingSeek = null;
      session.configuration = normalized;
      if (changedFragment) session.repetitions = 0;
      applySpeed();
      applyFraming();
      if (resumePending) {
        const {start, end} = selectedFragment();
        const target = normalized.loopEnabled && (video.currentTime < start || video.currentTime >= end) ? start : video.currentTime;
        seekTo(target, true);
      }
      publish(true);
      return state();
    }

    function onPause() {
      if (pendingPause) { pendingPause = false; return; }
      cancelGap();
      if (pendingSeek) pendingSeek.resume = false;
      publish(true);
    }

    function onSeeking() {
      if (pendingSeek && Math.abs(video.currentTime - pendingSeek.target) > 0.3) pendingSeek = null;
      if (!pendingSeek) cancelGap();
      publish(true);
    }

    function boundary() {
      if (!session || session.error || gap || pendingSeek || adPlaying() || !session.configuration.loopEnabled) return;
      const {start, end} = selectedFragment();
      if (end - start < 0.099) {
        fail(t('runtime.content.sectionOutOfRange'));
        return;
      }
      if (video.currentTime < end || video.paused && !video.ended) return;
      session.repetitions += 1;
      const plan = countInPlan(session.configuration, {wrap: true, minimumMs: session.configuration.gapSeconds * 1000});
      if (plan) {
        beginCountIn(start, plan);
      } else if (session.configuration.gapSeconds > 0) {
        waitGap({deadline: now() + session.configuration.gapSeconds * 1000});
        pendingPause = !video.paused;
        if (pendingPause) video.pause();
      } else {
        try { seekTo(start, true); } catch (error) { fail(error.message); }
      }
      publish(true);
    }

    function attachVideo(next) {
      if (video === next) return;
      if (video) {
        video.removeEventListener('pause', onPause);
        video.removeEventListener('seeking', onSeeking);
        video.removeEventListener('seeked', finishSeek);
        video.removeEventListener('ended', boundary);
        video.removeEventListener('timeupdate', boundary);
        video.removeEventListener('play', onPlay);
      }
      video = next;
      cancelGap();
      pendingSeek = null;
      applyFraming();
      watchFrames(video);
      if (video) {
        video.addEventListener('pause', onPause);
        video.addEventListener('seeking', onSeeking);
        video.addEventListener('seeked', finishSeek);
        video.addEventListener('ended', boundary);
        video.addEventListener('timeupdate', boundary);
        video.addEventListener('play', onPlay);
        if (session) applySpeed();
      }
    }

    function onPlay() { cancelGap(); publish(true); }

    function restorePlayback(restore) {
      if (!restore || !Number.isFinite(Number(restore.currentTime))) return;
      const {start, end} = selectedFragment();
      const requested = Math.max(0, Math.min(Number(restore.currentTime), video.duration));
      const target = session.configuration.loopEnabled && (requested < start || requested >= end) ? start : requested;
      if (restore.paused) video.pause();
      seekTo(target, !restore.paused);
    }

    function connect(videoId, configuration, repetitions = 0, restore = null) {
      if (!isYouTubeFrame() || pageVideoId() !== videoId) throw new Error(t('runtime.content.wrongFrame'));
      const next = document.querySelector('video.html5-main-video') || document.querySelector('video');
      if (!next) throw Object.assign(new Error(t('runtime.content.playerLoading')), {code: 'PLAYER_NOT_READY'});
      if (next.readyState === 0 || Number.isNaN(next.duration) || next.duration <= 0) throw Object.assign(new Error(t('runtime.content.pressPlay')), {code: 'PLAYER_NOT_READY'});
      if (!Number.isFinite(next.duration)) throw new Error(t('runtime.content.liveVideo'));
      const duration = adPlaying() ? Infinity : next.duration;
      session = {videoId, configuration: normalizeConfiguration(configuration || defaultConfiguration(), duration), normalizedDuration: duration, repetitions: Math.max(0, Math.floor(Number(repetitions) || 0)), error: null};
      framingPreview = null;
      attachVideo(next);
      applySpeed();
      applyFraming();
      if (restore) {
        if (adPlaying()) session.pendingRestore = restore;
        else restorePlayback(restore);
      }
      publish(true);
      clearTimeout(tickTimer);
      tickTimer = setTimeout(tick, 0);
      return state();
    }

    function command(name, value) {
      assertConnected();
      const configuration = structuredClone(session.configuration);
      const fragment = configuration.fragments[configuration.activeFragmentIndex];
      const playing = !video.paused || !!pendingSeek?.resume;
      switch (name) {
        case 'toggle-play': {
          const wasWaiting = !!gap;
          cancelGap();
          if (wasWaiting || playing) { if (pendingSeek) pendingSeek.resume = false; video.pause(); break; }
          if (!playing) {
            const {start, end} = selectedFragment();
            const outside = configuration.loopEnabled && (video.currentTime < start || video.currentTime >= end);
            const plan = countInPlan(session.configuration);
            if (plan) beginCountIn(outside ? start : video.currentTime, plan);
            else if (outside) seekTo(start, true);
            else play();
          }
          break;
        }
        case 'pause': {
          cancelGap();
          if (pendingSeek) pendingSeek.resume = false;
          if (!video.paused) video.pause();
          break;
        }
        case 'restart': {
          const plan = (playing || gap) && countInPlan(session.configuration);
          if (plan) beginCountIn(fragment.start, plan);
          else seekTo(fragment.start, playing || !!gap);
          break;
        }
        case 'seek':
        case 'seek-to': {
          const delta = Number(value);
          if (!Number.isFinite(delta)) throw new Error(t('runtime.content.invalidOffset'));
          seekTo(name === 'seek-to' ? delta : video.currentTime + delta, playing);
          break;
        }
        case 'frame-step': {
          const direction = Number(value);
          if (direction !== -1 && direction !== 1) throw new Error(t('runtime.content.frameDirection'));
          cancelGap();
          if (pendingSeek) pendingSeek.resume = false;
          if (!video.paused) video.pause();
          seekTo(frameStepTarget(direction), false);
          break;
        }
        case 'capture-a': {
          fragment.start = Math.max(0, finite(video.currentTime));
          if (fragment.end < fragment.start + 0.1) fragment.end = fragment.start + 0.1;
          updateConfiguration(configuration);
          break;
        }
        case 'capture-b': {
          fragment.end = Math.max(0.1, finite(video.currentTime));
          if (fragment.start > fragment.end - 0.1) fragment.start = Math.max(0, fragment.end - 0.1);
          updateConfiguration(configuration);
          break;
        }
        case 'toggle-loop': configuration.loopEnabled = !configuration.loopEnabled; updateConfiguration(configuration); break;
        case 'select-part': {
          const index = Number(value);
          if (!Number.isInteger(index) || index < 0 || index >= configuration.fragments.length) throw new Error(t('runtime.content.missingSection'));
          configuration.activeFragmentIndex = index;
          updateConfiguration(configuration);
          const plan = playing && countInPlan(session.configuration);
          if (plan) beginCountIn(session.configuration.fragments[index].start, plan);
          else seekTo(session.configuration.fragments[index].start, playing);
          break;
        }
        default: throw new Error(t('runtime.content.unknownCommand'));
      }
      publish(true);
      return state();
    }

    function tick() {
      if (destroyed) { clearFraming(); return; }
      if (location.href !== lastUrl) { lastUrl = location.href; scan(true); }
      if (session) {
        if (pageVideoId() !== session.videoId) {
          fail(t('runtime.content.videoChanged'));
        } else if (!session.error) {
          const next = document.querySelector('video.html5-main-video') || document.querySelector('video');
          if (!next) fail(t('runtime.content.playerRemoved'));
          else if (next !== video) attachVideo(next);
          if (adPlaying()) { cancelGap(); pendingSeek = null; }
          else if (video) {
            if (Number.isFinite(video.duration) && video.duration > 0 && session.normalizedDuration !== video.duration) {
              session.normalizedDuration = video.duration;
              updateConfiguration(session.configuration);
            }
            if (session.pendingRestore) {
              const restore = session.pendingRestore;
              session.pendingRestore = null;
              restorePlayback(restore);
            }
            if (video.playbackRate !== session.configuration.speed) applySpeed();
            if (pendingSeek) {
              if (now() > pendingSeek.deadline) { pendingSeek = null; fail(t('runtime.content.seekStalled')); }
              else if (now() - pendingSeek.createdAt > 80) finishSeek();
            }
            if (gap && now() >= gap.deadline) finishGap();
            boundary();
          }
        }
        applyFraming();
        publish();
      }
      tickTimer = setTimeout(tick, session ? document.hidden ? 100 : 40 : 1500);
    }

    document.addEventListener('keydown', (event) => {
      if (!event.isTrusted || !shortcutScope || destroyed || event.repeat || event.altKey || event.ctrlKey || event.metaKey || session?.error || adPlaying()) return;
      // The floating controller and tool windows handle their own keys inside closed shadow roots.
      if (event.composedPath().some((node) => node?.localName === 'loop-player-overlay' || node?.localName === 'loop-player-tool' || node?.isContentEditable || /^(INPUT|TEXTAREA|SELECT|BUTTON|SUMMARY|A)$/.test(node?.tagName || '') || ['textbox', 'combobox', 'slider'].includes(node?.getAttribute?.('role')))) return;
      const key = event.key.toLowerCase();
      const map = {' ': 'toggle-play', a: 'capture-a', b: 'capture-b', l: 'toggle-loop', r: 'restart'};
      let command = map[key];
      let value;
      if (key === ',' || key === '.') { command = 'frame-step'; value = key === ',' ? -1 : 1; }
      if (/^[1-9]$/.test(key)) { command = 'select-part'; value = Number(key) - 1; }
      if (['arrowleft', 'arrowright'].includes(key)) { command = 'seek'; value = (key === 'arrowleft' ? -1 : 1) * (event.shiftKey ? 0.1 : 1); }
      if (!command) return;
      event.preventDefault();
      event.stopImmediatePropagation();
      send({type: 'CONTENT_SHORTCUT', command, value});
    }, true);

    document.addEventListener('loadedmetadata', () => scan(true), true);
    addEventListener('popstate', () => scan(true));
    addEventListener('hashchange', () => scan(true));
    addEventListener('pageshow', () => scan(true));
    addEventListener('scroll', scheduleScan, {passive: true});
    addEventListener('resize', scheduleScan, {passive: true});
    scan(true);
    tick();
    return {
      handle(message) {
        switch (message.type) {
          case 'LP_SHORTCUT_SCOPE': shortcutScope = message.enabled === true; return {ok: true};
          case 'LP_SCAN': return {ok: true, candidates: scan(true), pageUrl: location.href, visibleFrameUrls};
          case 'LP_CONNECT': return {ok: true, session: connect(message.videoId, message.configuration, message.repetitions, message.restore)};
          case 'LP_COMMAND': return {ok: true, session: command(message.command, message.value)};
          case 'LP_SET_CONFIG': assertConnected(true); return {ok: true, session: updateConfiguration(message.configuration)};
          case 'LP_PREVIEW_VIEW': return {ok: previewFraming(message)};
          case 'LP_STATUS': return {ok: true, session: state()};
          case 'LP_DISCONNECT': session = null; framingPreview = null; cancelGap(); pendingSeek = null; clearFraming(); attachVideo(null); return {ok: true};
          default: return {ok: false, error: t('runtime.error.unknownMessage')};
        }
      },
    };
  });

  const receive = (message, sender, respond) => {
    if (sender.id !== chrome.runtime.id || !message?.type?.startsWith('LP_')) return;
    ready.then((runtime) => runtime.handle(message)).then(respond).catch((error) => respond({ok: false, code: error.code || null, error: error.message || (translate ? translate('runtime.content.controlFailed') : 'Could not control this video.')}));
    return true;
  };
  chrome.runtime.onMessage.addListener(receive);
  ready.catch(() => {
    if (globalThis.__loopPlayerContentInstalled === marker) delete globalThis.__loopPlayerContentInstalled;
    chrome.runtime.onMessage.removeListener?.(receive);
  });
})();
