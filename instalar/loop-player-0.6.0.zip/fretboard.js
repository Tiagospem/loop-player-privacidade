// Fretboard in an extension page: the full page in a tab, or the compact window used where the floating
// window cannot go (pages the extension cannot reach). The board itself is ui/fretboard-board.js.
import { mountFretboard, fretboardStorage } from './ui/fretboard-board.js';
import { hydrateIcons } from './ui/icons.js';
import { t, applyLocaleChoice, localizeDom, getLocale } from './lib/i18n.js';
import { loadUiPrefs, watchUiPrefs, applyAppearance, writeCache } from './ui/appearance.js';

const isExtension = Boolean(globalThis.chrome?.runtime?.id);
const compact = new URLSearchParams(location.search).get('layout') === 'compact';
document.documentElement.dataset.layout = compact ? 'compact' : 'page';
const WINDOW_KEY = 'loopPlayer.fretboardWindow.v1';
const storage = fretboardStorage(isExtension);
const $ = (selector) => document.querySelector(selector);
let pipWindow = null;

const uiPrefs = await loadUiPrefs();
applyAppearance(document.documentElement, uiPrefs);
applyLocaleChoice(uiPrefs.locale);
writeCache(uiPrefs, getLocale());
document.title = `${t('fretboard.title')} · Loop Player`;
localizeDom(document);
hydrateIcons(document);
watchUiPrefs((next) => {
  const previousLocale = getLocale();
  applyAppearance(document.documentElement, next);
  if (pipWindow) applyAppearance(pipWindow.document.documentElement, next);
  if (applyLocaleChoice(next.locale) !== previousLocale) location.reload();
});

const board = $('#board');
const app = await mountFretboard({ board, isExtension, layout: compact ? 'compact' : 'page' });
// Shortcuts typed outside the board (the page body) still reach it.
const keydown = (event) => { if (!event.composedPath().includes(board)) app.keydown(event); };
document.addEventListener('keydown', keydown);

// The compact window can grow into the full page in a tab, which continues from the same state.
$('#open-full').hidden = !compact;
$('#open-full').addEventListener('click', async () => {
  if (!isExtension) { location.href = 'fretboard.html'; return; }
  const response = await chrome.runtime.sendMessage({ type: 'OPEN_FRETBOARD', layout: 'tab' }).catch(() => null);
  if (response?.ok) window.close();
});
if (compact) {
  // The next compact window opens with the size and place of this one.
  const remember = () => storage.write(WINDOW_KEY, { width: window.outerWidth, height: window.outerHeight, left: window.screenX, top: window.screenY });
  let resizeTimer;
  window.addEventListener('resize', () => { clearTimeout(resizeTimer); resizeTimer = setTimeout(remember, 400); });
  window.addEventListener('pagehide', remember);
}

// A compact window that only holds the popped-out board steps out of the way, and comes back with it.
async function minimizeWindow(minimized) {
  if (!compact || !isExtension || !chrome.windows) return;
  try {
    const current = await chrome.windows.getCurrent();
    await chrome.windows.update(current.id, minimized ? { state: 'minimized' } : { state: 'normal', focused: true });
  } catch { /* The window stays as it is. */ }
}

// Picture-in-Picture keeps the board on top of every app while the lesson plays.
async function popOut() {
  if (pipWindow) { pipWindow.close(); return; }
  if (!globalThis.documentPictureInPicture?.requestWindow) { app.toast(t('fretboard.popOutUnavailable'), { tone: 'danger' }); return; }
  const opened = await documentPictureInPicture.requestWindow({ width: Math.min(1100, Math.max(760, board.offsetWidth)), height: Math.min(720, board.offsetHeight + 24) });
  const pipDocument = opened.document;
  pipDocument.title = `${t('fretboard.title')} · Loop Player`;
  for (const link of document.querySelectorAll('link[rel="stylesheet"]')) pipDocument.head.append(Object.assign(pipDocument.createElement('link'), { rel: 'stylesheet', href: link.href }));
  applyAppearance(pipDocument.documentElement, await loadUiPrefs());
  pipDocument.documentElement.dataset.layout = 'compact';
  pipDocument.documentElement.dataset.ready = '';
  pipDocument.body.classList.add('pip');
  pipDocument.addEventListener('keydown', keydown);
  pipWindow = opened;
  const layout = board.dataset.layout;
  board.dataset.layout = 'compact';
  pipDocument.body.append(board);
  $('#pop-out-label').textContent = t('fretboard.popBack');
  minimizeWindow(true);
  opened.addEventListener('pagehide', () => {
    pipWindow = null;
    board.dataset.layout = layout;
    $('.studio-head').after(board);
    $('#pop-out-label').textContent = t('fretboard.popOut');
    minimizeWindow(false);
  }, { once: true });
}
$('#pop-out').addEventListener('click', () => popOut().catch(() => app.toast(t('fretboard.popOutFailed'), { tone: 'danger' })));

document.documentElement.dataset.ready = '';
