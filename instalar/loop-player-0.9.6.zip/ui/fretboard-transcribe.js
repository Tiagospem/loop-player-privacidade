// Transcribe mode of the fretboard: figure out a solo from a video and practice it. The video plays above
// a timeline of the six strings; a line runs across it with the video. M marks the time of a note (a mark
// to fill), the neck puts or takes a note on the chosen mark or column (or at the current time), one note of
// a column can be chosen on its own to change or delete it, and the notes light up
// as the video reaches them. Work inside one of the video's A/B passages or on a free timeline over the
// whole video (the same choice as in the player: "Livre" leaves no passage chosen there). The timeline zooms
// and pans, with an overview of the whole passage or video; it follows the video while it plays.
// "Enviar para a Tablatura" turns it into a normal tab, with durations from the gaps.
// A transcription is saved like a tab (the worker writes it), with the video and each note's time.
import { STRING_COUNT, fretboardCells, pitchClass, spellPitch, tuningNames, tuningStrings } from '../lib/theory.js';
import {
  DEFAULT_METER, MAX_BPM, MAX_COLUMNS, MAX_TAB_NAME, MIN_BPM, MUTED,
  SAME_MOMENT, byTime, column, isMark, mergeSameMoment, isRest, isTranscription, meterText, normalizeBpm, normalizeColumn, normalizeTab, noteCount, sameLink, sanitizeTabs, transcriptionToTab,
} from '../lib/tabs.js';
import { t, getLocale } from '../lib/i18n.js';
import { ask } from './dialogs.js';
import { icon } from './icons.js';
import { escapeHTML, placePopover } from './html.js';
import { pageStorage, tabStore, videoBridge } from './tab-store.js';

const PLACE_KEY = 'loopPlayer.transcribe.v1';
const SAVE_DELAY_MS = 400;
const HISTORY_LIMIT = 100;
const ZOOMS = [5, 10, 20, 40, 80]; // seconds shown; null shows the whole passage or video
const FREE_ZOOM = 10;
const NO_PASSAGE = -1;
const SEEK_STEP = 2;
const NUDGE = 0.05;
const SPEEDS = [0.5, 0.6, 0.75, 0.9, 1];
const METERS = ['2/4', '3/4', '4/4', '5/4', '6/8', '12/8'];
const TECH_LABELS = { h: 'fretboard.tab.tech.h', p: 'fretboard.tab.tech.p', '/': 'fretboard.tab.tech.slideUp', '\\': 'fretboard.tab.tech.slideDown', b: 'fretboard.tab.tech.b', '~': 'fretboard.tab.tech.vibrato' };

const tx = (key, params) => escapeHTML(t(key, params));
const svg = (name, size = 14) => icon(name, { size });
const element = (tag, properties = {}) => Object.assign(document.createElement(tag), properties);
const tool = (id, content, label, { extra = '', attrs = '' } = {}) => `<button type="button" class="icon-btn${extra}" id="${id}" data-tip="${tx(label)}" aria-label="${tx(label)}"${attrs}>${content}</button>`;
const menuItem = (id, iconName, label) => `<button type="button" class="tab-menu-item" id="${id}" role="menuitem">${iconName ? svg(iconName, 16) : '<span class="tab-menu-blank"></span>'}<span>${tx(label)}</span></button>`;
// Short clock for the timeline: 1:04.5.
const clock = (seconds) => {
  const value = Math.max(0, seconds || 0);
  const minutes = Math.floor(value / 60);
  return `${minutes}:${(value - minutes * 60).toFixed(1).padStart(4, '0')}`;
};

export function transcribeMarkup() {
  return `
  <div class="tr-top" id="tr-top" hidden>
    <div class="tab-doc">
      <button type="button" class="tab-doc-library" id="tr-library" data-tip="${tx('fretboard.tr.library')}" aria-label="${tx('fretboard.tr.library')}">${svg('library', 16)}<span class="count" id="tr-count">0</span></button>
      <input id="tr-name" class="tab-name" maxlength="${MAX_TAB_NAME}" autocomplete="off" placeholder="${tx('fretboard.tr.namePlaceholder')}" aria-label="${tx('fretboard.tr.name')}">
      <span class="tab-status" id="tr-status" role="status"></span>
      <span class="bar-spacer"></span>
      <button type="button" class="btn btn-secondary btn-sm" id="tr-send" data-tip="${tx('fretboard.tr.sendHint')}">${svg('tab')}<span>${tx('fretboard.tr.send')}</span></button>
    </div>
    <div class="tab-toolbar tr-toolbar" role="toolbar" aria-label="${tx('fretboard.tr.toolbar')}">
      <span class="tab-group tr-transport">
        ${tool('tr-back', svg('skipBack', 16), 'fretboard.tr.back')}
        ${tool('tr-play', `<span class="tr-play-icon">${svg('play', 16)}</span><span class="tr-pause-icon" hidden>${svg('pause', 16)}</span>`, 'fretboard.tr.playPause', { extra: ' tr-play' })}
        ${tool('tr-forward', svg('skipForward', 16), 'fretboard.tr.forward')}
        <span class="tr-time" id="tr-time">0:00.0</span>
        <select id="tr-speed" class="input input-sm" data-tip="${tx('fretboard.tr.speed')}" aria-label="${tx('fretboard.tr.speed')}">${SPEEDS.map((speed) => `<option value="${speed}">${Math.round(speed * 100)}%</option>`).join('')}</select>
      </span>
      <span class="tab-sep" aria-hidden="true"></span>
      <label class="tr-part"><span class="sr-only">${tx('fretboard.tr.part')}</span><select id="tr-part" class="input input-sm" data-tip="${tx('fretboard.tr.partHint')}"></select></label>
      <span class="bar-spacer"></span>
      <button type="button" class="btn btn-secondary btn-sm" id="tr-mark" data-tip="${tx('fretboard.tr.markHint')}">${tx('fretboard.tr.mark')}</button>
      <span class="seg seg-icons tab-techs" id="tr-tech" role="radiogroup" aria-label="${tx('fretboard.tab.technique')}">
        ${Object.entries(TECH_LABELS).map(([tech, label]) => `<button type="button" role="radio" data-tech="${escapeHTML(tech)}" data-tip="${tx(label)}" aria-label="${tx(label)}"><b>${escapeHTML(tech)}</b></button>`).join('')}
      </span>
      ${tool('tr-delete', svg('trash', 16), 'fretboard.tr.delete')}
      ${tool('tr-undo', svg('undo', 16), 'fretboard.draw.undo')}
      ${tool('tr-more', svg('more', 16), 'fretboard.tr.more', { attrs: ' popovertarget="tr-more-menu"' })}
    </div>
    <div class="tab-menu" id="tr-more-menu" popover role="menu">
      ${menuItem('tr-redo', 'redo', 'fretboard.draw.redo')}
      ${menuItem('tr-clear-empty', 'eraser', 'fretboard.tr.clearEmpty')}
      <span class="tab-menu-sep"></span>
      ${menuItem('tr-new', 'plus', 'fretboard.tr.new')}
      ${menuItem('tr-remove', 'trash', 'fretboard.tr.remove')}
    </div>
  </div>
  <div class="tr-stage" id="tr-stage" hidden>
    <div class="tr-empty" id="tr-empty" hidden>
      <span class="tr-empty-icon" aria-hidden="true">${svg('video', 22)}</span>
      <p id="tr-empty-text"></p>
      <button type="button" class="btn btn-primary btn-sm" id="tr-start" hidden>${tx('fretboard.tr.start')}</button>
    </div>
    <div class="tr-timeline" id="tr-timeline" tabindex="0" role="application" aria-label="${tx('fretboard.tr.timeline')}" aria-describedby="tr-hint">
      <div class="tr-ruler" id="tr-ruler"></div>
      <div class="tr-lanes" id="tr-lanes"></div>
      <div class="tr-playhead" id="tr-playhead" data-tip="${tx('fretboard.tr.dragHead')}" hidden><span class="tr-playhead-time" id="tr-playhead-time"></span></div>
    </div>
    <div class="tr-overview" id="tr-overview" data-tip="${tx('fretboard.tr.overviewHint')}" aria-label="${tx('fretboard.tr.overview')}" hidden>
      <div class="tr-overview-notes" id="tr-overview-notes"></div>
      <div class="tr-overview-window" id="tr-overview-window"></div>
      <div class="tr-overview-head" id="tr-overview-head"></div>
    </div>
    <div class="tr-tray" id="tr-tray" hidden></div>
    <div class="tab-status-line">
      <span class="tr-view" role="group" aria-label="${tx('fretboard.tr.view')}">
        ${tool('tr-zoom-out', svg('minus', 14), 'fretboard.tr.zoomOut', { extra: ' icon-btn-sm' })}
        <span class="tr-zoom" id="tr-zoom"></span>
        ${tool('tr-zoom-in', svg('plus', 14), 'fretboard.tr.zoomIn', { extra: ' icon-btn-sm' })}
        <button type="button" class="btn btn-ghost btn-sm tr-follow" id="tr-follow" aria-pressed="true" data-tip="${tx('fretboard.tr.followHint')}">${tx('fretboard.tr.follow')}</button>
      </span>
      <span id="tr-position"></span>
      <span class="bar-spacer"></span>
      <span id="tr-hint" class="hint"></span>
    </div>
  </div>`;
}

export function transcribeDialogsMarkup() {
  const close = `<button type="button" class="icon-btn icon-btn-sm" value="cancel" title="${tx('common.close')}" aria-label="${tx('common.close')}">${svg('x', 16)}</button>`;
  return `
  <dialog class="dialog list-dialog" id="tr-library-dialog" aria-labelledby="tr-library-title">
    <div class="dialog-head"><h2 id="tr-library-title">${tx('fretboard.tr.library')}</h2>${close}</div>
    <ul class="diagram-list" id="tr-list"></ul>
    <div class="empty" id="tr-list-empty" hidden><span class="empty-icon">${svg('video', 22)}</span><strong>${tx('fretboard.tr.emptyTitle')}</strong><p>${tx('fretboard.tr.emptyText')}</p></div>
  </dialog>

  <dialog class="dialog form-dialog" id="tr-send-dialog" aria-labelledby="tr-send-title">
    <h2 id="tr-send-title">${tx('fretboard.tr.send')}</h2>
    <p>${tx('fretboard.tr.sendText')}</p>
    <div class="tab-tempo-fields">
      <label class="field-label" for="tr-bpm">${tx('fretboard.tab.bpm')}</label>
      <label class="field-label" for="tr-meter">${tx('fretboard.tab.meter')}</label>
      <input id="tr-bpm" class="input" type="number" min="${MIN_BPM}" max="${MAX_BPM}" step="1" inputmode="numeric">
      <select id="tr-meter" class="input">${METERS.map((meter) => `<option value="${meter}">${meter}</option>`).join('')}</select>
    </div>
    <p class="hint" id="tr-send-summary"></p>
    <div class="dialog-actions">
      <button type="button" class="btn btn-ghost" value="cancel">${tx('common.cancel')}</button>
      <button type="button" class="btn btn-primary" value="send">${tx('fretboard.tr.sendConfirm')}</button>
    </div>
  </dialog>`;
}

/**
 * @param {{view: () => object, render: () => void, renderNeck: () => void, toast: Function, isExtension: boolean,
 *   active: () => boolean, $: Function, $$: Function, openTab: (id: string) => Promise<void>}} options
 */
export async function createTranscriber({ view, render, renderNeck, toast, isExtension, active, $, $$, openTab }) {
  const store = tabStore(isExtension);
  const storage = pageStorage(isExtension);
  const bridge = videoBridge(isExtension);
  const place = (await storage.read(PLACE_KEY)) || {};
  let all = await store.list().catch(() => []);
  const transcriptions = () => all.filter(isTranscription);
  let doc = transcriptions().find((item) => item.id === place.currentId) || null;
  let selected = null; // the column chosen on the timeline (found again by its time when the transcription is reloaded)
  let pickedString = null; // one note of the chosen column, picked on the timeline or with ↑↓
  let row = 0;
  let tech = '';
  let typed = null;
  let video = null;
  // The part of the timeline on screen: where it starts and how many seconds it shows (null: all of it).
  let viewStart = 0;
  let zoom = FREE_ZOOM;
  let zoomFor = 'free';
  let following = true; // the timeline keeps the playing video in sight until it is moved by hand
  let scrub = null; // the line being dragged: {id, time, sent, timer}
  let saveTimer = null;
  let dirty = false;
  let status = '';
  let undo = [];
  let redo = [];
  let litAt = null; // time of the note the video reached (found again by time, like the chosen column)

  const windowOf = () => $('#tr-timeline').ownerDocument.defaultView;
  const linked = () => Boolean(doc && video && doc.video?.videoId === video.videoId);
  // The passage chosen in the player; none chosen is the free timeline over the whole video.
  const passage = () => (video ? video.fragments[video.active] ?? null : null);
  const rangeKey = () => (passage() ? 'passage' : 'free');

  // The section shown: the one bound to the passage looping now, or the free one. Created on first write.
  function findSection(create = false) {
    if (!doc) return null;
    const link = rangeKey() === 'passage' ? passage() : null;
    let found = doc.sections.find((item) => (link ? sameLink(item.link, link) : !item.link));
    if (!found && create) {
      const index = video?.active ?? 0;
      found = { id: `s${Math.random().toString(36).slice(2, 9)}`, name: link ? (link.name || t('fretboard.tr.passageName', { number: index + 1 })) : t('fretboard.tr.free'), columns: [], ...(link ? { link: { start: link.start, end: link.end } } : {}) };
      doc.sections.push(found);
    }
    return found;
  }
  const notes = () => byTime(findSection()?.columns || []);
  const timed = () => notes().filter((value) => value.at !== undefined);

  // Everything the timeline can show: the passage, or the whole video (or as far as the notes go).
  function bounds() {
    const link = rangeKey() === 'passage' ? passage() : null;
    if (link) return { from: link.start, to: Math.max(link.start + 0.5, Math.min(link.end, video.duration || link.end)) };
    const last = timed().at(-1)?.at ?? 0;
    return { from: 0, to: Math.max(video?.duration || 0, last + 5, FREE_ZOOM) };
  }
  // A passage starts shown whole; the free timeline starts at ten seconds.
  function zoomSpan() {
    const key = rangeKey() === 'passage' ? `passage:${passage().start}-${passage().end}` : 'free';
    if (zoomFor !== key) { zoomFor = key; zoom = key === 'free' ? FREE_ZOOM : null; following = true; }
    const { from, to } = bounds();
    return zoom === null ? to - from : Math.min(zoom, to - from);
  }
  // The time on screen.
  function range() {
    const { from, to } = bounds();
    const span = zoomSpan();
    viewStart = Math.min(Math.max(viewStart, from), to - span);
    return { from: viewStart, to: viewStart + span };
  }
  // Moves the view so the time is in sight (a page at a time, with a little of what came before).
  function reveal(time) {
    const { from, to } = range();
    if (time >= from && time <= to) return false;
    viewStart = time - (to - from) * 0.1;
    range();
    return true;
  }
  function pan(seconds, { byHand = true } = {}) {
    viewStart += seconds;
    if (byHand && video && !video.paused) following = false;
    renderView();
  }
  function setZoom(next, anchor) {
    const { from, to } = range();
    const at = anchor ?? (video && linked() && videoTime() >= from && videoTime() <= to ? videoTime() : (from + to) / 2);
    const ratio = (at - from) / (to - from);
    zoom = next;
    const span = zoomSpan();
    viewStart = at - ratio * span;
    renderView();
  }
  // One step closer (1) or farther (-1), ending at the whole passage or video.
  function zoomStep(direction, anchor) {
    const total = bounds().to - bounds().from;
    const choices = [...ZOOMS.filter((value) => value < total), null];
    const current = zoom === null ? choices.length - 1 : Math.max(0, choices.findIndex((value) => value !== null && value >= zoom));
    const next = choices[Math.min(choices.length - 1, Math.max(0, current - direction))];
    if (next !== zoom) setZoom(next, anchor);
  }

  // The video's time now: the last reading moved on since, at its speed, and kept inside a looping passage.
  function videoTime(at = performance.now()) {
    if (!video) return 0;
    let time = video.currentTime;
    if (!video.paused) time += (at - video.readAt) / 1000 * video.speed;
    const link = passage();
    if (!video.paused && link && link.end < video.duration && time > link.end && link.end > link.start) time = link.start + ((time - link.end) % (link.end - link.start));
    return time;
  }

  // What the line shows: the video's time, but smoothed. Each new reading of the video would otherwise move
  // the line by its small error (a tremble); small differences are caught up over a moment, real jumps (a
  // seek, the loop going back) are followed at once, and a pause stops the line where it is.
  const CATCH_UP = 0.25; // seconds to absorb a small difference
  const JUMP = 0.3; // a larger difference is a jump
  let shown = null; // {time, at}
  function displayTime(at = performance.now()) {
    const target = videoTime(at);
    if (!video || video.paused || !shown) { shown = { time: target, at }; return target; }
    const elapsed = Math.max(0, (at - shown.at) / 1000);
    const ahead = shown.time + elapsed * video.speed;
    const error = target - ahead;
    const time = Math.abs(error) > JUMP ? target : ahead + error * Math.min(1, elapsed / CATCH_UP);
    shown = { time, at };
    return time;
  }

  async function freshVideo() {
    const next = await bridge.state().catch(() => null);
    video = next ? { ...next, readAt: performance.now() - next.age } : null;
    return video;
  }

  async function command(name, value) {
    if (!linked()) { toast(t('fretboard.tr.notOpen')); return; }
    try { await bridge.command(doc.video.videoId, name, value); } catch (error) { toast(error.message, { tone: 'danger' }); }
    await freshVideo();
    renderView();
  }
  const seek = (time) => command('seek-to', Math.max(0, Math.round(time * 100) / 100));

  // Saving ---------------------------------------------------------------------------------------------
  function showStatus(next) {
    status = next;
    $('#tr-status').textContent = next ? t(`fretboard.tab.${next}`) : '';
  }
  function rememberPlace() { storage.write(PLACE_KEY, { currentId: doc?.id ?? null }); }
  function persist() {
    dirty = true;
    clearTimeout(saveTimer);
    showStatus('saving');
    saveTimer = setTimeout(flush, SAVE_DELAY_MS);
  }
  async function flush() {
    clearTimeout(saveTimer);
    saveTimer = null;
    if (!dirty || !doc) return;
    dirty = false;
    try {
      const response = await store.save(structuredClone(doc));
      all = sanitizeTabs(response.tabs);
      if (!dirty) showStatus('saved');
    } catch (error) {
      dirty = true;
      showStatus('saveFailed');
      toast(error.message, { tone: 'danger' });
    }
    if (active()) renderControls();
  }
  store.watch((list) => {
    all = list;
    const fresh = list.find((item) => item.id === doc?.id);
    if (fresh && !dirty && !saveTimer && fresh.updatedAt > doc.updatedAt) { doc = structuredClone(fresh); repair(); resync(); }
    if (active()) renderView();
  });
  $('#tr-timeline').ownerDocument.defaultView.addEventListener('pagehide', () => { if (dirty) flush(); });

  // Every edit: one undo step, the notes kept in time order, then save and redraw.
  // The chosen column as it is in the transcription now: a reload (the saved copy coming back, undo) makes new
  // objects, so it is found again by its time. Without this a note written "into" it became a new column.
  function resync() {
    if (!selected) return;
    const columns = findSection()?.columns || [];
    if (columns.includes(selected)) return;
    selected = selected.at === undefined ? null : columns.find((value) => value.at !== undefined && Math.abs(value.at - selected.at) < 0.005) || null;
    if (!selected) pickedString = null;
  }
  const selectedIndex = (section) => { resync(); return selected ? section.columns.indexOf(selected) : -1; };

  function change(mutate) {
    resync();
    undo.push(JSON.stringify(doc));
    if (undo.length > HISTORY_LIMIT) undo.shift();
    redo = [];
    mutate();
    tidy();
    doc.updatedAt = Date.now();
    persist();
    render();
  }
  function restore(snapshot) {
    doc = normalizeTab(JSON.parse(snapshot));
    tidy();
    resync();
    persist();
    render();
  }
  const undoStep = () => { if (undo.length) { redo.push(JSON.stringify(doc)); restore(undo.pop()); } };
  const redoStep = () => { if (redo.length) { undo.push(JSON.stringify(doc)); restore(redo.pop()); } };

  // Documents ------------------------------------------------------------------------------------------
  // Notes in time order, one column per moment of the video.
  function tidy() {
    let merged = 0;
    for (const item of doc?.sections || []) {
      const result = mergeSameMoment(item.columns);
      item.columns = result.columns;
      merged += result.merged;
    }
    return merged;
  }
  // A transcription saved with two columns at the same moment (0.8.x) is mended and saved once.
  function repair() { if (tidy()) { doc.updatedAt = Date.now(); persist(); } }

  function openDoc(target) {
    if (dirty) flush();
    doc = target ? structuredClone(target) : null;
    repair();
    selected = null;
    pickedString = null;
    undo = [];
    redo = [];
    showStatus(target && all.some((item) => item.id === target.id) ? 'saved' : '');
    rememberPlace();
    render();
  }

  // A transcription of the video open in the Loop Player, named after it.
  function startDoc() {
    if (!video) return;
    openDoc(normalizeTab({ name: video.title.slice(0, MAX_TAB_NAME), video: { videoId: video.videoId, title: video.title }, rhythm: true, sections: [{ name: t('fretboard.tr.free'), columns: [] }] }));
    persist();
  }

  // No "Praticar aqui" first: play, M or the start button practice the video of this page from here.
  let connecting = null;
  function usePageVideo() {
    connecting ??= (async () => {
      try {
        const response = await bridge.connect(doc?.video.videoId);
        // An embedded player that never played asks for one play on the page itself.
        if (response?.session?.error) toast(response.session.error);
      } catch (error) {
        toast(error.message, { tone: 'danger' });
      }
      await freshVideo();
      if (video && !doc) {
        const own = transcriptions().find((item) => item.video.videoId === video.videoId);
        if (own) openDoc(own); else startDoc();
      }
      renderView();
      return linked();
    })().finally(() => { connecting = null; });
    return connecting;
  }
  async function ready() {
    if (linked()) return true;
    if (!isExtension) { toast(t('fretboard.tr.extensionOnly')); return false; }
    const ok = await usePageVideo();
    if (!ok && doc) toast(t('fretboard.tr.notOpen'));
    return ok;
  }

  async function libraryDialog() {
    const list = $('#tr-list');
    const draw = () => {
      const items = transcriptions();
      $('#tr-list-empty').hidden = items.length > 0;
      list.replaceChildren(...items.map((item) => {
        const li = element('li', { className: 'diagram-item' });
        const open = element('button', { type: 'button', className: 'diagram-open' });
        open.dataset.open = item.id;
        open.append(element('strong', { textContent: item.name || t('fretboard.tab.untitled') }), element('span', { className: 'hint', textContent: `${item.video.title || item.video.videoId} · ${t('fretboard.tab.noteCount', { count: noteCount(item) })}` }));
        if (item.id === doc?.id) li.setAttribute('aria-current', 'true');
        li.append(open);
        return li;
      }));
    };
    const onClick = (event) => {
      const id = event.target.closest('[data-open]')?.dataset.open;
      if (!id) return;
      openDoc(transcriptions().find((item) => item.id === id));
      $('#tr-library-dialog').close('open');
    };
    list.addEventListener('click', onClick);
    draw();
    await ask($('#tr-library-dialog'));
    list.removeEventListener('click', onClick);
  }

  async function removeDoc() {
    if (!doc) return;
    const gone = structuredClone(doc);
    clearTimeout(saveTimer);
    saveTimer = null;
    dirty = false;
    try { all = sanitizeTabs((await store.remove(gone.id)).tabs); } catch (error) { toast(error.message, { tone: 'danger' }); return; }
    openDoc(transcriptions().find((item) => item.video.videoId === video?.videoId) || null);
    toast(t('fretboard.tr.removed', { name: gone.name || t('fretboard.tab.untitled') }), { action: { label: t('fretboard.draw.undo'), run: async () => {
      const response = await store.import([gone]).catch(() => null);
      if (response) { all = sanitizeTabs(response.tabs); openDoc(all.find((item) => item.id === gone.id) || null); }
    } } });
  }

  // "Enviar para a Tablatura": a normal tab with the notes in order and durations from the gaps.
  async function sendDialog() {
    if (!doc || !doc.sections.some((item) => item.columns.some((value) => !isRest(value)))) { toast(t('fretboard.tr.nothingToSend')); return; }
    const dialog = $('#tr-send-dialog');
    $('#tr-bpm').value = String(Math.round(video?.bpm || doc.bpm));
    $('#tr-meter').value = meterText(doc.meter || DEFAULT_METER);
    if (!$('#tr-meter').value) $('#tr-meter').value = '4/4';
    $('#tr-send-summary').textContent = t('fretboard.tr.sendSummary', { notes: t('fretboard.tab.noteCount', { count: noteCount(doc) }), sections: t('fretboard.tab.sectionCount', { count: doc.sections.filter((item) => item.columns.some((value) => !isRest(value))).length }) });
    if (await ask(dialog) !== 'send') return;
    const [beats, unit] = $('#tr-meter').value.split('/').map(Number);
    const tab = transcriptionToTab(doc, { bpm: normalizeBpm(Number($('#tr-bpm').value)) ?? doc.bpm, meter: { beats, unit } });
    if (dirty) await flush();
    try {
      const response = await store.import([tab]);
      all = sanitizeTabs(response.tabs);
      await openTab(response.summary.ids[0]);
      toast(t('fretboard.tr.sent'));
    } catch (error) { toast(error.message, { tone: 'danger' }); }
  }

  // Marking and writing -------------------------------------------------------------------------------
  // M while the video plays: a note written without a time takes this one; otherwise a mark to fill.
  async function mark() {
    if (!linked() && !await ready()) return;
    const tapped = performance.now();
    await freshVideo();
    if (!linked()) { toast(t(doc ? 'fretboard.tr.notOpen' : 'fretboard.tr.startFirst')); return; }
    const time = Math.round(videoTime(tapped) * 100) / 100;
    // A moment that already has a column needs no mark.
    if ((findSection()?.columns || []).some((value) => value.at !== undefined && Math.abs(value.at - time) < SAME_MOMENT)) return;
    change(() => {
      const section = findSection(true);
      const waiting = section.columns.find((value) => value.at === undefined && !isRest(value));
      if (waiting) section.columns[section.columns.indexOf(waiting)] = normalizeColumn({ ...waiting, at: time });
      else if (section.columns.length < MAX_COLUMNS) section.columns.push(column({}, '', { at: time }));
    });
  }

  // A fret on the neck: on the chosen mark or column, that string gets this note (the same note again takes it
  // off, so a column can hold a chord); with nothing chosen, a new note at the video's time (or on the column
  // already there). Typed numbers always set the note.
  function write(string, fret, { toggle = true } = {}) {
    if (!doc) { toast(t('fretboard.tr.startFirst')); return; }
    resync();
    change(() => {
      const section = findSection(true);
      let index = selectedIndex(section);
      if (index < 0 && video) {
        const at = Math.round(videoTime() * 100) / 100;
        index = section.columns.findIndex((value) => value.at !== undefined && Math.abs(value.at - at) < SAME_MOMENT);
        if (index < 0) { section.columns.push(column({}, '', { at })); index = section.columns.length - 1; }
      }
      if (index < 0) return;
      const target = section.columns[index];
      const n = [...target.n];
      n[string] = toggle && target.n[string] === fret ? null : fret;
      selected = normalizeColumn({ ...target, n, ...(tech && fret !== MUTED ? { t: tech } : {}) });
      section.columns[index] = selected;
      pickedString = n[string] === null ? null : string;
      tech = '';
    });
    row = string;
  }

  function select(target, { seekVideo = true, string = null } = {}) {
    selected = target;
    pickedString = target && string !== null && target.n?.[string] !== null ? string : null;
    if (pickedString !== null) row = pickedString;
    if (target?.at !== undefined) {
      reveal(target.at);
      if (seekVideo && linked()) seek(target.at);
    }
    render();
  }

  function step(direction) {
    const list = timed();
    if (!list.length) return;
    const at = selected?.at ?? videoTime();
    const next = direction > 0 ? list.find((value) => value.at > at + 0.001) : [...list].reverse().find((value) => value.at < at - 0.001);
    if (next) select(next);
  }

  function nudge(delta) {
    if (!selected || selected.at === undefined) return;
    change(() => {
      const section = findSection(true);
      const index = selectedIndex(section);
      if (index < 0) return;
      selected = normalizeColumn({ ...selected, at: Math.max(0, Math.round((selected.at + delta) * 100) / 100) });
      section.columns[index] = selected;
    });
  }

  function removeSelected() {
    if (!selected) return;
    change(() => {
      const section = findSection(true);
      const index = selectedIndex(section);
      if (index < 0) return;
      // One note picked in a chord goes alone; otherwise the whole column (or mark).
      const target = section.columns[index];
      if (pickedString !== null && target.n.filter((fret) => fret !== null).length > 1) {
        const n = [...target.n];
        n[pickedString] = null;
        selected = normalizeColumn({ ...target, n });
        section.columns[index] = selected;
        pickedString = null;
        return;
      }
      section.columns.splice(index, 1);
      selected = null;
      pickedString = null;
    });
  }

  function clearEmpty() {
    const section = findSection();
    if (!section?.columns.some(isMark)) return;
    change(() => { section.columns = section.columns.filter((value) => !isMark(value)); if (isMark(selected)) selected = null; });
  }

  function typeDigit(digit) {
    const now = Date.now();
    const joined = typed && now - typed.at < 700 && typed.target === selected ? Number(`${typed.value}${digit}`) : null;
    const fret = joined !== null && joined <= 24 ? joined : Number(digit);
    write(row, fret, { toggle: false });
    typed = { value: String(fret), at: now, target: selected };
  }

  function setTech(next) {
    tech = tech === next ? '' : next;
    if (selected && !isRest(selected)) {
      change(() => {
        const section = findSection(true);
        const index = selectedIndex(section);
        if (index < 0) return;
        selected = normalizeColumn({ ...selected, t: tech });
        section.columns[index] = selected;
      });
      tech = '';
    } else renderControls();
  }

  // Polling the video --------------------------------------------------------------------------------
  let polling = false;
  let lastPoll = 0;
  async function poll() {
    if (polling) return;
    polling = true;
    lastPoll = performance.now();
    try {
      if (active()) {
        await freshVideo();
        // The video open now shows its own most recent transcription.
        if (video && (!doc || doc.video.videoId !== video.videoId) && !dirty) {
          const own = transcriptions().find((item) => item.video.videoId === video.videoId);
          if (own) openDoc(own);
        }
        renderView();
      }
    } finally {
      polling = false;
      // Faster while the video plays, so a pause made elsewhere (the player, YouTube) stops the line soon.
      try { windowOf().setTimeout(poll, !active() ? 1500 : video && !video.paused ? 200 : 400); } catch { /* The window closed; the watchdog restarts it. */ }
    }
  }
  if (isExtension) {
    poll();
    setInterval(() => { if (performance.now() - lastPoll > 2000) poll(); }, 1000);
  }

  // The line runs with the video; the note it reached lights up, and the neck shows it.
  let frameView = null;
  function follow() {
    if (frameView) return;
    frameView = windowOf();
    const tick = () => {
      if (!active() || !video) { frameView = null; return; }
      placePlayhead();
      try { frameView = windowOf(); frameView.requestAnimationFrame(tick); } catch { frameView = null; }
    };
    frameView.requestAnimationFrame(tick);
  }

  function placePlayhead() {
    const time = scrub ? scrub.time : displayTime();
    const lanes = $('#tr-lanes');
    if (!scrub && following && linked() && !video.paused && reveal(time)) renderTimeline();
    const { from, to } = range();
    const head = $('#tr-playhead');
    const visible = linked() && time >= from && time <= to;
    head.hidden = !visible;
    if (visible) head.style.setProperty('left', `${lanes.offsetLeft + (time - from) / (to - from) * lanes.clientWidth}px`);
    $('#tr-playhead-time').textContent = clock(time);
    $('#tr-time').textContent = video ? `${clock(time)} / ${clock(video.duration)}` : '0:00.0';
    placeOverview(time);
    const reached = [...timed()].reverse().find((value) => value.at <= time + 0.02 && !isRest(value)) || null;
    if ((reached?.at ?? null) !== litAt) {
      litAt = reached?.at ?? null;
      for (const node of $$('#tr-lanes [data-lit]')) node.removeAttribute('data-lit');
      if (litAt !== null) for (const node of $$(`#tr-lanes [data-at="${litAt}"]`)) node.dataset.lit = 'true';
      if (!selected && !video?.paused) renderNeck();
    }
  }

  // Rendering ----------------------------------------------------------------------------------------
  const tokenOf = (value, string) => {
    const fret = value.n[string];
    if (fret === null) return '';
    if (fret === MUTED) return 'x';
    return `${value.t || ''}${fret}`;
  };

  // Rebuilt only when something on it changed: the poll redraws often, and a click whose note was replaced
  // between press and release used to land on the empty timeline (deselecting and moving the video).
  let timelineKey = '';
  function renderTimeline() {
    const lanes = $('#tr-lanes');
    const ruler = $('#tr-ruler');
    const { from, to } = range();
    const key = JSON.stringify([from, to, doc?.id, doc?.tuning, timed().map((value) => [value.at, value.n, value.t]), selected?.at, pickedString, getLocale()]);
    if (key === timelineKey && lanes.childElementCount) { renderOverview(); return; }
    timelineKey = key;
    const span = to - from;
    const x = (time) => `${((time - from) / span) * 100}%`;
    const unit = span <= 12 ? 1 : span <= 40 ? 5 : 10;
    const ticks = [];
    for (let second = Math.ceil(from / unit) * unit; second <= to; second += unit) {
      const tick = element('span', { className: 'tr-tick', textContent: clock(second).replace(/\.0$/, '') });
      tick.style.setProperty('left', x(second));
      ticks.push(tick);
    }
    ruler.replaceChildren(...ticks);
    const labels = [...tuningNames(doc?.tuning || 'standard')];
    if (labels[0] === labels[STRING_COUNT - 1]) labels[STRING_COUNT - 1] = labels[STRING_COUNT - 1].toLowerCase();
    const strings = [...Array(STRING_COUNT).keys()].reverse();
    const items = [];
    for (const [rowIndex, string] of strings.entries()) {
      const lane = element('span', { className: 'tr-lane', textContent: labels[string] });
      lane.style.setProperty('top', `${rowIndex * 24}px`);
      items.push(lane);
    }
    for (const value of timed()) {
      if (value.at < from - 0.01 || value.at > to + 0.01) continue;
      const band = element('button', { type: 'button', className: `tr-note${isMark(value) ? ' is-mark' : ''}` });
      band.style.setProperty('left', x(value.at));
      band.dataset.at = String(value.at);
      band.dataset.tip = `${clock(value.at)}${isMark(value) ? ` · ${t('fretboard.tr.markToFill')}` : ''}`;
      band.setAttribute('aria-label', isMark(value) ? t('fretboard.tr.markAt', { time: clock(value.at) }) : `${clock(value.at)}: ${strings.filter((string) => value.n[string] !== null).map((string) => `${labels[string]} ${tokenOf(value, string)}`).join(', ')}`);
      if (value === selected) band.dataset.selected = 'true';
      if (value.at === litAt) band.dataset.lit = 'true';
      for (const [rowIndex, string] of strings.entries()) {
        const token = tokenOf(value, string);
        if (!token) continue;
        const chip = element('span', { className: 'tr-fret', textContent: token });
        chip.dataset.string = String(string);
        if (value === selected && string === pickedString) chip.dataset.picked = 'true';
        chip.style.setProperty('top', `${rowIndex * 24}px`);
        band.append(chip);
      }
      items.push(band);
    }
    lanes.replaceChildren(...items);
    renderOverview();
  }

  // The overview: the whole passage or video, its notes, the part on screen and the video's place.
  function renderOverview() {
    const overview = $('#tr-overview');
    const all = bounds();
    const { from, to } = range();
    const whole = all.to - all.from;
    overview.hidden = to - from >= whole - 0.01;
    if (overview.hidden) return;
    const x = (time) => `${((time - all.from) / whole) * 100}%`;
    $('#tr-overview-notes').replaceChildren(...timed().filter((value) => value.at >= all.from && value.at <= all.to).map((value) => {
      const tick = element('span', { className: `tr-overview-note${isMark(value) ? ' is-mark' : ''}` });
      tick.style.setProperty('left', x(value.at));
      return tick;
    }));
    const box = $('#tr-overview-window');
    box.style.setProperty('left', x(from));
    box.style.setProperty('width', `${((to - from) / whole) * 100}%`);
  }
  function placeOverview(time) {
    const head = $('#tr-overview-head');
    const all = bounds();
    head.hidden = $('#tr-overview').hidden || !linked() || time < all.from || time > all.to;
    if (!head.hidden) head.style.setProperty('left', `${((time - all.from) / (all.to - all.from)) * 100}%`);
  }

  function renderTray() {
    const waiting = notes().filter((value) => value.at === undefined && !isRest(value));
    $('#tr-tray').hidden = !waiting.length;
    $('#tr-tray').textContent = waiting.length ? t('fretboard.tr.waiting', { count: waiting.length }) : '';
  }

  function hint() {
    if (!doc) return '';
    if (selected && isMark(selected)) return t('fretboard.tr.hintMark');
    if (selected && pickedString !== null) return t('fretboard.tr.hintPicked');
    if (selected) return t('fretboard.tr.hintNote');
    return t('fretboard.tr.hintKeys');
  }

  function renderControls() {
    const has = Boolean(doc);
    const same = linked();
    $('#tr-count').textContent = String(transcriptions().length);
    const name = $('#tr-name');
    if (name !== name.getRootNode().activeElement || name.dataset.doc !== doc?.id) name.value = doc?.name || '';
    name.dataset.doc = doc?.id || '';
    name.disabled = !has;
    showStatus(has ? status : '');
    $('#tr-send').disabled = !has;
    for (const id of ['#tr-back', '#tr-forward', '#tr-speed', '#tr-part']) $(id).disabled = !same;
    // Play and M can start practicing the page's video themselves.
    const canStart = isExtension;
    for (const id of ['#tr-play', '#tr-mark']) $(id).disabled = !same && !canStart;
    $('#tr-delete').disabled = !selected;
    const chord = selected && selected.n.filter((fret) => fret !== null).length > 1;
    $('#tr-delete').dataset.tip = t(isMark(selected) ? 'fretboard.tr.deleteMark' : chord && pickedString !== null ? 'fretboard.tr.deletePicked' : chord ? 'fretboard.tr.deleteColumn' : 'fretboard.tr.delete');
    const span = has ? zoomSpan() : FREE_ZOOM;
    const total = has ? bounds().to - bounds().from : FREE_ZOOM;
    $('#tr-zoom').textContent = span >= total - 0.01 ? t('fretboard.tr.zoomAll') : t('fretboard.tr.zoomSeconds', { seconds: Math.round(span) });
    $('#tr-zoom-in').disabled = !has || span <= ZOOMS[0];
    $('#tr-zoom-out').disabled = !has || span >= total - 0.01;
    $('#tr-follow').setAttribute('aria-pressed', String(following));
    $('#tr-follow').disabled = !same;
    $('#tr-play .tr-play-icon').hidden = Boolean(video && !video.paused);
    $('#tr-play .tr-pause-icon').hidden = !(video && !video.paused);
    const speed = $('#tr-speed');
    if (speed.getRootNode().activeElement !== speed) speed.value = String(video ? SPEEDS.reduce((best, item) => (Math.abs(item - video.speed) < Math.abs(best - video.speed) ? item : best)) : 1);
    // Every passage of the video, or free over the whole video: the same choice as in the player.
    const select = $('#tr-part');
    const short = (time) => clock(time).replace(/\.0$/, '');
    const options = [element('option', { value: 'free', textContent: t('fretboard.tr.free') }), ...(video?.fragments || []).map((link, index) => element('option', {
      value: String(index), textContent: t('fretboard.tr.passage', { number: index + 1, name: link.name ? ` · ${link.name}` : '', start: short(link.start), end: short(link.end) }),
    }))];
    const signature = options.map((option) => `${option.value}:${option.textContent}`).join('|');
    if (select.dataset.options !== signature) { select.replaceChildren(...options); select.dataset.options = signature; }
    if (select.getRootNode().activeElement !== select) select.value = passage() ? String(video.active) : 'free';
    for (const button of $$('#tr-tech [data-tech]')) button.setAttribute('aria-checked', String(button.dataset.tech === (selected?.t || tech)));
    $('#tr-undo').disabled = !undo.length;
    $('#tr-redo').disabled = !redo.length;
    $('#tr-remove').disabled = !has;
    // Without the video or a transcription, the stage says what to do.
    const empty = $('#tr-empty');
    empty.hidden = has && (same || !video);
    $('#tr-timeline').hidden = !has;
    $('#tr-start').hidden = !isExtension || (has && same);
    $('#tr-start').textContent = t(video ? 'fretboard.tr.start' : 'fretboard.tr.usePageVideo');
    $('#tr-empty-text').textContent = !isExtension ? t('fretboard.tr.extensionOnly')
      : !video ? (has ? t('fretboard.tr.openVideo', { title: doc.video.title || doc.video.videoId }) : t('fretboard.tr.noVideo'))
        : has && !same ? t('fretboard.tr.otherVideo', { title: video.title })
          : t('fretboard.tr.startText', { title: video.title });
    if (has && !video) empty.hidden = false;
    const list = timed();
    const marks = list.filter(isMark).length;
    $('#tr-position').textContent = has ? [t('fretboard.tab.noteCount', { count: list.length - marks }), marks ? t('fretboard.tr.marksLeft', { count: marks }) : ''].filter(Boolean).join(' · ') : '';
    $('#tr-hint').textContent = hint();
  }

  function renderView() {
    if (!active()) return;
    resync();
    renderControls();
    if (doc) { renderTimeline(); renderTray(); placePlayhead(); }
    if (video && !video.paused) follow();
  }

  // The neck: every note by name in the background, the chosen note and the one the video reached.
  function model() {
    const state = view();
    const tuning = doc?.tuning || 'standard';
    const range = { from: 0, to: state.frets };
    const strings = tuningStrings(tuning);
    const dots = new Map();
    const put = (dot) => dots.set(`${dot.string}:${dot.fret}`, dot);
    for (const cell of fretboardCells({ tuning, range })) put({ string: cell.string, fret: cell.fret, kind: 'ghost', text: spellPitch(cell.pc, 9, 'major') });
    resync();
    // The chosen column always (so what the neck shows is what a click changes); otherwise the note reached.
    const shown = selected || timed().find((value) => value.at === litAt) || null;
    shown?.n.forEach((fret, string) => {
      if (Number.isInteger(fret) && fret <= state.frets) put({ string, fret, kind: shown === selected && string === pickedString ? 'root' : 'mark', text: String(fret), title: `${spellPitch(pitchClass(strings[string] + fret), 9, 'major')} · ${t('fretboard.tab.fretTitle', { fret })}` });
    });
    return { range, leftHanded: state.hand === 'left', highOnTop: state.high === 'top', stringNames: tuningNames(tuning), interactive: true, dots: [...dots.values()], lines: [] };
  }

  // Events -------------------------------------------------------------------------------------------
  const timeAt = (event) => {
    const lanes = $('#tr-lanes').getBoundingClientRect();
    const { from, to } = range();
    return from + Math.min(1, Math.max(0, (event.clientX - lanes.left) / lanes.width)) * (to - from);
  };
  // A note (or one fret of it) is chosen on press, not on release, so a redraw in between cannot lose it.
  function pressLanes(event) {
    const band = event.target.closest('.tr-note');
    const chip = event.target.closest('.tr-fret');
    if (band) { select(timed().find((value) => String(value.at) === band.dataset.at) || null, { string: chip ? Number(chip.dataset.string) : null }); return; }
    selected = null;
    pickedString = null;
    // The empty timeline: the video goes there, and keeps following while the button is held.
    if (!startScrub(event, $('#tr-lanes')) && linked()) seek(timeAt(event));
    render();
  }
  $('#tr-lanes').addEventListener('pointerdown', (event) => { if (event.button === 0) pressLanes(event); });
  $('#tr-lanes').addEventListener('pointermove', moveScrub);
  $('#tr-lanes').addEventListener('pointerup', endScrub);
  $('#tr-lanes').addEventListener('pointercancel', endScrub);
  // Enter or Space on a focused note.
  $('#tr-lanes').addEventListener('click', (event) => { if (event.detail === 0 && event.target.closest('.tr-note')) pressLanes(event); });
  // Dragging the line (or along the ruler, or the empty timeline) moves the video with it: the picture follows
  // while dragging, the view pans near the edges, and M marks wherever it is let go.
  const SCRUB_EVERY_MS = 90;
  function scrubTo(event) {
    const box = $('#tr-lanes').getBoundingClientRect();
    const all = bounds();
    let { from, to } = range();
    const edge = Math.min(36, box.width * 0.08);
    // Near an edge the view pans, a little each move, toward where the line is going.
    if (event.clientX < box.left + edge && from > all.from) { viewStart -= (to - from) * 0.04; renderTimeline(); ({ from, to } = range()); }
    else if (event.clientX > box.right - edge && to < all.to) { viewStart += (to - from) * 0.04; renderTimeline(); ({ from, to } = range()); }
    const ratio = Math.min(1, Math.max(0, (event.clientX - box.left) / box.width));
    scrub.time = Math.round(Math.min(all.to, Math.max(all.from, from + ratio * (to - from))) * 100) / 100;
    placePlayhead();
    const now = performance.now();
    if (now - scrub.sent >= SCRUB_EVERY_MS) {
      scrub.sent = now;
      bridge.command(doc.video.videoId, 'seek-to', scrub.time).catch(() => {});
    }
  }
  function startScrub(event, target) {
    if (event.button !== 0 || !linked()) return false;
    event.preventDefault();
    scrub = { id: event.pointerId, time: videoTime(), sent: 0, target };
    target.setPointerCapture?.(event.pointerId);
    $('#tr-playhead').dataset.dragging = 'true';
    following = false;
    scrubTo(event);
    return true;
  }
  function moveScrub(event) { if (scrub?.id === event.pointerId) scrubTo(event); }
  function endScrub(event) {
    if (scrub?.id !== event.pointerId) return;
    const { time } = scrub;
    scrub = null;
    delete $('#tr-playhead').dataset.dragging;
    following = Boolean(video && !video.paused);
    seek(time);
  }
  for (const target of [$('#tr-playhead'), $('#tr-ruler')]) {
    target.addEventListener('pointerdown', (event) => startScrub(event, target));
    target.addEventListener('pointermove', moveScrub);
    target.addEventListener('pointerup', endScrub);
    target.addEventListener('pointercancel', endScrub);
  }
  // Trackpad sideways (or Shift + wheel) pans; Ctrl/⌘ + wheel (or a pinch) zooms around the pointer.
  let zoomWheel = 0;
  $('#tr-timeline').addEventListener('wheel', (event) => {
    if (!doc) return;
    if (event.ctrlKey || event.metaKey) {
      event.preventDefault();
      zoomWheel += event.deltaY;
      if (Math.abs(zoomWheel) < 40) return;
      const direction = zoomWheel < 0 ? 1 : -1;
      zoomWheel = 0;
      zoomStep(direction, timeAt(event));
      return;
    }
    const delta = Math.abs(event.deltaX) > Math.abs(event.deltaY) ? event.deltaX : event.shiftKey ? event.deltaY : 0;
    if (!delta) return;
    event.preventDefault();
    const { from, to } = range();
    pan((delta / $('#tr-lanes').clientWidth) * (to - from));
  }, { passive: false });
  // The overview: drag the window to move the view; click elsewhere to take the video there.
  const overviewTime = (event) => {
    const box = $('#tr-overview').getBoundingClientRect();
    const all = bounds();
    return all.from + Math.min(1, Math.max(0, (event.clientX - box.left) / box.width)) * (all.to - all.from);
  };
  let overviewDrag = null;
  $('#tr-overview').addEventListener('pointerdown', (event) => {
    if (event.button !== 0 || !doc) return;
    const { from, to } = range();
    const time = overviewTime(event);
    const inside = time >= from && time <= to;
    overviewDrag = { id: event.pointerId, offset: inside ? time - from : (to - from) / 2, moved: false, seekTo: inside ? null : time };
    $('#tr-overview').setPointerCapture(event.pointerId);
    if (!inside) { viewStart = time - overviewDrag.offset; renderView(); }
  });
  $('#tr-overview').addEventListener('pointermove', (event) => {
    if (overviewDrag?.id !== event.pointerId) return;
    overviewDrag.moved = true;
    overviewDrag.seekTo = null;
    viewStart = overviewTime(event) - overviewDrag.offset;
    if (video && !video.paused) following = false;
    renderView();
  });
  const endOverview = (event) => {
    if (overviewDrag?.id !== event.pointerId) return;
    const { seekTo } = overviewDrag;
    overviewDrag = null;
    if (event.type === 'pointerup' && seekTo !== null && linked()) { following = true; seek(seekTo); }
  };
  $('#tr-overview').addEventListener('pointerup', endOverview);
  $('#tr-overview').addEventListener('pointercancel', endOverview);
  $('#tr-zoom-in').addEventListener('click', () => zoomStep(1));
  $('#tr-zoom-out').addEventListener('click', () => zoomStep(-1));
  $('#tr-follow').addEventListener('click', () => {
    following = !following;
    if (following && linked()) reveal(videoTime());
    renderView();
  });
  $('#tr-name').addEventListener('input', (event) => { if (!doc) return; doc.name = event.target.value.slice(0, MAX_TAB_NAME); doc.updatedAt = Date.now(); persist(); });
  $('#tr-library').addEventListener('click', libraryDialog);
  $('#tr-start').addEventListener('click', () => { if (video) startDoc(); else usePageVideo(); });
  $('#tr-new').addEventListener('click', startDoc);
  $('#tr-remove').addEventListener('click', removeDoc);
  $('#tr-send').addEventListener('click', sendDialog);
  $('#tr-back').addEventListener('click', () => seek(videoTime() - SEEK_STEP));
  $('#tr-forward').addEventListener('click', () => seek(videoTime() + SEEK_STEP));
  // Playing again brings the view back to the video.
  const togglePlay = async () => {
    if (!linked() && !await ready()) return;
    if (video?.paused) following = true;
    // Pausing from here stops the line at once, without waiting for the next reading of the video.
    else if (video) { video = { ...video, currentTime: displayTime(), readAt: performance.now(), paused: true }; renderView(); }
    command('toggle-play');
  };
  $('#tr-play').addEventListener('click', togglePlay);
  $('#tr-speed').addEventListener('change', (event) => command('speed', Number(event.target.value)));
  // Free leaves no passage chosen in the player; a passage is chosen there too (and the video goes to it).
  $('#tr-part').addEventListener('change', (event) => {
    const index = event.target.value === 'free' ? NO_PASSAGE : Number(event.target.value);
    selected = null;
    following = true;
    if (index === NO_PASSAGE) viewStart = videoTime() - FREE_ZOOM * 0.1;
    command('select-part', index);
  });
  $('#tr-mark').addEventListener('click', mark);
  $('#tr-tech').addEventListener('click', (event) => { const button = event.target.closest('[data-tech]'); if (button) setTech(button.dataset.tech); });
  $('#tr-undo').addEventListener('click', undoStep);
  $('#tr-redo').addEventListener('click', redoStep);
  $('#tr-delete').addEventListener('click', removeSelected);
  $('#tr-clear-empty').addEventListener('click', clearEmpty);
  $('#tr-more-menu').addEventListener('click', (event) => { if (event.target.closest('.tab-menu-item')) $('#tr-more-menu').hidePopover?.(); });
  for (const type of ['beforetoggle', 'toggle']) $('#tr-more-menu').addEventListener(type, (event) => { if (event.newState === 'open') placePopover($('#tr-more-menu'), $('#tr-more'), { align: 'end' }); });

  // Keyboard: Space plays, M marks, arrows move between notes (Shift: the video, Alt: the mark's time).
  function keydown(event) {
    if (!active() || event.altKey && !['ArrowLeft', 'ArrowRight'].includes(event.key)) return;
    const typing = event.composedPath().some((node) => /^(INPUT|TEXTAREA|SELECT)$/.test(node?.tagName || ''));
    if (typing) return;
    const mod = event.ctrlKey || event.metaKey;
    if (mod && event.key.toLowerCase() === 'z') { event.preventDefault(); if (event.shiftKey) redoStep(); else undoStep(); return; }
    if (mod && event.key.toLowerCase() === 'y') { event.preventDefault(); redoStep(); return; }
    if (mod) return;
    const handled = () => event.preventDefault();
    switch (event.key) {
      case ' ': handled(); togglePlay(); return;
      case 'PageUp': case 'PageDown': { handled(); const { from, to } = range(); pan((event.key === 'PageUp' ? -1 : 1) * (to - from) * 0.9); return; }
      case 'Home': handled(); viewStart = bounds().from; pan(0); return;
      case 'End': handled(); viewStart = bounds().to; pan(0); return;
      case '+': case '=': handled(); zoomStep(1); return;
      case '-': handled(); zoomStep(-1); return;
      case 'm': case 'M': handled(); mark(); return;
      case 'ArrowLeft': case 'ArrowRight': {
        handled();
        const direction = event.key === 'ArrowLeft' ? -1 : 1;
        if (event.altKey) nudge(direction * NUDGE);
        else if (event.shiftKey) seek(videoTime() + direction * SEEK_STEP);
        else step(direction);
        return;
      }
      // ↑↓ pick the next note of the chosen column (or the string a typed number goes to).
      case 'ArrowUp': case 'ArrowDown': {
        handled();
        const direction = event.key === 'ArrowUp' ? 1 : -1;
        const strings = selected ? [...Array(STRING_COUNT).keys()].filter((string) => selected.n[string] !== null) : [];
        const next = direction > 0 ? strings.find((string) => string > (pickedString ?? row)) : [...strings].reverse().find((string) => string < (pickedString ?? row));
        if (next !== undefined) { pickedString = next; row = next; } else row = Math.min(STRING_COUNT - 1, Math.max(0, row + direction));
        render();
        return;
      }
      case 'Backspace': case 'Delete': handled(); removeSelected(); return;
      case 'Escape': if (selected) { handled(); selected = null; pickedString = null; render(); } return;
      case 'x': case 'X': handled(); write(row, MUTED); return;
      default:
        if (/^\d$/.test(event.key)) { handled(); typeDigit(event.key); return; }
        if (TECH_LABELS[event.key]) { handled(); setTech(event.key); }
    }
  }

  // The transcription open at start is checked like any other.
  if (doc) { doc = structuredClone(doc); repair(); }

  return {
    cell: (target) => write(target.string, target.fret),
    model,
    render: renderView,
    keydown,
    title: () => doc?.name || t('fretboard.tr.title'),
  };
}
