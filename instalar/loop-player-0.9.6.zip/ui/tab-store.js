// Saved tabs and transcriptions (the worker writes them), what each editor keeps for itself, and the video
// practiced in the Loop Player. Shared by the Tab and Transcribe modes of the fretboard.
import { mergeTabs, sanitizeTabs, saveTab } from '../lib/tabs.js';
import { t } from '../lib/i18n.js';

export const TABS_KEY = 'loopPlayer.tabs.v1';

// Where the editor was and its clipboard belong to this page; the static preview uses localStorage.
export function pageStorage(isExtension) {
  return {
    async read(key) {
      try {
        if (isExtension) return (await chrome.storage.local.get(key))[key];
        return JSON.parse(localStorage.getItem(key) || 'null');
      } catch { return null; }
    },
    write(key, value) {
      try {
        if (isExtension) chrome.storage.local.set({ [key]: value });
        else localStorage.setItem(key, JSON.stringify(value));
      } catch { /* The editor keeps working in memory. */ }
    },
  };
}

// Saved tabs live in the worker; the static preview (no extension) keeps them in this browser.
export function tabStore(isExtension) {
  if (isExtension) {
    const send = async (message) => {
      const response = await chrome.runtime.sendMessage(message);
      if (!response?.ok) throw new Error(response?.error || t('common.extensionNoResponse'));
      return response;
    };
    return {
      list: async () => sanitizeTabs((await send({ type: 'GET_TABS' })).tabs),
      save: (tab) => send({ type: 'SAVE_TAB', tab }),
      remove: (id) => send({ type: 'DELETE_TAB', id }),
      import: (tabs) => send({ type: 'IMPORT_TABS', tabs }),
      watch: (callback) => chrome.storage.onChanged.addListener((changes, area) => {
        if (area === 'local' && changes[TABS_KEY]) callback(sanitizeTabs(changes[TABS_KEY].newValue));
      }),
    };
  }
  const read = () => { try { return sanitizeTabs(JSON.parse(localStorage.getItem(TABS_KEY) || '[]')); } catch { return []; } };
  const write = (tabs) => { localStorage.setItem(TABS_KEY, JSON.stringify(tabs)); return tabs; };
  return {
    list: async () => read(),
    save: async (raw) => { const { tab, tabs } = saveTab(read(), raw); return { tab, tabs: write(tabs) }; },
    remove: async (id) => ({ tabs: write(read().filter((item) => item.id !== id)) }),
    import: async (incoming) => { const { tabs, ...summary } = mergeTabs(read(), incoming); return { summary, tabs: write(tabs) }; },
    watch: () => {},
  };
}

// The video practiced in the Loop Player, through the worker (content.js controls the player).
export function videoBridge(isExtension) {
  if (!isExtension) return { state: async () => null, command: async () => null, connect: async () => null };
  const send = async (message) => {
    const response = await chrome.runtime.sendMessage(message);
    if (!response?.ok) throw new Error(response?.error || t('common.extensionNoResponse'));
    return response;
  };
  return {
    state: async () => (await send({ type: 'TAB_VIDEO_STATE' })).video,
    command: (videoId, command, value) => send({ type: 'TAB_VIDEO_COMMAND', videoId, command, value }),
    // Starts practicing the video of the page (the one given, when the page has it).
    connect: (videoId) => send({ type: 'TAB_VIDEO_CONNECT', ...(videoId ? { videoId } : {}) }),
  };
}
